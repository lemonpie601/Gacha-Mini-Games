/* Gacha Mini Games v1.6.0 — personal extension for Gacha Forge on Marinara Engine.
 * While a chapter or story is being generated, the generation screen gets a column of small games on its right:
 * 지뢰찾기, 사과 상자 (the fruit follows the 말랑 colour preset), 2048, 짝 맞추기, 쿠키 가게, 디저트 핀볼 and more. Closing the column or
 * finishing generation removes them; nothing here touches the run, rewards or the generation request.
 * Split out of Gacha UI Style · 말랑 (1.12.0). Works on its own; with 말랑 on it takes 말랑's colours, preset and
 * SD sprites; without it, the colours and corners of the game's own UI style. Short synthesized hit sounds follow
 * Gacha Forge Sound's volume when it is installed. Best records live in this browser only. */
(() => {
  "use strict";
  const KEY = "__GF_MINIGAMES_EXTENSION";
  if (typeof window[KEY] === "function") {
    try { window[KEY](); } catch {}
  }
  const HOST_TAG = "marinara-capability-gacha-forge";
  const MARINARA = typeof marinara !== "undefined" && marinara ? marinara : null;
  const life = new AbortController();
  const on = (target, type, fn, opts = {}) => target.addEventListener(type, fn, { ...opts, signal: life.signal });
  const el = (tag, cls = "", text = "") => { const n = document.createElement(tag); if (cls) n.className = cls; if (text) n.textContent = text; return n; };
  let disposed = false;

  /* Loading games: local UI state only; never touch the run, rewards or generation request. */
  function newMineGame(random = Math.random, difficulty = "easy") {
    const [cols, mines] = ({ easy: [8, 10], normal: [10, 18], hard: [12, 30] })[difficulty] || [8, 10];
    const cells = Array.from({ length: cols * cols }, () => ({ mine: false, open: false, flag: false, count: 0 }));
    const game = { cells, cols, rows: cols, mines, started: false, ended: false, won: false, boom: -1 };
    const neighbours = (i) => cells.map((_, j) => j).filter((j) => j !== i && Math.abs(j % cols - i % cols) <= 1 && Math.abs(Math.floor(j / cols) - Math.floor(i / cols)) <= 1);
    game.neighbours = neighbours;
    game.flag = (i) => { if (!game.ended && !cells[i].open) cells[i].flag = !cells[i].flag; };
    game.reveal = (i) => {
      if (game.ended || cells[i].flag || cells[i].open) return;
      if (!game.started) {
        const safe = new Set([i, ...neighbours(i)]), pool = cells.map((_, j) => j).filter((j) => !safe.has(j));
        for (let k = 0; k < mines; k++) { const at = k + Math.floor(random() * (pool.length - k)); [pool[k], pool[at]] = [pool[at], pool[k]]; cells[pool[k]].mine = true; }
        cells.forEach((c, j) => c.count = neighbours(j).filter((n) => cells[n].mine).length);
        game.started = true;
      }
      if (cells[i].mine) { cells[i].open = true; game.ended = true; game.boom = i; return; }
      const queue = [i];
      while (queue.length) { const j = queue.pop(), c = cells[j]; if (c.open || c.flag || c.mine) continue; c.open = true; if (!c.count) queue.push(...neighbours(j)); }
      if (cells.filter((c) => c.open).length === cells.length - mines) { game.ended = true; game.won = true; }
    };
    // Pressing an opened number whose flags are all placed opens the rest around it (as in the classic game).
    game.chord = (i) => {
      const c = cells[i];
      if (game.ended || !c.open || !c.count) return;
      const around = neighbours(i);
      if (around.filter((j) => cells[j].flag).length !== c.count) return;
      for (const j of around) { game.reveal(j); if (game.ended) return; }
    };
    return game;
  }
  function newFruitGame(random = Math.random, difficulty = "normal") {
    const [cols, rows, max, time] = ({ easy: [8, 6, 5, 180], normal: [10, 8, 9, 120], hard: [12, 10, 9, 90] })[difficulty] || [10, 8, 9, 120];
    const game = { cols, rows, time, cells: Array.from({ length: cols * rows }, () => 1 + Math.floor(random() * max)), score: 0, ended: false };
    game.cells[0] = max === 5 ? 5 : 1; game.cells[1] = 10 - game.cells[0]; // Every new board has at least one legal selection.
    game.select = (a, b, remove = false) => {
      const x0 = Math.min(a % cols, b % cols), x1 = Math.max(a % cols, b % cols), y0 = Math.min(Math.floor(a / cols), Math.floor(b / cols)), y1 = Math.max(Math.floor(a / cols), Math.floor(b / cols));
      const ids = game.cells.map((_, i) => i).filter((i) => i % cols >= x0 && i % cols <= x1 && Math.floor(i / cols) >= y0 && Math.floor(i / cols) <= y1);
      const sum = ids.reduce((n, i) => n + game.cells[i], 0);
      if (remove && sum === 10 && !game.ended) { game.score += ids.filter((i) => game.cells[i]).length; ids.forEach((i) => game.cells[i] = 0); }
      return { ids, sum };
    };
    // A rectangle that still sums to 10 (for the hint, and to end a board with nothing left to clear).
    game.findMove = () => {
      const sum = (x0, y0, x1, y1) => { let n = 0; for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) n += game.cells[y * cols + x]; return n; };
      for (let y0 = 0; y0 < rows; y0++) for (let x0 = 0; x0 < cols; x0++) for (let y1 = y0; y1 < rows; y1++) {
        if (sum(x0, y0, x0, y1) > 10) break;
        for (let x1 = x0; x1 < cols; x1++) { const s = sum(x0, y0, x1, y1); if (s === 10) return { a: y0 * cols + x0, b: y1 * cols + x1 }; if (s > 10) break; }
      }
      return null;
    };
    return game;
  }
  function new2048Game(random = Math.random, difficulty = "normal") {
    const [size, goal] = ({ easy: [5, 2048], normal: [4, 2048], hard: [3, 256] })[difficulty] || [4, 2048];
    const cells = Array(size * size).fill(0);
    const game = { size, cols: size, goal, cells, score: 0, ended: false, won: false, fresh: -1, merged: [] };
    const spawn = () => {
      const empty = cells.map((v, i) => v ? -1 : i).filter((i) => i >= 0);
      if (!empty.length) { game.fresh = -1; return; }
      const i = empty[Math.floor(random() * empty.length)];
      cells[i] = random() < 0.9 ? 2 : 4; game.fresh = i;
    };
    // The cells of one row or column, listed from the side the tiles slide towards.
    const line = (k, dir) => Array.from({ length: size }, (_, i) => dir === "left" ? k * size + i : dir === "right" ? k * size + size - 1 - i : dir === "up" ? i * size + k : (size - 1 - i) * size + k);
    game.canMove = () => cells.some((v, i) => !v || (i % size < size - 1 && cells[i + 1] === v) || (i + size < cells.length && cells[i + size] === v));
    game.move = (dir) => {
      if (game.ended) return false;
      let moved = false; game.merged = [];
      for (let k = 0; k < size; k++) {
        const idx = line(k, dir), vals = idx.map((i) => cells[i]).filter(Boolean), out = [], merged = [];
        for (let j = 0; j < vals.length; j++) {
          if (j + 1 < vals.length && vals[j] === vals[j + 1]) { const v = vals[j] * 2; out.push(v); merged.push(out.length - 1); game.score += v; if (v >= goal) game.won = true; j++; }
          else out.push(vals[j]);
        }
        idx.forEach((i, p) => { const v = out[p] || 0; if (cells[i] !== v) moved = true; cells[i] = v; });
        game.merged.push(...merged.map((p) => idx[p]));
      }
      if (moved) spawn(); else game.fresh = -1;
      if (!game.canMove()) game.ended = true;
      return moved;
    };
    spawn(); spawn();
    return game;
  }
  const MEMORY_SYMBOLS = ["🍎", "🍋", "🍇", "🍓", "🍑", "🍒", "🥝", "🍍", "🍉", "🍊", "🫐", "🥥"];
  function newMemoryGame(random = Math.random, difficulty = "easy", faces = []) {
    const [cols, pairs] = ({ easy: [4, 6], normal: [4, 8], hard: [6, 12] })[difficulty] || [4, 6];
    const shuffle = (list) => { const a = list.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
    // The world's own SD characters are the cards; fruit fills in when there are fewer of them than pairs.
    const pool = [...shuffle([...new Set(faces)]).slice(0, pairs), ...MEMORY_SYMBOLS].slice(0, pairs);
    const cells = shuffle([...pool, ...pool]).map((face) => ({ face, open: false, done: false }));
    const game = { cols, rows: cells.length / cols, pairs, cells, moves: 0, ended: false, won: false };
    game.flip = (i) => {
      const c = cells[i];
      if (game.ended || c.open || c.done) return "ignored";
      const up = cells.map((x, j) => x.open && !x.done ? j : -1).filter((j) => j >= 0);
      if (up.length >= 2) return "busy";
      c.open = true;
      if (!up.length) return "open";
      game.moves++;
      const other = cells[up[0]];
      if (other.face !== c.face) return "miss";
      other.done = c.done = true;
      if (cells.every((x) => x.done)) game.ended = game.won = true;
      return "match";
    };
    game.hide = () => cells.forEach((x) => { if (x.open && !x.done) x.open = false; });
    return game;
  }
  /* More games: 쿠키 가게, 디저트 핀볼, 비스킷 벽돌깨기, 젤리 블록, 스네이크, 딸기 우유 레시피, 초코칩 터뜨리기, 꽃밭 퍼즐, 별 밝히기. */
  // 쿠키 가게, in the manner of 슈의 라면집. Guests queue at the counter (three at most), each with an order — plain,
  // chocolate chip, cream or both — and a patience that runs out. An oven goes: butter the tray → light it → wait for
  // the preheat lamp → dough → sugar → bake. While the cookie is golden (it steams), top it as ordered, then plate it:
  // the guest who ordered that cookie takes it (else whoever waited longest) and pays by how it was made (game.judge),
  // plus a tip when it came quickly. A lit oven left too long — empty or not — burns: clearing it uses one of three
  // spares, and with no spare left that oven is gone. A guest who gives up costs a heart. Reach the day's goal to win;
  // run out of hearts or ovens and the shop closes. Time is passed in (now), so the game can be paused by shifting it.
  const SHOP_TOOLS = [["butter", "버터"], ["fire", "불 켜기"], ["dough", "반죽"], ["sugar", "설탕"], ["chip", "초코칩"], ["cream", "크림"], ["serve", "접시"]];
  const SHOP_ORDERS = { plain: "플레인", chip: "초코칩", cream: "크림", both: "스페셜" };
  function newShopGame(random = Math.random, difficulty = "normal") {
    // preheat, bake, golden, over, empty oven burns after, goal, a guest every, patience, hearts
    const [heat, bake, ready, over, empty, goal, every, patience, hearts] = ({
      easy: [1500, 5000, 4500, 3500, 9000, 6000, 9000, 34000, 5],
      normal: [1500, 4000, 3500, 2500, 7000, 10000, 7000, 26000, 4],
      hard: [1200, 3500, 2600, 2000, 5500, 15000, 5500, 20000, 3],
    })[difficulty] || [1500, 4000, 3500, 2500, 7000, 10000, 7000, 26000, 4];
    const fresh = () => ({ butter: false, lit: null, dough: null, flat: false, sugar: false, chip: "", cream: "" });
    const game = { heat, bake, ready, over, empty, goal, patience, hearts, ovens: [fresh(), fresh(), fresh(), fresh()], spares: 3, money: 0, tips: 0, served: 0, perfect: 0, left: 0,
      queue: [], guests: 0, next: 0, opened: null, ended: false, won: false, last: null };
    // cold → heat (preheating) → hot (ready for dough) → burnt; with dough: raw → ready (golden) → over → burnt.
    game.stage = (o, now) => {
      if (o === null) return "gone";
      if (o.lit == null) return "";
      if (o.dough == null) { const t = now - o.lit; return t < heat ? "heat" : t < empty ? "hot" : "burnt"; }
      const t = now - Math.max(o.dough, o.lit);
      return t < bake ? "raw" : t < bake + ready ? "ready" : t < bake + ready + over ? "over" : "burnt";
    };
    // How far the oven's dial has turned, 0–1: the bake once there is dough, else how close the empty oven is to burning.
    game.dial = (o, now) => !o || o.lit == null ? 0 : Math.min(1, o.dough == null ? (now - o.lit) / empty : (now - Math.max(o.dough, o.lit)) / (bake + ready + over));
    const lost = (o) => o === null;
    const want = () => ["plain", "chip", "cream", "both"][Math.floor(random() * 4)];
    game.open = (now) => { if (game.opened != null) return; game.opened = now; game.next = now; game.update(now); };
    // Guests come and go with the clock.
    game.update = (now) => {
      if (game.ended || game.opened == null) return;
      for (const g of game.queue.slice()) {
        if (now - g.came < patience) continue;
        game.queue.splice(game.queue.indexOf(g), 1); game.left++; game.hearts--;
        game.last = { line: "너무 오래 기다렸어… 갈래!", price: null, gone: true, guest: g.id, want: g.want };
      }
      if (game.hearts <= 0) { game.ended = true; return; }
      if (!game.queue.length) game.next = Math.min(game.next, now + 1500);
      if (game.queue.length < 3 && now >= game.next) { game.queue.push({ id: game.guests++, want: want(), came: now }); game.next = now + every * (0.75 + random() * 0.5); }
    };
    game.shift = (dt) => {
      for (const o of game.ovens) if (o) { if (o.lit != null) o.lit += dt; if (o.dough != null) o.dough += dt; }
      for (const g of game.queue) g.came += dt;
      game.next += dt; if (game.opened != null) game.opened += dt;
    };
    game.use = (tool, i, now) => {
      const o = game.ovens[i];
      if (game.ended || lost(o)) return "";
      const st = game.stage(o, now);
      if (st === "burnt") {
        // A burnt oven is cleared with a spare, or gone for good.
        if (game.spares > 0) { game.spares--; game.ovens[i] = fresh(); return "cleared"; }
        game.ovens[i] = null;
        if (game.ovens.every(lost)) game.ended = true;
        return "gone";
      }
      if (tool === "butter") { if (o.butter || o.dough != null) return ""; o.butter = true; return "butter"; }
      if (tool === "fire") { if (o.lit != null) return ""; o.lit = now; return "fire"; }
      // Dough in a cold or still-heating oven bakes flat.
      if (tool === "dough") { if (o.dough != null) return ""; o.dough = now; o.flat = !(o.lit != null && now - o.lit >= heat); return "dough"; }
      if (tool === "sugar") { if (o.sugar || o.dough == null) return ""; o.sugar = true; return "sugar"; }
      if (tool === "chip" || tool === "cream") { if (o[tool] || o.dough == null || o.lit == null) return ""; o[tool] = st === "ready" ? "ontime" : st === "raw" ? "early" : "late"; return tool; }
      if (tool === "serve") {
        if (o.dough == null) return "";
        if (!game.queue.length) return "nobody";
        const kind = game.kind(o), guest = game.queue.find((g) => g.want === kind) || game.queue[0];
        const r = game.judge(o, st, guest.want, now - guest.came);
        game.queue.splice(game.queue.indexOf(guest), 1);
        game.money += r.price; game.tips += r.tip; game.served++; if (r.perfect) game.perfect++;
        game.last = { ...r, guest: guest.id, want: guest.want, oven: i };
        game.ovens[i] = fresh();
        if (game.money >= goal) game.ended = game.won = true;
        return "served";
      }
      return "";
    };
    game.kind = (o) => o.chip && o.cream ? "both" : o.chip ? "chip" : o.cream ? "cream" : "plain";
    // The price: 1,000 for a golden cookie made right, less for each slip; the worst slip is what the guest says.
    game.judge = (o, st, order, waited) => {
      if (o.lit == null) return { price: 0, tip: 0, perfect: false, line: "이건 그냥 반죽이잖아!" };
      const slips = [];
      if (st === "raw") slips.push([700, "덜 익었잖아!"]);
      if (st === "over") slips.push([400, "좀 딱딱한데?"]);
      if (!o.butter) slips.push([200, "바닥이 눌어붙었어."]);
      if (o.flat) slips.push([200, "납작하네… 예열은 했어?"]);
      if (!o.sugar) slips.push([300, "하나도 안 달아!"]);
      for (const [k, name] of [["chip", "초코칩"], ["cream", "크림"]]) {
        const wanted = order === k || order === "both";
        if (wanted && !o[k]) slips.push([250, name + "이 없잖아!"]);
        else if (!wanted && o[k]) slips.push([150, name + "은 안 시켰는데?"]);
        else if (o[k] === "early") slips.push([100, name + "이 녹아 버렸어."]);
        else if (o[k] === "late") slips.push([150, name + "을 너무 늦게 올렸네."]);
      }
      const price = Math.max(0, 1000 - slips.reduce((n, [loss]) => n + loss, 0));
      const tip = price >= 800 && waited < patience * 0.45 ? 200 : 0;
      slips.sort((a, b) => b[0] - a[0]);
      return { price: price + tip, tip, perfect: !slips.length, line: slips.length ? slips[0][1] : tip ? "빨리 나왔네! 아주 맛있어~!" : "아주 맛있어~!" };
    };
    return game;
  }
  // 디저트 핀볼: hold the launcher, then keep the ball up with the two flippers. Bumpers (100) and the slingshots above
  // the flippers (10) score; rolling over all three top lanes gives 500 and raises the multiplier (up to ×5, back to ×1
  // with each lost ball). A flipper press shifts the lit lanes. A ball lost within the ball-save time comes back, once.
  // step(ms) runs the physics in fixed 1/400 s steps, so it plays the same at any frame rate.
  function newPinballGame(random = Math.random, difficulty = "normal") {
    const [gravity, balls, len, save] = ({ easy: [560, 5, 50, 10000], normal: [680, 3, 46, 5000], hard: [800, 3, 42, 0] })[difficulty] || [680, 3, 46, 5000];
    const W = 320, H = 520, R = 7, LANE = 286, cx = 149;
    // The table's rim: the left wall, an elliptic roof, the outer right wall.
    const rim = [[12, 470], [12, 90]];
    for (let k = 1; k < 24; k++) { const a = Math.PI + Math.PI * k / 24; rim.push([160 + 148 * Math.cos(a), 90 + 80 * Math.sin(a)]); }
    rim.push([308, 90], [308, 510]);
    const walls = [];
    for (let k = 1; k < rim.length; k++) walls.push([...rim[k - 1], ...rim[k]]);
    walls.push([LANE, 510, LANE, 150], [LANE, 490, 308, 490], // the launch lane and the plunger
      [12, 392, 90, 447], [LANE, 392, 208, 447], // the inlane guides down to the flippers
      [40, 330, 40, 372], [40, 372, 78, 398], [258, 330, 258, 372], [258, 372, 220, 398], // the slingshots' backs
      [130, 50, 130, 84], [170, 50, 170, 84], [90, 54, 90, 84], [210, 54, 210, 84]); // the top lane posts
    const slings = [[40, 330, 78, 398], [258, 330, 220, 398]].map((s) => ({ s, flash: 0 }));
    const gate = [LANE, 150, LANE, 96];
    const flipper = (side) => ({ side, x: side < 0 ? cx - 56 : cx + 56, y: 455, len, rest: side < 0 ? 0.5 : Math.PI - 0.5, up: side < 0 ? -0.45 : Math.PI + 0.45, a: 0, w: 0, held: false });
    const flippers = [flipper(-1), flipper(1)];
    flippers.forEach((f) => { f.a = f.rest; });
    const bumpers = [[110, 170, 16], [190, 170, 16], [150, 236, 18]].map(([x, y, r]) => ({ x, y, r, flash: 0 }));
    const lanes = [110, 150, 190].map((x) => ({ x, y: 70, lit: false }));
    const game = { W, H, R, LANE, cx, rim, walls, slings, gate, flippers, bumpers, lanes, gravity, save, balls, score: 0, mult: 1, top: 1, ball: null, charge: 0, pulling: false,
      launched: 0, saved: false, clock: 0, popups: [], note: null, ended: false, won: false };
    // A new ball (or a saved one, which keeps its ball save used up) waits on the plunger.
    const toLane = (saved = false) => { game.ball = { x: 297, y: 490 - R - 0.5, vx: 0, vy: 0, lane: true }; game.charge = 0; game.pulling = false; game.launched = 0; game.saved = saved; };
    toLane();
    const add = (n, x, y) => { const v = n * game.mult; game.score += v; game.popups.push({ text: "+" + v, x, y, t: 0 }); };
    game.press = (side, down) => {
      const f = flippers[side < 0 ? 0 : 1];
      if (down && !f.held && !game.ended) { const lit = lanes.map((l) => l.lit); lanes.forEach((l, k) => { l.lit = lit[(k + (side < 0 ? 1 : 2)) % 3]; }); }
      f.held = down;
    };
    game.pull = (down) => {
      const b = game.ball;
      if (down) { if (b.lane && b.y > 460 && !game.ended) game.pulling = true; return; }
      if (!game.pulling) return;
      game.pulling = false;
      // Even a tap clears the lane; holding longer shoots harder.
      if (b.lane && b.y > 460) { b.vy = -(Math.sqrt(2 * gravity * 440) + 420 * game.charge); if (!game.launched) game.launched = game.clock; }
      game.charge = 0;
    };
    // Push the ball out of a segment of half-thickness t; e is the bounce, (sx, sy) the surface's own velocity.
    const hitSegment = (b, x1, y1, x2, y2, t, e, sx = 0, sy = 0) => {
      const dx = x2 - x1, dy = y2 - y1, l2 = dx * dx + dy * dy;
      const k = Math.max(0, Math.min(1, ((b.x - x1) * dx + (b.y - y1) * dy) / l2));
      const px = x1 + k * dx, py = y1 + k * dy;
      let nx = b.x - px, ny = b.y - py; const d = Math.hypot(nx, ny);
      if (d >= R + t || d === 0) return null;
      nx /= d; ny /= d;
      b.x = px + nx * (R + t); b.y = py + ny * (R + t);
      const vn = (b.vx - sx) * nx + (b.vy - sy) * ny;
      if (vn < 0) { b.vx -= (1 + e) * vn * nx; b.vy -= (1 + e) * vn * ny; }
      return { nx, ny, px, py };
    };
    const tick = (dt) => {
      const b = game.ball;
      game.clock += dt * 1000;
      if (game.pulling) game.charge = Math.min(1, game.charge + dt);
      for (const f of flippers) {
        const target = f.held ? f.up : f.rest, speed = (f.held ? 20 : 11) * dt, before = f.a;
        f.a = Math.abs(target - f.a) <= speed ? target : f.a + Math.sign(target - f.a) * speed;
        f.w = (f.a - before) / dt;
      }
      b.vy += gravity * dt;
      const v = Math.hypot(b.vx, b.vy);
      if (v > 1100) { b.vx *= 1100 / v; b.vy *= 1100 / v; }
      b.x += b.vx * dt; b.y += b.vy * dt;
      b.lane = b.x > LANE;
      for (const s of walls) hitSegment(b, ...s, 3, 0.45);
      if (!b.lane) hitSegment(b, ...gate, 3, 0.45);
      for (const sl of slings) {
        const h = hitSegment(b, ...sl.s, 3, 0.5);
        if (h && b.vx * h.nx + b.vy * h.ny < 260) { b.vx += h.nx * 260; b.vy += h.ny * 260; sl.flash = 0.18; add(10, h.px, h.py); }
      }
      for (const f of flippers) {
        const tx = f.x + Math.cos(f.a) * f.len, ty = f.y + Math.sin(f.a) * f.len;
        // The flipper's surface moves with it: w × r at the closest point.
        const dx = tx - f.x, dy = ty - f.y, k = Math.max(0, Math.min(1, ((b.x - f.x) * dx + (b.y - f.y) * dy) / (dx * dx + dy * dy)));
        const rx = dx * k, ry = dy * k;
        hitSegment(b, f.x, f.y, tx, ty, 5.5, 0.3, -f.w * ry, f.w * rx);
      }
      for (const p of bumpers) {
        let nx = b.x - p.x, ny = b.y - p.y; const d = Math.hypot(nx, ny);
        if (d >= p.r + R || d === 0) continue;
        nx /= d; ny /= d; b.x = p.x + nx * (p.r + R); b.y = p.y + ny * (p.r + R);
        const vn = b.vx * nx + b.vy * ny, out = Math.max(380, -vn * 0.9);
        b.vx += (out - vn) * nx; b.vy += (out - vn) * ny;
        p.flash = 0.2; add(100, p.x, p.y - p.r);
      }
      for (const l of lanes) {
        if (l.lit || Math.hypot(b.x - l.x, b.y - l.y) > 10) continue;
        l.lit = true; add(50, l.x, l.y - 8);
        if (lanes.every((x) => x.lit)) { add(500, cx, 110); game.mult = Math.min(5, game.mult + 1); game.top = Math.max(game.top, game.mult); game.note = { text: "×" + game.mult + " 배수!", t: 0 }; lanes.forEach((x) => { x.lit = false; }); }
      }
      if (b.y > H + R) {
        if (!game.saved && game.launched && game.clock - game.launched < save) { game.note = { text: "볼 세이브!", t: 0 }; toLane(true); return; }
        game.balls--; game.mult = 1;
        if (game.balls <= 0) { game.ended = true; b.y = H + 40; b.vx = b.vy = 0; return; }
        game.note = { text: "남은 공 " + game.balls, t: 0 }; toLane();
      }
    };
    game.step = (ms) => {
      if (game.ended) return;
      const n = Math.max(1, Math.round(Math.min(ms, 50) / 2.5));
      for (let k = 0; k < n && !game.ended; k++) tick(Math.min(ms, 50) / 1000 / n);
      const s = Math.min(ms, 50) / 1000;
      bumpers.forEach((p) => { p.flash = Math.max(0, p.flash - s); }); slings.forEach((p) => { p.flash = Math.max(0, p.flash - s); });
      game.popups = game.popups.filter((p) => (p.t += s) < 0.8);
      if (game.note && (game.note.t += s) > 1.6) game.note = null;
    };
    return game;
  }
  /* 쿠키 가게 drawings: sticker-outlined SVG, solid fills. Static markup only; the game state is set as data-*
   * attributes on the wrapping element and the CSS shows, hides and recolours the parts. */
  const SHOP_COOKIE_SVG = (kind) => '<svg viewBox="0 0 40 36" aria-hidden="true">'
    + '<ellipse cx="20" cy="31" rx="14" ry="2.5" fill="#6B4528" opacity=".18"/>'
    + '<path d="M5 21c0-7 7-11 15-11s15 4 15 11-7 9-15 9-15-2-15-9Z" fill="#E7A552" stroke="#6B3A14" stroke-width="2.4" stroke-linejoin="round"/>'
    + '<path d="M10 20q3-2 6 0M24 18q3-2 6 1M17 25q3-1 6 0" fill="none" stroke="#B5722F" stroke-width="1.5" stroke-linecap="round"/>'
    + (kind === 'chip' || kind === 'both' ? '<g fill="#3E2616"><ellipse cx="12" cy="24" rx="2.2" ry="1.7"/><ellipse cx="27" cy="23" rx="2.2" ry="1.7"/><ellipse cx="20" cy="27" rx="2" ry="1.5"/><ellipse cx="30" cy="18" rx="1.8" ry="1.4"/><ellipse cx="9" cy="17" rx="1.8" ry="1.4"/></g>' : '')
    + (kind === 'cream' || kind === 'both' ? '<path d="M12 17c0-4 3-6 5-7 0-3 2-5 3-7 1 2 3 4 3 7 2 1 5 3 5 7-3 2-13 2-16 0Z" fill="#fff" stroke="#C99F7E" stroke-width="2" stroke-linejoin="round"/><path d="M15 14q5 2 10 0" fill="none" stroke="#E8D3BE" stroke-width="1.4" stroke-linecap="round"/>' : '')
    + '<path d="M9 15q3-3 7-4" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" opacity=".55"/></svg>';
  // One oven: control panel (knob, dial, lamp), the glass door with the tray, the cookie, steam and smoke.
  const SHOP_OVEN_SVG = (zones) => '<svg viewBox="0 0 100 124" aria-hidden="true">'
    + '<rect class="ov-foot" x="14" y="114" width="14" height="8" rx="3"/><rect class="ov-foot" x="72" y="114" width="14" height="8" rx="3"/>'
    + '<rect class="ov-body" x="4" y="6" width="92" height="110" rx="14"/>'
    + '<path class="ov-top" d="M4 34V20A14 14 0 0 1 18 6h64a14 14 0 0 1 14 14v14Z"/>'
    + '<g class="ov-knob"><circle cx="18" cy="20" r="7.5"/><path d="M18 20v-6"/></g>'
    + '<g class="ov-dial"><circle class="dial-face" cx="50" cy="22" r="11"/>' + zones + '<path class="needle" d="M50 22v-9"/><circle class="hub" cx="50" cy="22" r="2.2"/></g>'
    + '<circle class="ov-lamp" cx="82" cy="20" r="5"/>'
    + '<rect class="ov-door" x="11" y="40" width="78" height="70" rx="10"/>'
    + '<rect class="ov-glass" x="17" y="46" width="66" height="44" rx="7"/>'
    + '<g class="ov-fire"><path d="M28 88c-3-4 0-6 2-9 1 3 4 4 2 9Z"/><path d="M40 88c-3-4 0-7 2-10 1 3 4 5 2 10Z"/><path d="M52 88c-3-4 0-7 2-10 1 3 4 5 2 10Z"/><path d="M64 88c-3-4 0-6 2-9 1 3 4 4 2 9Z"/></g>'
    + '<path class="ov-coil" d="M21 84l4-3 4 3 4-3 4 3 4-3 4 3 4-3 4 3 4-3 4 3 4-3 4 3 4-3 4 3"/>'
    + '<rect class="ov-tray" x="23" y="75" width="54" height="4.5" rx="2"/>'
    + '<g class="ov-butter"><rect x="41" y="68" width="18" height="7.5" rx="2"/><path d="M44 70.5h7"/></g><ellipse class="ov-melt" cx="50" cy="74.6" rx="20" ry="2.3"/>'
    + '<g class="ov-cookie"><ellipse class="ck-ball" cx="50" cy="67" rx="14" ry="9"/>'
    + '<path class="ck-disc" d="M28 70c0-5 10-8 22-8s22 3 22 8-10 6-22 6-22-1-22-6Z"/><path class="ck-crack" d="M35 68q4-2 7 0M53 66q3-2 7 1M44 72q3-1 6 0"/>'
    + '<g class="ck-sugar"><circle cx="38" cy="65" r="1"/><circle cx="46" cy="63" r="1"/><circle cx="57" cy="64" r="1"/><circle cx="63" cy="68" r="1"/><circle cx="41" cy="71" r="1"/></g>'
    + '<g class="ck-chip"><ellipse cx="38" cy="68" rx="2.6" ry="1.9"/><ellipse cx="49" cy="65" rx="2.6" ry="1.9"/><ellipse cx="61" cy="68" rx="2.6" ry="1.9"/><ellipse cx="54" cy="72" rx="2.3" ry="1.6"/><ellipse cx="43" cy="72.5" rx="2.2" ry="1.5"/></g>'
    + '<g class="ck-cream"><path d="M41 66c0-4 4-5 6-6 0-3 2-5 3-7 1 2 3 4 3 7 2 1 6 2 6 6-4 2-14 2-18 0Z"/><path d="M44 63q6 2 12 0"/></g></g>'
    + '<g class="ov-steam"><path d="M38 60c-3-3 3-6 0-10"/><path d="M50 57c-3-3 3-6 0-10"/><path d="M62 60c-3-3 3-6 0-10"/></g>'
    + '<g class="ov-smoke"><circle cx="40" cy="58" r="6"/><circle cx="52" cy="53" r="8"/><circle cx="63" cy="59" r="5.5"/></g>'
    + '<path class="ov-shine" d="M22 52q3-3 8-3"/>'
    + '<rect class="ov-handle" x="24" y="97" width="52" height="6" rx="3"/></svg>';
  // The tools on the shelf.
  const SHOP_TOOL_SVG = {
    butter: '<path d="M8 22 22 14l14 6v8L22 36 8 30Z" fill="#FFE07A" stroke="#7A5A10" stroke-width="2.4" stroke-linejoin="round"/><path d="M8 22l14 6 14-8M22 28v8" fill="none" stroke="#7A5A10" stroke-width="2.4" stroke-linejoin="round"/><path d="M12 22l10-5" stroke="#fff" stroke-width="2" stroke-linecap="round" opacity=".7"/>',
    fire: '<path d="M22 38c-8 0-12-5-12-11 0-7 6-10 7-17 3 3 4 6 4 9 2-2 3-5 3-8 5 4 10 9 10 16 0 6-4 11-12 11Z" fill="#FF8A3D" stroke="#8A3410" stroke-width="2.4" stroke-linejoin="round"/><path d="M22 37c-4 0-6-2-6-5 0-4 4-5 5-9 3 3 7 5 7 9 0 3-2 5-6 5Z" fill="#FFD84D"/>',
    dough: '<path d="M6 24h32l-3 12c-1 2-2 3-4 3H13c-2 0-3-1-4-3Z" fill="#9CC9F5" stroke="#2C4F78" stroke-width="2.4" stroke-linejoin="round"/><path d="M10 24c0-6 5-10 12-10s12 4 12 10Z" fill="#F6DFAE" stroke="#9A7440" stroke-width="2.4" stroke-linejoin="round"/><path d="M15 19q3-2 6-2" stroke="#fff" stroke-width="2" stroke-linecap="round" fill="none"/><path d="M4 24h36" stroke="#2C4F78" stroke-width="2.4" stroke-linecap="round"/>',
    sugar: '<rect x="11" y="13" width="22" height="25" rx="5" fill="#fff" stroke="#6B4528" stroke-width="2.4"/><rect x="13" y="7" width="18" height="7" rx="2" fill="#F7A8C4" stroke="#6B4528" stroke-width="2.4"/><g fill="#C8B9A8"><rect x="16" y="24" width="4" height="4" rx="1"/><rect x="23" y="27" width="4" height="4" rx="1"/><rect x="18" y="31" width="4" height="4" rx="1"/></g><path d="M15 18v6" stroke="#E9E0D5" stroke-width="2" stroke-linecap="round"/>',
    chip: '<path d="M10 12h24l-2 26H12Z" fill="#C2803F" stroke="#4A2A12" stroke-width="2.4" stroke-linejoin="round"/><path d="M10 12l3-5h18l3 5" fill="#E9B26B" stroke="#4A2A12" stroke-width="2.4" stroke-linejoin="round"/><g fill="#3E2616"><path d="M17 22l3-4 3 4Z"/><path d="M22 30l3-4 3 4Z"/><path d="M14 32l3-4 3 4Z"/></g>',
    cream: '<path d="M14 6h16l-4 22h-8Z" fill="#FFF6EC" stroke="#9A7A62" stroke-width="2.4" stroke-linejoin="round"/><path d="M18 28h8l-2 6h-4Z" fill="#C9D0D8" stroke="#5C646E" stroke-width="2.4" stroke-linejoin="round"/><path d="M15 38c2-3 5-3 7-3s5 0 7 3" fill="#fff" stroke="#C99F7E" stroke-width="2.2" stroke-linecap="round"/><path d="M18 10l2 12" stroke="#fff" stroke-width="2" stroke-linecap="round"/>',
    serve: '<ellipse cx="22" cy="27" rx="18" ry="8" fill="#fff" stroke="#6B4528" stroke-width="2.4"/><ellipse cx="22" cy="26" rx="11" ry="4.5" fill="none" stroke="#9CC9F5" stroke-width="2"/><path d="M8 25q2-3 6-4" stroke="#E5EEF6" stroke-width="2" stroke-linecap="round" fill="none"/>',
  };
  // A guest drawn when there are no SD sprites: hair and clothes vary by guest; the face follows the mood.
  const SHOP_GUEST_SVG = '<svg viewBox="0 0 60 72" aria-hidden="true">'
    + '<path class="g-body" d="M9 72c0-15 9-22 21-22s21 7 21 22Z"/><path class="g-collar" d="M23 51l7 7 7-7"/>'
    + '<path class="g-back" d="M12 34c0-14 8-21 18-21s18 7 18 21c0 8-3 12-3 12H15s-3-4-3-12Z"/>'
    + '<circle class="g-head" cx="30" cy="31" r="16"/>'
    + '<path class="g-hair" d="M13 31c0-12 8-18 17-18s17 6 17 18c-3-5-7-8-11-8-1 3-4 5-7 5 1-2 1-4 0-5-6 1-12 3-16 8Z"/>'
    + '<g class="g-eyes"><ellipse cx="24" cy="33" rx="2" ry="2.6"/><ellipse cx="36" cy="33" rx="2" ry="2.6"/></g>'
    + '<path class="g-brow" d="M20 27l6 2M40 27l-6 2"/>'
    + '<circle class="g-cheek" cx="20" cy="38" r="2.6"/><circle class="g-cheek" cx="40" cy="38" r="2.6"/>'
    + '<path class="g-mouth m-happy" d="M26 39q4 4 8 0"/><path class="g-mouth m-flat" d="M27 40h6"/><path class="g-mouth m-angry" d="M26 41q4-3 8 0"/></svg>';
  const SHOP_GUEST_LOOKS = [['#6B4528', '#F7A8C4'], ['#2D2A3A', '#9CC9F5'], ['#E9B26B', '#8FDDBA'], ['#B5523A', '#FFE07A'], ['#8C6CF0', '#FFD3E0'], ['#3E5A8A', '#FFC27A']];
  // 비스킷 벽돌깨기: bounce the gumball off the spatula into rows of biscuits. Where it meets the spatula sets the angle.
  // Chocolate biscuits (the top row from 보통 on) take two hits. A broken biscuit may drop a treat: a long spatula for
  // a while, or a heart. Clear the tray for the next stage, a little faster; lose the ball with no hearts left and it is
  // over. step(ms) runs in fixed 1/400 s steps, so it plays the same at any frame rate.
  function newBrickGame(random = Math.random, difficulty = "normal") {
    const [width, speed, lives, choco] = ({ easy: [72, 250, 5, 0], normal: [58, 290, 3, 1], hard: [48, 330, 3, 2] })[difficulty] || [58, 290, 3, 1];
    const W = 320, H = 420, R = 6, PY = 392, COLS = 8, BW = 34, BH = 15, GAP = 3, LEFT = (W - COLS * BW - (COLS - 1) * GAP) / 2, TOP = 46;
    const game = { W, H, R, PY, BW, BH, stage: 1, speed, lives, score: 0, bricks: [], items: [], popups: [], note: null,
      paddle: { x: W / 2, w: width, target: null, dir: 0, long: 0 }, ball: null, ended: false, won: false, broken: 0 };
    const lay = () => {
      const rows = Math.min(8, 4 + game.stage);
      game.bricks = [];
      for (let r = 0; r < rows; r++) for (let c = 0; c < COLS; c++) {
        // Later stages leave a gap pattern so the trays differ.
        if (game.stage > 1 && (r + c * (game.stage % 3 + 1)) % 7 === 0) continue;
        const hp = r < choco + (game.stage > 2 ? 1 : 0) ? 2 : 1;
        game.bricks.push({ x: LEFT + c * (BW + GAP), y: TOP + r * (BH + GAP), row: r, hp, max: hp });
      }
    };
    const serve = () => { game.ball = { x: game.paddle.x, y: PY - R - 1, vx: 0, vy: 0, stuck: true }; };
    lay(); serve();
    const add = (n, x, y) => { game.score += n; game.popups.push({ text: "+" + n, x, y, t: 0 }); };
    game.launch = () => {
      const b = game.ball;
      if (!b.stuck || game.ended) return;
      const a = (random() - 0.5) * 0.8;
      b.stuck = false; b.vx = Math.sin(a) * game.speed; b.vy = -Math.cos(a) * game.speed;
    };
    game.move = (dir) => { game.paddle.dir = dir; game.paddle.target = null; };
    game.aim = (x) => { game.paddle.target = x; };
    const tick = (dt) => {
      const p = game.paddle, b = game.ball, half = (p.long > 0 ? p.w * 1.5 : p.w) / 2;
      if (p.target != null) p.x += Math.max(-700 * dt, Math.min(700 * dt, p.target - p.x));
      else p.x += p.dir * 420 * dt;
      p.x = Math.max(half + 4, Math.min(W - half - 4, p.x));
      if (b.stuck) { b.x = p.x; return; }
      b.x += b.vx * dt; b.y += b.vy * dt;
      if (b.x < R + 4) { b.x = R + 4; b.vx = Math.abs(b.vx); }
      if (b.x > W - R - 4) { b.x = W - R - 4; b.vx = -Math.abs(b.vx); }
      if (b.y < R + 4) { b.y = R + 4; b.vy = Math.abs(b.vy); }
      // The spatula: the farther from its middle, the steeper the bounce.
      if (b.vy > 0 && b.y + R >= PY && b.y - R <= PY + 10 && Math.abs(b.x - p.x) <= half + R) {
        const off = Math.max(-1, Math.min(1, (b.x - p.x) / half)), a = off * 1.05, v = Math.min(game.speed * 1.6, Math.hypot(b.vx, b.vy) * 1.004);
        b.vx = Math.sin(a) * v; b.vy = -Math.cos(a) * v; b.y = PY - R; game.bounces = (game.bounces || 0) + 1;
      }
      // Biscuits: bounce off the side that was hit least deep.
      for (const k of game.bricks) {
        if (k.hp <= 0) continue;
        const cx = Math.max(k.x, Math.min(b.x, k.x + BW)), cy = Math.max(k.y, Math.min(b.y, k.y + BH));
        if ((b.x - cx) ** 2 + (b.y - cy) ** 2 > R * R) continue;
        const ox = Math.min(b.x + R - k.x, k.x + BW - (b.x - R)), oy = Math.min(b.y + R - k.y, k.y + BH - (b.y - R));
        if (ox < oy) b.vx = b.x < k.x + BW / 2 ? -Math.abs(b.vx) : Math.abs(b.vx);
        else b.vy = b.y < k.y + BH / 2 ? -Math.abs(b.vy) : Math.abs(b.vy);
        k.hp--; k.hit = 0.15;
        if (k.hp > 0) { add(5, k.x + BW / 2, k.y); break; }
        game.broken++; add(10 * game.stage + (k.max > 1 ? 20 : 0), k.x + BW / 2, k.y);
        if (random() < 0.09) game.items.push({ kind: random() < 0.7 ? "long" : "heart", x: k.x + BW / 2, y: k.y + BH / 2 });
        break;
      }
      game.bricks = game.bricks.filter((k) => k.hp > 0);
      if (!game.bricks.length) {
        add(100 * game.stage, W / 2, 200); game.stage++; game.speed *= 1.08; game.items = [];
        game.note = { text: "스테이지 " + game.stage + "!", t: 0 }; lay(); serve(); return;
      }
      if (b.y > H + R) {
        game.lives--; p.long = 0; game.items = [];
        if (game.lives <= 0) { game.ended = true; return; }
        game.note = { text: "남은 하트 " + game.lives, t: 0 }; serve();
      }
    };
    game.step = (ms) => {
      if (game.ended) return;
      const s = Math.min(ms, 50) / 1000, n = Math.max(1, Math.round(s / 0.0025));
      for (let k = 0; k < n && !game.ended; k++) tick(s / n);
      const p = game.paddle, half = (p.long > 0 ? p.w * 1.5 : p.w) / 2;
      p.long = Math.max(0, p.long - s);
      // Treats fall; the spatula catches them.
      game.items = game.items.filter((it) => {
        it.y += 110 * s;
        if (it.y >= PY - 6 && it.y <= PY + 12 && Math.abs(it.x - p.x) <= half + 8) {
          if (it.kind === "long") { p.long = 12; game.note = { text: "길쭉 뒤집개!", t: 0 }; } else { game.lives = Math.min(9, game.lives + 1); game.note = { text: "하트 +1", t: 0 }; }
          return false;
        }
        return it.y < H + 10;
      });
      game.bricks.forEach((k) => { if (k.hit) k.hit = Math.max(0, k.hit - s); });
      game.popups = game.popups.filter((q) => (q.t += s) < 0.8);
      if (game.note && (game.note.t += s) > 1.6) game.note = null;
    };
    return game;
  }
  // 젤리 블록, in the manner of Block Blast: three pieces wait in the tray; drag each onto the board. A full row or
  // column melts away. Points: one per square placed, plus 10 × lines² per clear, plus 20 a step of combo (clears that
  // follow one another within three placements), and 300 for emptying the board. When none of the waiting pieces
  // fits anywhere, it is over.
  const BLOCK_SHAPES = [
    // [weight on easy, normal, hard], cells as [row, col]
    [[3, 2, 1], [[0, 0]]],
    [[3, 2, 2], [[0, 0], [0, 1]]], [[3, 2, 2], [[0, 0], [1, 0]]],
    [[2, 2, 2], [[0, 0], [0, 1], [0, 2]]], [[2, 2, 2], [[0, 0], [1, 0], [2, 0]]],
    [[1, 2, 2], [[0, 0], [0, 1], [0, 2], [0, 3]]], [[1, 2, 2], [[0, 0], [1, 0], [2, 0], [3, 0]]],
    [[0, 1, 2], [[0, 0], [0, 1], [0, 2], [0, 3], [0, 4]]], [[0, 1, 2], [[0, 0], [1, 0], [2, 0], [3, 0], [4, 0]]],
    [[3, 3, 2], [[0, 0], [0, 1], [1, 0], [1, 1]]],
    [[0, 1, 2], [[0, 0], [0, 1], [0, 2], [1, 0], [1, 1], [1, 2], [2, 0], [2, 1], [2, 2]]],
    [[1, 1, 1], [[0, 0], [0, 1], [0, 2], [1, 0], [1, 1], [1, 2]]], [[1, 1, 1], [[0, 0], [0, 1], [1, 0], [1, 1], [2, 0], [2, 1]]],
    // small corners
    [[2, 1, 1], [[0, 0], [1, 0], [1, 1]]], [[2, 1, 1], [[0, 1], [1, 0], [1, 1]]], [[2, 1, 1], [[0, 0], [0, 1], [1, 0]]], [[2, 1, 1], [[0, 0], [0, 1], [1, 1]]],
    // L and J
    [[1, 1, 1], [[0, 0], [1, 0], [2, 0], [2, 1]]], [[1, 1, 1], [[0, 1], [1, 1], [2, 1], [2, 0]]], [[1, 1, 1], [[0, 0], [0, 1], [0, 2], [1, 0]]], [[1, 1, 1], [[0, 0], [0, 1], [0, 2], [1, 2]]],
    [[1, 1, 1], [[0, 0], [0, 1], [1, 1], [2, 1]]], [[1, 1, 1], [[0, 0], [0, 1], [1, 0], [2, 0]]], [[1, 1, 1], [[1, 0], [1, 1], [1, 2], [0, 2]]], [[1, 1, 1], [[1, 0], [1, 1], [1, 2], [0, 0]]],
    // T
    [[1, 1, 1], [[0, 0], [0, 1], [0, 2], [1, 1]]], [[1, 1, 1], [[1, 0], [1, 1], [1, 2], [0, 1]]], [[1, 1, 1], [[0, 0], [1, 0], [2, 0], [1, 1]]], [[1, 1, 1], [[0, 1], [1, 1], [2, 1], [1, 0]]],
    // S and Z
    [[0, 1, 1], [[0, 1], [0, 2], [1, 0], [1, 1]]], [[0, 1, 1], [[0, 0], [0, 1], [1, 1], [1, 2]]], [[0, 1, 1], [[0, 0], [1, 0], [1, 1], [2, 1]]], [[0, 1, 1], [[0, 1], [1, 1], [1, 0], [2, 0]]],
    // big corners
    [[0, 1, 2], [[0, 0], [1, 0], [2, 0], [2, 1], [2, 2]]], [[0, 1, 2], [[0, 0], [0, 1], [0, 2], [1, 0], [2, 0]]], [[0, 1, 2], [[0, 0], [0, 1], [0, 2], [1, 2], [2, 2]]], [[0, 1, 2], [[0, 2], [1, 2], [2, 2], [2, 1], [2, 0]]],
  ];
  function newBlockGame(random = Math.random, difficulty = "normal") {
    const n = ({ easy: 9, normal: 8, hard: 8 })[difficulty] || 8, lv = ({ easy: 0, normal: 1, hard: 2 })[difficulty] ?? 1;
    const pool = BLOCK_SHAPES.filter(([w]) => w[lv] > 0), total = pool.reduce((s, [w]) => s + w[lv], 0);
    const game = { cols: n, rows: n, cells: Array(n * n).fill(0), tray: [], score: 0, combo: 0, since: 0, lines: 0, placed: 0, ended: false, won: false, last: null };
    const draw = () => {
      let r = random() * total;
      for (const [w, cells] of pool) { if ((r -= w[lv]) < 0) return cells; }
      return pool[0][1];
    };
    const piece = () => { const cells = draw(); return { cells, h: Math.max(...cells.map((c) => c[0])) + 1, w: Math.max(...cells.map((c) => c[1])) + 1, color: 1 + Math.floor(random() * 7) }; };
    const deal = () => { game.tray = [piece(), piece(), piece()]; };
    game.fits = (p, row, col) => !!p && p.cells.every(([r, c]) => r + row >= 0 && r + row < n && c + col >= 0 && c + col < n && !game.cells[(r + row) * n + c + col]);
    game.canPlace = (p) => { for (let r = 0; r <= n - p.h; r++) for (let c = 0; c <= n - p.w; c++) if (game.fits(p, r, c)) return true; return false; };
    // The rows and columns a piece at (row, col) would fill, for the preview.
    game.wouldClear = (p, row, col) => {
      const filled = new Set(p.cells.map(([r, c]) => (r + row) * n + c + col)), full = (i) => game.cells[i] || filled.has(i), out = new Set();
      for (let k = 0; k < n; k++) {
        const row = Array.from({ length: n }, (_, j) => k * n + j), column = Array.from({ length: n }, (_, j) => j * n + k);
        if (row.every(full)) row.forEach((i) => out.add(i));
        if (column.every(full)) column.forEach((i) => out.add(i));
      }
      return out;
    };
    game.place = (t, row, col) => {
      const p = game.tray[t];
      if (game.ended || !game.fits(p, row, col)) return null;
      const at = p.cells.map(([r, c]) => (r + row) * n + c + col);
      at.forEach((i) => { game.cells[i] = p.color; });
      game.tray[t] = null; game.placed++;
      let lines = 0; const gone = new Set();
      for (let k = 0; k < n; k++) {
        const row = Array.from({ length: n }, (_, j) => k * n + j), column = Array.from({ length: n }, (_, j) => j * n + k);
        if (row.every((i) => game.cells[i])) { lines++; row.forEach((i) => gone.add(i)); }
        if (column.every((i) => game.cells[i])) { lines++; column.forEach((i) => gone.add(i)); }
      }
      const melted = [...gone].map((i) => [i, game.cells[i]]);
      gone.forEach((i) => { game.cells[i] = 0; });
      let gain = at.length;
      if (lines) {
        game.combo = game.since < 3 && game.lines ? game.combo + 1 : 1; game.since = 0;
        gain += 10 * lines * lines + 20 * (game.combo - 1);
      } else if (++game.since >= 3) game.combo = 0;
      const clean = lines > 0 && game.cells.every((v) => !v);
      if (clean) gain += 300;
      game.lines += lines; game.score += gain;
      game.last = { at, melted, lines, gain, combo: lines ? game.combo : 0, clean };
      if (game.tray.every((x) => !x)) deal();
      if (!game.tray.some((x) => x && game.canPlace(x))) game.ended = true;
      return game.last;
    };
    deal();
    return game;
  }
  // 스네이크: eat, grow, never touch a wall or yourself.
  function newSnakeGame(random = Math.random, difficulty = "normal") {
    const [n, speed] = ({ easy: [12, 170], normal: [15, 125], hard: [18, 90] })[difficulty] || [15, 125];
    const mid = Math.floor(n / 2) * n + Math.floor(n / 2);
    const game = { cols: n, rows: n, speed, body: [mid, mid - 1, mid - 2], dir: "right", queue: [], food: -1, score: 0, ended: false, won: false };
    const placeFood = () => {
      const taken = new Set(game.body), free = [];
      for (let i = 0; i < n * n; i++) if (!taken.has(i)) free.push(i);
      if (!free.length) { game.ended = game.won = true; game.food = -1; return; }
      game.food = free[Math.floor(random() * free.length)];
    };
    const OPPOSITE = { up: "down", down: "up", left: "right", right: "left" };
    game.turn = (dir) => {
      const last = game.queue.length ? game.queue[game.queue.length - 1] : game.dir;
      if (!OPPOSITE[dir] || dir === last || dir === OPPOSITE[last] || game.queue.length >= 2) return false;
      game.queue.push(dir); return true;
    };
    game.step = () => {
      if (game.ended) return;
      if (game.queue.length) game.dir = game.queue.shift();
      const head = game.body[0], x = head % n, y = Math.floor(head / n);
      const [nx, ny] = game.dir === "up" ? [x, y - 1] : game.dir === "down" ? [x, y + 1] : game.dir === "left" ? [x - 1, y] : [x + 1, y];
      if (nx < 0 || ny < 0 || nx >= n || ny >= n) { game.ended = true; return; }
      const next = ny * n + nx, eats = next === game.food;
      // Moving into the cell the tail leaves this step is allowed.
      const blocking = eats ? game.body : game.body.slice(0, -1);
      if (blocking.includes(next)) { game.ended = true; return; }
      game.body.unshift(next);
      if (eats) { game.score++; placeFood(); } else game.body.pop();
    };
    placeFood();
    return game;
  }
  // 딸기 우유 · 레시피: the ingredients light up in order; press them back. Each round adds one more.
  function newRecipeGame(random = Math.random, difficulty = "normal") {
    const [pads, speed] = ({ easy: [4, 700], normal: [4, 520], hard: [6, 420] })[difficulty] || [4, 520];
    const game = { pads, speed, sequence: [], at: 0, round: 0, ended: false };
    game.next = () => { game.sequence.push(Math.floor(random() * pads)); game.at = 0; };
    game.press = (i) => {
      if (game.ended) return "ended";
      if (game.sequence[game.at] !== i) { game.ended = true; return "fail"; }
      game.at++;
      if (game.at < game.sequence.length) return "ok";
      game.round++; game.next(); return "round";
    };
    game.next();
    return game;
  }
  // 민트 초코 · 초코칩 터뜨리기: press a group of two or more touching chips of one colour; the rest fall and close up.
  function newPopGame(random = Math.random, difficulty = "normal") {
    const [cols, rows, colours] = ({ easy: [8, 6, 3], normal: [10, 8, 4], hard: [12, 9, 5] })[difficulty] || [10, 8, 4];
    const cells = Array.from({ length: cols * rows }, () => 1 + Math.floor(random() * colours));
    const game = { cols, rows, colours, cells, score: 0, ended: false, won: false };
    game.group = (i) => {
      const v = cells[i]; if (!v) return [];
      const seen = new Set([i]), stack = [i];
      while (stack.length) {
        const j = stack.pop(), x = j % cols, y = Math.floor(j / cols);
        for (const [nx, ny] of [[x - 1, y], [x + 1, y], [x, y - 1], [x, y + 1]]) {
          const k = ny * cols + nx;
          if (nx >= 0 && nx < cols && ny >= 0 && ny < rows && !seen.has(k) && cells[k] === v) { seen.add(k); stack.push(k); }
        }
      }
      return [...seen];
    };
    game.canMove = () => cells.some((v, i) => v && ((i % cols < cols - 1 && cells[i + 1] === v) || (i + cols < cells.length && cells[i + cols] === v)));
    game.pop = (i) => {
      if (game.ended) return 0;
      const g = game.group(i); if (g.length < 2) return 0;
      g.forEach((j) => cells[j] = 0);
      game.score += (g.length - 1) * (g.length - 1);
      // Gravity in each column, then empty columns close to the left.
      const columns = [];
      for (let x = 0; x < cols; x++) { const col = []; for (let y = rows - 1; y >= 0; y--) if (cells[y * cols + x]) col.push(cells[y * cols + x]); if (col.length) columns.push(col); }
      cells.fill(0);
      columns.forEach((col, x) => col.forEach((v, k) => { cells[(rows - 1 - k) * cols + x] = v; }));
      if (!cells.some(Boolean)) { game.won = true; game.score += 100; }
      if (!game.canMove()) game.ended = true;
      return g.length;
    };
    return game;
  }
  // 라벤더 · 꽃밭 퍼즐: slide the pieces into the empty spot until they read in order. Shuffled by legal moves,
  // so every board can be solved.
  function newSlideGame(random = Math.random, difficulty = "normal") {
    const n = ({ easy: 3, normal: 4, hard: 5 })[difficulty] || 4;
    const cells = Array.from({ length: n * n }, (_, i) => (i + 1) % (n * n));
    const game = { cols: n, rows: n, cells, moves: 0, ended: false, won: false };
    const blank = () => cells.indexOf(0);
    const near = (i, j) => Math.abs(i % n - j % n) + Math.abs(Math.floor(i / n) - Math.floor(j / n)) === 1;
    game.solved = () => cells.every((v, i) => v === (i + 1) % (n * n));
    let last = -1;
    // A fixed number of random legal moves, then a few stepped ones if that happened to land back on the solution.
    for (let k = 0; k < n * n * 30 + n * n * 4 && (k < n * n * 30 || game.solved()); k++) {
      const b = blank(), options = cells.map((_, i) => i).filter((i) => near(i, b) && i !== last);
      const pick = k < n * n * 30 ? options[Math.floor(random() * options.length)] : options[k % options.length];
      [cells[b], cells[pick]] = [cells[pick], cells[b]]; last = b;
    }
    game.slide = (i) => {
      if (game.ended) return false;
      const b = blank(); if (!near(i, b)) return false;
      [cells[b], cells[i]] = [cells[i], cells[b]]; game.moves++;
      if (game.solved()) game.ended = game.won = true;
      return true;
    };
    return game;
  }
  // 밤하늘 · 별 밝히기: pressing a star switches it and its four neighbours; light every star. Made by pressing
  // from all-lit, so it can always be solved.
  function newLightsGame(random = Math.random, difficulty = "normal") {
    const [n, presses] = ({ easy: [4, 4], normal: [5, 7], hard: [6, 12] })[difficulty] || [5, 7];
    const cells = Array(n * n).fill(true);
    const game = { cols: n, rows: n, cells, moves: 0, ended: false, won: false };
    const flip = (i) => { const x = i % n, y = Math.floor(i / n); for (const [a, b] of [[x, y], [x - 1, y], [x + 1, y], [x, y - 1], [x, y + 1]]) if (a >= 0 && a < n && b >= 0 && b < n) cells[b * n + a] = !cells[b * n + a]; };
    // Distinct cells by a partial shuffle: a fixed number of draws, whatever the random source.
    const order = cells.map((_, i) => i);
    for (let k = 0; k < presses; k++) { const at = k + Math.floor(random() * (order.length - k)); [order[k], order[at]] = [order[at], order[k]]; flip(order[k]); }
    if (cells.every(Boolean)) flip(0);
    game.press = (i) => { if (game.ended) return; flip(i); game.moves++; if (cells.every(Boolean)) game.ended = game.won = true; };
    return game;
  }
  // 마카롱 낙하 (테트리스 방식): pieces of four from a shuffled bag of seven fall one at a time; a full row melts,
  // the pile reaching the top ends it. Ghost, hold, three-piece preview; one level per 10 rows, each faster.
  const DROP_PIECES = {
    I: [[0, 1], [1, 1], [2, 1], [3, 1]], O: [[1, 0], [2, 0], [1, 1], [2, 1]], T: [[1, 0], [0, 1], [1, 1], [2, 1]],
    S: [[1, 0], [2, 0], [0, 1], [1, 1]], Z: [[0, 0], [1, 0], [1, 1], [2, 1]], J: [[0, 0], [0, 1], [1, 1], [2, 1]], L: [[2, 0], [0, 1], [1, 1], [2, 1]],
  };
  const DROP_COLOURS = { I: 5, O: 3, T: 6, S: 4, Z: 7, J: 1, L: 2 };
  const DROP_POINTS = [0, 100, 300, 500, 800];
  function newDropGame(random = Math.random, difficulty = "normal") {
    const [start, slow, holdOk] = ({ easy: [1, 1.35, true], normal: [1, 1, true], hard: [6, 1, false] })[difficulty] || [1, 1, true];
    const cols = 10, rows = 20;
    const game = { cols, rows, cells: Array(cols * rows).fill(0), piece: null, next: [], hold: null, held: false, holdOk,
      score: 0, lines: 0, level: start, combo: -1, locks: 0, slams: 0, ended: false, won: false, last: null, fall: 0, grounded: 0, resets: 0 };
    let bag = [];
    const draw = () => { if (!bag.length) { bag = Object.keys(DROP_PIECES); for (let i = bag.length - 1; i > 0; i--) { const j = Math.floor(random() * (i + 1)); [bag[i], bag[j]] = [bag[j], bag[i]]; } } return bag.pop(); };
    const size = (k) => k === "I" ? 4 : k === "O" ? 0 : 3;
    // Turning a cell of an n-box clockwise r times; the O does not turn.
    const shape = (k, r) => DROP_PIECES[k].map(([x, y]) => { const n = size(k); for (let t = 0; t < ((r % 4) + 4) % 4 && n; t++) [x, y] = [n - 1 - y, x]; return [x, y]; });
    game.blocks = (p = game.piece) => p ? shape(p.k, p.r).map(([x, y]) => [p.x + x, p.y + y]) : [];
    const fits = (p) => game.blocks(p).every(([x, y]) => x >= 0 && x < cols && y < rows && (y < 0 || !game.cells[y * cols + x]));
    const spawn = (k) => {
      const p = { k, r: 0, x: 3, y: k === "I" ? -1 : 0 };
      game.piece = p; game.fall = 0; game.grounded = 0; game.resets = 0;
      if (!fits(p)) { game.ended = true; game.piece = null; }
    };
    const refill = () => { while (game.next.length < 3) game.next.push(draw()); };
    refill(); spawn(game.next.shift()); refill();
    // Rows a cell takes to fall at this level, from 800 ms at level 1 down to 60 ms.
    game.speed = () => Math.max(60, 800 * Math.pow(0.84, game.level - 1)) * slow;
    const landed = () => !fits({ ...game.piece, y: game.piece.y + 1 });
    // Moving or turning a piece resting on the pile restarts its lock delay, at most 15 times.
    const nudged = () => { if (game.grounded && game.resets < 15) { game.grounded = 0.0001; game.resets++; } };
    game.move = (dx) => {
      if (game.ended || !game.piece) return false;
      const p = { ...game.piece, x: game.piece.x + dx };
      if (!fits(p)) return false;
      game.piece = p; nudged(); return true;
    };
    game.rotate = (dir = 1) => {
      if (game.ended || !game.piece || game.piece.k === "O") return false;
      for (const [kx, ky] of [[0, 0], [-1, 0], [1, 0], [0, -1], [-2, 0], [2, 0], [0, 1]]) {
        const p = { ...game.piece, r: game.piece.r + dir, x: game.piece.x + kx, y: game.piece.y + ky };
        if (fits(p)) { game.piece = p; nudged(); return true; }
      }
      return false;
    };
    game.ghost = () => { if (!game.piece) return []; let p = game.piece; while (fits({ ...p, y: p.y + 1 })) p = { ...p, y: p.y + 1 }; return game.blocks(p); };
    const lock = () => {
      const blocks = game.blocks();
      if (blocks.some(([, y]) => y < 0)) { game.ended = true; game.piece = null; return; }
      blocks.forEach(([x, y]) => { game.cells[y * cols + x] = DROP_COLOURS[game.piece.k]; });
      const full = [];
      for (let y = 0; y < rows; y++) if (game.cells.slice(y * cols, y * cols + cols).every(Boolean)) full.push(y);
      for (const y of full) { game.cells.splice(y * cols, cols); game.cells.unshift(...Array(cols).fill(0)); }
      game.locks++;
      game.combo = full.length ? game.combo + 1 : -1;
      const gained = DROP_POINTS[full.length] * game.level + (full.length && game.combo > 0 ? 50 * game.combo * game.level : 0);
      game.score += gained; game.lines += full.length;
      game.last = { rows: full, gained, combo: game.combo, at: game.locks };
      game.level = Math.max(game.level, start + Math.floor(game.lines / 10));
      game.held = false;
      spawn(game.next.shift()); refill();
    };
    game.soft = () => {
      if (game.ended || !game.piece || landed()) return false;
      game.piece = { ...game.piece, y: game.piece.y + 1 }; game.score += 1; game.fall = 0; return true;
    };
    game.slam = () => {
      if (game.ended || !game.piece) return 0;
      let n = 0;
      while (!landed()) { game.piece = { ...game.piece, y: game.piece.y + 1 }; n++; }
      game.score += 2 * n; game.slams++; lock(); return n;
    };
    game.swap = () => {
      if (game.ended || !game.piece || !game.holdOk || game.held) return false;
      const k = game.piece.k;
      if (game.hold) spawn(game.hold); else { spawn(game.next.shift()); refill(); }
      game.hold = k; game.held = true; return true;
    };
    // Time passes: gravity, and a piece resting on the pile locks after half a second.
    game.step = (ms) => {
      if (game.ended || !game.piece) return;
      if (landed()) { game.grounded = (game.grounded || 0) + ms; if (game.grounded >= 500) lock(); return; }
      game.grounded = 0; game.fall += ms;
      const every = game.speed();
      while (game.fall >= every && !landed()) { game.fall -= every; game.piece = { ...game.piece, y: game.piece.y + 1 }; }
    };
    game.shape = shape;
    return game;
  }
  /* Four well-known mobile games, played the way the originals play. All four run on their own clock and pause with the panel. */
  // Chrome's T-Rex runner on its own 600×150 field. Speeds are in px per 60fps frame, as in the original source.
  function newDinoGame(random = Math.random, difficulty = 'normal') {
    const cfg = ({ easy: { start: 5.5, accel: 0.0007, max: 10 }, normal: { start: 6, accel: 0.001, max: 13 }, hard: { start: 7, accel: 0.0016, max: 13 } })[difficulty] || { start: 6, accel: 0.001, max: 13 };
    const TYPES = { small: { w: 17, h: 35, multi: 4, gap: 120 }, large: { w: 25, h: 50, multi: 7, gap: 120 }, ptero: { w: 46, h: 40, multi: 99, gap: 150 } };
    const game = { W: 600, H: 150, x: 50, y: 0, vy: 0, holding: false, reachedMin: false, ducking: false, started: false, ended: false, won: false,
      speed: cfg.start, distance: 0, score: 0, obstacles: [], time: 0, runTime: 0, flash: 0, hundreds: 0, endedAt: 0, kinds: [] };
    // The dinosaur's hit boxes, relative to its feet: head, body and legs standing; one long box ducking.
    game.boxes = () => game.ducking && game.y === 0 ? [{ x: game.x + 2, y: 0, w: 55, h: 22 }]
      : [{ x: game.x + 20, y: 26, w: 22, h: 18 }, { x: game.x + 6, y: 8, w: 28, h: 24 }, { x: game.x + 12, y: 0, w: 14, h: 9 }];
    const hitBox = o => o.kind === 'ptero' ? { x: o.x + 6, y: o.y + 8, w: o.w - 12, h: 22 } : { x: o.x + 3, y: 0, w: o.w - 6, h: o.h - 4 };
    const spawn = () => {
      const kinds = ['small', 'large'];
      if (game.speed >= 8.5) kinds.push('ptero');
      let kind = kinds[Math.floor(random() * kinds.length)];
      // Like the original, the same obstacle never comes three times in a row.
      if (game.kinds.length >= 2 && game.kinds.slice(-2).every(k => k === kind)) kind = kinds.filter(k => k !== kind)[Math.floor(random() * (kinds.length - 1))];
      game.kinds = [...game.kinds.slice(-2), kind];
      const t = TYPES[kind], size = kind !== 'ptero' && game.speed > t.multi ? 1 + Math.floor(random() * 3) : 1, w = t.w * size;
      const gap = Math.round(w * game.speed + t.gap * 0.6);
      game.obstacles.push({ kind, size, x: game.W + 4, w, h: t.h, y: kind === 'ptero' ? [0, 25, 50][Math.floor(random() * 3)] : 0,
        vx: kind === 'ptero' ? (random() < 0.5 ? 0.8 : -0.8) : 0, gap: gap + Math.round(random() * gap * 0.5), seed: Math.floor(random() * 1000) });
    };
    game.jump = () => {
      if (game.ended) return false;
      game.started = true; game.holding = true;
      if (game.y > 0 || game.ducking) return false;
      game.vy = 600 + game.speed * 6; game.y = 0.01; game.reachedMin = false; return true;
    };
    game.release = () => { game.holding = false; };
    game.duck = held => { game.ducking = !!held && !game.ended; if (game.ducking) game.started = true; };
    game.step = ms => {
      if (!game.started || game.ended) return;
      let left = Math.max(0, Math.min(100, ms)) / 1000;
      while (left > 0 && !game.ended) {
        const dt = Math.min(left, 1 / 120); left -= dt; game.time += dt; game.runTime += dt;
        game.flash = Math.max(0, game.flash - dt);
        if (game.y > 0) {
          if (game.y >= 30) game.reachedMin = true;
          // Let go early for a short hop; hold for the full jump. Ducking in the air drops fast.
          if (((!game.holding && game.reachedMin) || game.y > 55) && game.vy > 300) game.vy = 300;
          game.vy -= 2160 * (game.ducking ? 3 : 1) * dt; game.y += game.vy * dt;
          if (game.y <= 0) { game.y = 0; game.vy = 0; }
        }
        const px = game.speed * 60 * dt;
        game.distance += px;
        game.speed = Math.min(cfg.max, game.speed + cfg.accel * 60 * dt);
        const score = Math.floor(game.distance * 0.025);
        if (Math.floor(score / 100) > Math.floor(game.score / 100)) { game.flash = 0.8; game.hundreds++; }
        game.score = score;
        for (const o of game.obstacles) o.x -= px + o.vx * 60 * dt;
        game.obstacles = game.obstacles.filter(o => o.x + o.w > -20);
        const last = game.obstacles[game.obstacles.length - 1];
        if (game.runTime > 1.2 && (!last || last.x + last.w + last.gap < game.W)) spawn();
        for (const o of game.obstacles) {
          const ob = hitBox(o);
          if (game.boxes().some(b => b.x < ob.x + ob.w && b.x + b.w > ob.x && game.y + b.y < ob.y + ob.h && game.y + b.y + b.h > ob.y)) { game.ended = true; game.endedAt = game.time; break; }
        }
      }
    };
    return game;
  }

  // Water Sort Puzzle: levels that grow by a colour every two, four layers a tube, five undos and one spare tube a level.
  function newWaterSortGame(random = Math.random, difficulty = 'normal', level = 1) {
    const base = ({ easy: 3, normal: 4, hard: 6 })[difficulty] || 4;
    const colors = Math.min(10, base + Math.floor((level - 1) / 2)), capacity = 4;
    const game = { level, difficulty, colors, capacity, bottles: [], moves: 0, ended: false, won: false, history: [], undos: 5, extra: false };
    const solved = () => game.bottles.every(b => !b.length || b.length === capacity && b.every(c => c === b[0]));
    const run = b => { let n = 0; for (let i = b.length - 1; i >= 0 && b[i] === b[b.length - 1]; i--) n++; return n; };
    // Reverse legal pours from a solved board: every scramble step has a legal forward inverse, so a solution always exists.
    for (let attempt = 0; attempt < 20; attempt++) {
      game.bottles = Array.from({ length: colors + 2 }, (_, i) => i < colors ? Array(capacity).fill(i) : []);
      let previous = null;
      for (let step = 0; step < colors * 45; step++) {
        const choices = [];
        game.bottles.forEach((a, i) => {
          if (!a.length) return;
          const top = a[a.length - 1], r = run(a), limit = r === a.length ? r : r - 1;
          if (!limit) return;
          game.bottles.forEach((b, j) => {
            if (i === j || b.length >= capacity || b[b.length - 1] === top || previous && previous[0] === j && previous[1] === i) return;
            for (let n = 1; n <= Math.min(limit, capacity - b.length); n++) {
              if (!b.length && n === a.length) continue;
              choices.push([i, j, n]);
            }
          });
        });
        if (!choices.length) break;
        const [i, j, n] = choices[Math.floor(random() * choices.length)];
        game.bottles[j].push(...game.bottles[i].splice(-n)); previous = [i, j];
      }
      if (!solved()) break;
    }
    game.canPour = (i, j) => {
      const a = game.bottles[i], b = game.bottles[j];
      return !game.ended && i !== j && !!a?.length && !!b && b.length < capacity && (!b.length || b[b.length - 1] === a[a.length - 1]);
    };
    // Returns how many layers moved (0 when the pour is not allowed).
    game.pour = (from, to) => {
      if (!game.canPour(from, to)) return 0;
      const a = game.bottles[from], b = game.bottles[to];
      game.history.push(game.bottles.map(x => x.slice()));
      const n = Math.min(run(a), capacity - b.length); b.push(...a.splice(-n)); game.moves++;
      game.won = game.ended = solved(); return n;
    };
    game.undo = () => {
      if (!game.history.length || game.ended || game.undos <= 0) return false;
      const back = game.history.pop();
      while (back.length < game.bottles.length) back.push([]);
      game.bottles = back; game.moves--; game.undos--; return true;
    };
    game.addBottle = () => {
      if (game.extra || game.ended) return false;
      game.bottles.push([]); game.extra = true; return true;
    };
    game.done = i => { const b = game.bottles[i]; return b.length === capacity && b.every(c => c === b[0]); };
    return game;
  }

  // Knife Hit: endless stages on a spinning log, every fifth a boss; the log changes speed, stops and turns back.
  function newKnifeGame(random = Math.random, difficulty = 'normal') {
    const cfg = ({ easy: [1.5, 5], normal: [2.1, 6], hard: [2.7, 7] })[difficulty] || [2.1, 6];
    const tau = Math.PI * 2, norm = a => (a % tau + tau) % tau, gapTo = (a, b) => Math.abs(Math.atan2(Math.sin(a - b), Math.cos(a - b)));
    const PATTERNS = ['steady', 'wobble', 'reverse', 'stopgo'];
    const game = { stage: 0, score: 0, apples: 0, angle: 0, spin: 0, dir: 1, base: cfg[0], knives: [], fruit: [], remaining: 0, total: 0, flight: null, wait: 0,
      time: 0, stageTime: 0, started: false, ended: false, won: false, boss: false, pattern: 'steady', hitAt: -9, appleAt: -9, brokeAt: -9, fail: null };
    game.speedAt = t => {
      const s = game.base * game.dir;
      if (game.pattern === 'wobble') return s * (0.35 + 0.85 * (0.5 + 0.5 * Math.sin(t * 1.7)));
      if (game.pattern === 'reverse') return s * Math.max(-1, Math.min(1, Math.sin(t * 1.25) * 2.2));
      if (game.pattern === 'stopgo') return s * 1.5 * Math.pow(Math.max(0, Math.sin(t * 2.2)), 0.6);
      if (game.pattern === 'boss') return s * 1.2 * Math.max(-1, Math.min(1, Math.sin(t * 0.9) * 3)) * (0.8 + 0.4 * Math.sin(t * 3.1));
      return s;
    };
    const free = (list, gap) => { for (let k = 0; k < 40; k++) { const a = random() * tau; if (list.every(b => gapTo(a, b) > gap)) return a; } return null; };
    game.next = () => {
      game.stage++; game.boss = game.stage % 5 === 0; game.stageTime = 0; game.angle = random() * tau; game.dir = random() < 0.5 ? 1 : -1;
      game.base = cfg[0] + Math.min(1.2, (game.stage - 1) * 0.08);
      game.pattern = game.boss ? 'boss' : game.stage === 1 ? 'steady' : PATTERNS[Math.floor(random() * PATTERNS.length)];
      game.total = game.remaining = Math.min(cfg[1] + Math.floor((game.stage - 1) / 2) + (game.boss ? 2 : 0), 11);
      game.knives = [];
      const pre = game.stage === 1 ? 0 : Math.min(4, Math.floor(random() * (2 + game.stage / 3)));
      for (let i = 0; i < pre; i++) { const a = free(game.knives, 0.6); if (a != null) game.knives.push(a); }
      game.fruit = [];
      if (!game.boss && random() < 0.5) { const a = free(game.knives, 0.5); if (a != null) game.fruit.push(a); }
      game.preset = game.knives.length; game.wait = 0; game.flight = null;
    };
    game.next();
    game.throwKnife = () => {
      if (game.ended || game.wait > 0 || game.flight != null || game.remaining <= 0) return false;
      game.started = true; game.flight = 0; return true;
    };
    game.step = ms => {
      let left = Math.max(0, Math.min(250, ms)) / 1000;
      while (left > 0) {
        const dt = Math.min(left, 1 / 120); left -= dt; game.time += dt;
        if (game.ended) continue;
        game.stageTime += dt; game.spin = game.speedAt(game.stageTime); game.angle = norm(game.angle + game.spin * dt);
        if (game.wait > 0) { game.wait -= dt; if (game.wait <= 0) game.next(); continue; }
        if (game.flight == null) continue;
        game.flight += dt;
        if (game.flight < 0.09) continue;
        game.flight = null;
        // The knife meets the log at its lowest point; in the log's own turn that is this angle.
        const hit = norm(Math.PI / 2 - game.angle);
        if (game.knives.some(a => gapTo(a, hit) < 0.15)) { game.ended = true; game.remaining--; game.fail = { t: game.time, side: game.spin >= 0 ? 1 : -1 }; break; }
        const got = game.fruit.filter(a => gapTo(a, hit) < 0.26).length;
        if (got) { game.fruit = game.fruit.filter(a => gapTo(a, hit) >= 0.26); game.apples += got; game.appleAt = game.time; }
        game.knives.push(hit); game.remaining--; game.score++; game.hitAt = game.time;
        if (!game.remaining) { game.wait = 1.1; game.brokeAt = game.time; }
      }
    };
    return game;
  }

  // Count Masters: run a road, pick gates, lose men to walls, saws and enemy crowds, then climb the bonus stairs.
  function newCountMastersGame(random = Math.random, difficulty = 'normal') {
    const cfg = ({ easy: { start: 5, enemy: 0.35, bad: 0.3 }, normal: { start: 1, enemy: 0.5, bad: 0.45 }, hard: { start: 1, enemy: 0.65, bad: 0.6 } })[difficulty] || { start: 1, enemy: 0.5, bad: 0.45 };
    const game = { x: 0, target: 0, direction: 0, count: cfg.start, z: 0, speed: 14, events: [], started: false, ended: false, won: false, score: 0, maxCount: 0,
      note: '', noteTime: 0, noteGood: true, phase: 'run', fight: null, acc: 0, steps: 0, stairT: 0, mult: 1, finishCount: 0, time: 0, stepCost: 3, maxSteps: 30 };
    let expect = cfg.start, z = 45;
    for (const kind of ['gate', 'gate', 'block', 'gate', 'enemy', 'gate', 'saw', 'gate', 'gate', 'enemy', 'block', 'gate', 'enemy']) {
      if (kind === 'gate') {
        const good = expect >= 4 && random() < 0.35 ? { op: '*', v: random() < 0.75 ? 2 : 3 } : { op: '+', v: Math.max(3, Math.round(expect * (0.4 + random() * 0.6)) + Math.floor(random() * 8)) };
        const other = random() < cfg.bad ? (expect > 6 && random() < 0.4 ? { op: '/', v: 2 } : { op: '-', v: Math.max(2, Math.round(expect * 0.3 + random() * 6)) })
          : { op: '+', v: Math.max(2, Math.round(good.op === '+' ? good.v * 0.5 : expect * 0.6)) };
        game.events.push({ z, type: 'gate', gates: random() < 0.5 ? [good, other] : [other, good] });
        expect = good.op === '*' ? expect * good.v : expect + good.v;
      } else if (kind === 'enemy') {
        const v = Math.max(2, Math.round(expect * cfg.enemy)); game.events.push({ z, type: 'enemy', value: v, left: v }); expect -= v;
      } else if (kind === 'block') {
        const leftSide = random() < 0.5; game.events.push({ z, type: 'block', from: leftSide ? -1 : 0.08, to: leftSide ? -0.08 : 1 });
      } else game.events.push({ z, type: 'saw', c: -0.5 + random(), amp: 0.35, phase: random() * 6, half: 0.26 });
      z += 34 + random() * 6;
    }
    game.length = z + 15;
    // Men stand in a sunflower: man i at radius 0.32·√i metres. The road is ±1 (±5 m).
    game.man = i => { const r = 0.32 * Math.sqrt(i + 0.5), t = i * 2.39996; return { dx: r * Math.cos(t) / 5, dz: r * Math.sin(t) * 0.7 }; };
    game.shown = () => Math.min(160, game.count);
    game.radius = () => 0.32 * Math.sqrt(game.shown()) / 5;
    game.sawAt = e => e.c + e.amp * Math.sin(game.time * 1.6 + e.phase);
    game.start = () => { if (!game.ended) game.started = true; };
    game.aim = x => { if (Number.isFinite(x)) game.target = Math.max(-1, Math.min(1, x)); };
    game.move = d => { game.direction = Math.sign(d); };
    const say = (text, good) => { game.note = text; game.noteGood = good; game.noteTime = 1; };
    const cut = (from, to) => {
      const n = game.shown(); let inside = 0;
      for (let i = 0; i < n; i++) { const x = game.x + game.man(i).dx; if (x >= from && x <= to) inside++; }
      const lost = n ? Math.round(game.count * inside / n) : 0;
      if (lost) { game.count -= lost; say('−' + lost, false); }
    };
    const end = won => { game.ended = true; game.won = won; game.score = won ? Math.round(game.finishCount * game.mult) : 0; };
    game.step = ms => {
      if (!game.started || game.ended) return;
      const dt = Math.max(0, Math.min(100, ms)) / 1000;
      game.time += dt; game.noteTime = Math.max(0, game.noteTime - dt);
      if (game.direction) game.target = Math.max(-1, Math.min(1, game.target + game.direction * dt * 1.8));
      const lim = Math.max(0, 1 - game.radius() * 0.85);
      game.x += (Math.max(-lim, Math.min(lim, game.target)) - game.x) * Math.min(1, dt * 12);
      if (game.phase === 'run') {
        game.z += game.speed * dt;
        for (const e of game.events) {
          if (e.done || e.z > game.z) continue;
          e.done = true;
          if (e.type === 'gate') {
            const g = e.gates[game.x < 0 ? 0 : 1];
            game.count = Math.max(0, Math.min(9999, g.op === '*' ? game.count * g.v : g.op === '/' ? Math.ceil(game.count / g.v) : g.op === '-' ? game.count - g.v : game.count + g.v));
            say((g.op === '*' ? '×' : g.op === '/' ? '÷' : g.op === '-' ? '−' : '+') + g.v, g.op === '*' || g.op === '+');
          } else if (e.type === 'block') cut(e.from, e.to);
          else if (e.type === 'saw') { const c = game.sawAt(e); cut(c - e.half, c + e.half); }
          else if (e.type === 'enemy') { game.phase = 'fight'; game.fight = e; game.acc = 0; game.rate = Math.max(game.count, e.left) / 0.9; }
          if (game.phase !== 'run') break;
        }
        if (game.phase === 'run' && game.z >= game.length) { game.phase = 'stairs'; game.finishCount = game.count; game.stairT = 0; }
      } else if (game.phase === 'fight') {
        const e = game.fight; game.acc += game.rate * dt;
        const k = Math.min(Math.floor(game.acc), game.count, e.left); game.acc -= Math.floor(game.acc);
        game.count -= k; e.left -= k;
        if (!e.left && game.count) { game.phase = 'run'; game.fight = null; }
      } else if (game.phase === 'stairs') {
        game.stairT += dt;
        while (game.stairT >= 0.16 && !game.ended) {
          game.stairT -= 0.16;
          if (game.count > game.stepCost && game.steps < game.maxSteps) { game.count -= game.stepCost; game.steps++; game.mult = 1 + game.steps * 0.1; }
          else end(true);
        }
      }
      game.maxCount = Math.max(game.maxCount, game.count);
      if (!game.count && !game.ended && game.phase !== 'stairs') end(false);
    };
    return game;
  }

  // Candy Crush: swap neighbours to line up three or more; four make a striped candy, an L or T a wrapped one, five a colour bomb.
  // Each level has a target score and a move budget; leftover moves become striped candies at the end (sugar crush).
  // The board settles one event at a time (settle()), so the view can animate every clear and every fall.
  function newCandyGame(random = Math.random, difficulty = 'normal', level = 1) {
    const cfg = ({ easy: { colors: 5, moves: 25 }, normal: { colors: 6, moves: 20 }, hard: { colors: 6, moves: 16 } })[difficulty] || { colors: 6, moves: 20 };
    const R = 8, C = 8;
    const game = { rows: R, cols: C, colors: cfg.colors, level, difficulty, moves: cfg.moves, target: Math.round((1000 + (level - 1) * 350) / 10) * 10,
      score: 0, grid: [], phase: 'idle', pending: null, cascade: 0, sugar: false, ended: false, won: false, nextId: 1, swaps: 0 };
    const make = (color, kind = 'n') => ({ id: game.nextId++, color, kind });
    const at = (r, c) => r >= 0 && r < R && c >= 0 && c < C ? game.grid[r][c] : null;
    const runs = () => {
      const out = [];
      for (let r = 0; r < R; r++) for (let c = 0; c < C;) {
        const a = at(r, c); let n = 1;
        while (a && a.kind !== 'b' && c + n < C && at(r, c + n) && at(r, c + n).kind !== 'b' && at(r, c + n).color === a.color) n++;
        if (a && a.kind !== 'b' && n >= 3) out.push({ dir: 'h', cells: Array.from({ length: n }, (_, k) => [r, c + k]) });
        c += n;
      }
      for (let c = 0; c < C; c++) for (let r = 0; r < R;) {
        const a = at(r, c); let n = 1;
        while (a && a.kind !== 'b' && r + n < R && at(r + n, c) && at(r + n, c).kind !== 'b' && at(r + n, c).color === a.color) n++;
        if (a && a.kind !== 'b' && n >= 3) out.push({ dir: 'v', cells: Array.from({ length: n }, (_, k) => [r + k, c]) });
        r += n;
      }
      return out;
    };
    const swapCells = (a, b) => { const t = game.grid[a[0]][a[1]]; game.grid[a[0]][a[1]] = game.grid[b[0]][b[1]]; game.grid[b[0]][b[1]] = t; };
    const adjacent = (a, b) => Math.abs(a[0] - b[0]) + Math.abs(a[1] - b[1]) === 1;
    const legal = (a, b) => {
      const x = at(...a), y = at(...b);
      if (!x || !y) return false;
      if (x.kind === 'b' || y.kind === 'b' || x.kind !== 'n' && y.kind !== 'n') return true;
      swapCells(a, b); const ok = runs().length > 0; swapCells(a, b); return ok;
    };
    game.hint = () => {
      for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) for (const [dr, dc] of [[0, 1], [1, 0]]) {
        if (r + dr < R && c + dc < C && legal([r, c], [r + dr, c + dc])) return [[r, c], [r + dr, c + dc]];
      }
      return null;
    };
    const fill = () => {
      for (let tries = 0; tries < 200; tries++) {
        game.grid = Array.from({ length: R }, () => Array(C).fill(null));
        for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) {
          let color;
          do color = Math.floor(random() * game.colors);
          while (c >= 2 && at(r, c - 1).color === color && at(r, c - 2).color === color || r >= 2 && at(r - 1, c).color === color && at(r - 2, c).color === color);
          game.grid[r][c] = make(color);
        }
        if (game.hint()) return;
      }
    };
    fill();
    // Mix the candies (keeping specials) until there is a move and nothing is already lined up.
    const shuffle = () => {
      const all = game.grid.flat();
      for (let tries = 0; tries < 300; tries++) {
        for (let i = all.length - 1; i > 0; i--) { const j = Math.floor(random() * (i + 1)); [all[i], all[j]] = [all[j], all[i]]; }
        for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) game.grid[r][c] = all[r * C + c];
        if (!runs().length && game.hint()) return;
      }
      fill();
    };
    game.trySwap = (a, b) => {
      if (game.phase !== 'idle' || game.ended || !adjacent(a, b) || !at(...a) || !at(...b)) return 'no';
      if (!legal(a, b)) return 'bad';
      swapCells(a, b); game.moves--; game.swaps++; game.cascade = 0; game.pending = { a, b }; game.phase = 'busy';
      return 'ok';
    };
    // Clear cells; a special candy that is cleared fires too. Returns the cleared candies with their places.
    const blast = (start, keep = new Set()) => {
      const seen = new Set(), queue = [...start], out = [];
      const add = (r, c) => { if (r >= 0 && r < R && c >= 0 && c < C && !keep.has(r * C + c)) queue.push([r, c]); };
      while (queue.length) {
        const [r, c] = queue.shift(), key = r * C + c;
        if (seen.has(key)) continue;
        const k = at(r, c); if (!k) continue;
        seen.add(key); out.push({ r, c, ...k });
        if (k.kind === 'h') for (let x = 0; x < C; x++) add(r, x);
        else if (k.kind === 'v') for (let y = 0; y < R; y++) add(y, c);
        else if (k.kind === 'w') { for (let y = -1; y <= 1; y++) for (let x = -1; x <= 1; x++) add(r + y, c + x); }
        else if (k.kind === 'b') {
          const colors = game.grid.flat().filter(q => q && q.kind !== 'b').map(q => q.color), pick = colors[Math.floor(random() * colors.length)];
          for (let y = 0; y < R; y++) for (let x = 0; x < C; x++) if (at(y, x) && at(y, x).color === pick) add(y, x);
        }
      }
      for (const o of out) game.grid[o.r][o.c] = null;
      return out;
    };
    const points = n => { game.cascade++; const p = n * 20 * game.cascade; game.score += p; return p; };
    const combo = (a, b) => {
      const x = at(...a), y = at(...b), cells = [];
      const box = (r0, c0, h) => { for (let r = r0 - h; r <= r0 + h; r++) for (let c = c0 - h; c <= c0 + h; c++) if (at(r, c)) cells.push([r, c]); };
      const kinds = [x.kind, y.kind];
      if (x.kind === 'b' && y.kind === 'b') { for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) cells.push([r, c]); }
      else if (x.kind === 'b' || y.kind === 'b') {
        const bomb = x.kind === 'b' ? b : a, other = x.kind === 'b' ? y : x;
        const bombCandy = at(...bomb); game.grid[bomb[0]][bomb[1]] = null; cells.length = 0;
        for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) {
          const q = at(r, c);
          if (q && q.kind !== 'b' && q.color === other.color) { if (other.kind === 'h' || other.kind === 'v') q.kind = random() < 0.5 ? 'h' : 'v'; else if (other.kind === 'w') q.kind = 'w'; cells.push([r, c]); }
        }
        const out = blast(cells); out.push({ r: bomb[0], c: bomb[1], ...bombCandy }); return { cleared: out, extra: 1 };
      } else if (kinds.includes('w') && kinds.some(k => k === 'h' || k === 'v')) {
        x.kind = y.kind = 'n';
        for (let d = -1; d <= 1; d++) { for (let c = 0; c < C; c++) cells.push([b[0] + d, c]); for (let r = 0; r < R; r++) cells.push([r, b[1] + d]); }
      } else if (x.kind === 'w' && y.kind === 'w') { x.kind = y.kind = 'n'; box(b[0], b[1], 2); }
      else { x.kind = y.kind = 'n'; for (let c = 0; c < C; c++) cells.push([b[0], c]); for (let r = 0; r < R; r++) cells.push([r, b[1]]); }
      return { cleared: blast(cells.filter(([r, c]) => r >= 0 && r < R && c >= 0 && c < C)), extra: 0 };
    };
    // One step of settling: a swap combo, a round of matches, a fall, the end-of-level sugar crush, or done.
    game.settle = () => {
      if (game.phase !== 'busy') return { type: 'idle' };
      const p = game.pending; game.pending = null;
      if (p) {
        const x = at(...p.a), y = at(...p.b);
        if (x && y && (x.kind === 'b' || y.kind === 'b' || x.kind !== 'n' && y.kind !== 'n')) {
          const { cleared } = combo(p.a, p.b);
          return { type: 'clear', cleared, created: [], points: points(cleared.length) + 300, combo: true };
        }
      }
      const found = runs();
      if (found.length) {
        // Join runs that share a cell (L and T shapes) and decide which special each group makes.
        const groups = [];
        for (const run of found) {
          const keys = new Set(run.cells.map(([r, c]) => r * C + c));
          const hit = groups.filter(g => [...keys].some(k => g.keys.has(k)));
          const g = { runs: [run], keys };
          for (const h of hit) { h.runs.forEach(x => g.runs.push(x)); h.keys.forEach(k => g.keys.add(k)); groups.splice(groups.indexOf(h), 1); }
          groups.push(g);
        }
        const keep = new Set(), created = [];
        let bonus = 0;
        for (const g of groups) {
          const longest = Math.max(...g.runs.map(r => r.cells.length)), both = g.runs.some(r => r.dir === 'h') && g.runs.some(r => r.dir === 'v');
          const kind = longest >= 5 ? 'b' : both ? 'w' : longest === 4 ? (g.runs[0].dir === 'h' ? 'v' : 'h') : null;
          if (!kind) continue;
          const cells = [...g.keys], moved = p ? [p.a, p.b].map(([r, c]) => r * C + c).find(k => g.keys.has(k)) : undefined;
          const spot = moved ?? (both ? [...g.keys].find(k => g.runs.filter(r => r.cells.some(([y, x]) => y * C + x === k)).length > 1) : cells[Math.floor(cells.length / 2)]) ?? cells[0];
          const old = game.grid[Math.floor(spot / C)][spot % C];
          keep.add(spot); created.push({ r: Math.floor(spot / C), c: spot % C, kind, color: old.color, fired: old.kind !== 'n' ? old.kind : null });
          bonus += kind === 'b' ? 200 : kind === 'w' ? 120 : 60;
        }
        const start = groups.flatMap(g => [...g.keys]).filter(k => !keep.has(k)).map(k => [Math.floor(k / C), k % C]);
        // A special that is consumed into a new special still fires.
        for (const cr of created) if (cr.fired) start.push([cr.r, cr.c]);
        const createdSpots = new Set(created.filter(cr => !cr.fired).map(cr => cr.r * C + cr.c));
        const cleared = blast(start, createdSpots);
        for (const cr of created) {
          const q = game.grid[cr.r][cr.c];
          if (q && !cr.fired) { q.kind = cr.kind; if (cr.kind === 'b') q.color = -1; cr.id = q.id; }
          else if (!q) { const n = make(cr.kind === 'b' ? -1 : cr.color, cr.kind); game.grid[cr.r][cr.c] = n; cr.id = n.id; }
          else cr.id = q.id;
        }
        game.score += bonus;
        return { type: 'clear', cleared, created, points: points(cleared.length) + bonus };
      }
      // Gravity: candies drop to fill gaps; new ones come in from the top.
      const spawned = [], fell = [];
      for (let c = 0; c < C; c++) {
        let w = R - 1;
        for (let r = R - 1; r >= 0; r--) if (game.grid[r][c]) { if (w !== r) { game.grid[w][c] = game.grid[r][c]; game.grid[r][c] = null; fell.push(game.grid[w][c].id); } w--; }
        for (let r = w, k = 0; r >= 0; r--, k++) { game.grid[r][c] = make(Math.floor(random() * game.colors)); spawned.push({ id: game.grid[r][c].id, r, c, above: w + 1 }); }
      }
      if (spawned.length || fell.length) return { type: 'fall', spawned, fell };
      // The board is still. End of level, sugar crush, or back to the player.
      if (game.score >= game.target && game.moves > 0) {
        const normal = []; for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) if (at(r, c).kind === 'n') normal.push([r, c]);
        const [r, c] = normal[Math.floor(random() * normal.length)] || [0, 0];
        at(r, c).kind = random() < 0.5 ? 'h' : 'v'; game.moves--; game.sugar = true; game.score += 100;
        return { type: 'sugar', r, c, id: at(r, c).id };
      }
      if (game.sugar) {
        const specials = []; for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) if (at(r, c).kind !== 'n') specials.push([r, c]);
        if (specials.length) { game.cascade = 0; const cleared = blast(specials); return { type: 'clear', cleared, created: [], points: points(cleared.length) }; }
      }
      if (game.score >= game.target) { game.phase = 'won'; game.ended = game.won = true; return { type: 'won' }; }
      if (game.moves <= 0) { game.phase = 'lost'; game.ended = true; return { type: 'lost' }; }
      game.phase = 'idle';
      if (!game.hint()) { shuffle(); return { type: 'shuffle' }; }
      return { type: 'ready' };
    };
    game.stars = () => game.score >= game.target * 2 ? 3 : game.score >= game.target * 1.5 ? 2 : game.score >= game.target ? 1 : 0;
    return game;
  }

  function writingLoad(h) {
    if (!h) return false;
    // A story fetch/entry is not generation. The Forge screen also covers image generation after text is ready.
    const forge = h.shadowRoot?.querySelector?.('.forge-center');
    const visible = forge && !forge.closest('[hidden]') && forge.getClientRects().length > 0;
    if (!visible || forge.closest('.forge.-error, .forge.-paused') || h._forgeCancelling) return false;
    // First-world cast and art have rotating progress labels, often without any
    // generation verb. Use their actual states, not names or translated labels.
    const state = typeof h._state === 'function' ? h._state() : null;
    if (state === 'banner') return h._bannerState === 'loading';
    if (state === 'art') return h._artState === 'painting';
    const text = visible ? forge.textContent || '' : '';
    if (/(?:실패|오류|취소|failed|error|cancelled)/i.test(text)) return false;
    const working = /(?:생성\s*중|작성\s*중|그리는\s*중|generating|rendering|writing\b)/i.test(text);
    if (visible && /(?:완료|완성|completed|finished)/i.test(text) && !working) return false;
    // Fetching an existing chapter also uses _planState=loading. Only an explicit
    // generation-in-progress screen may offer games; labels/buttons are not evidence.
    return !!visible && working;
  }
  /* Sound: short punchy effects synthesized with Web Audio (no files): a low kick for weight, a noise burst for the
   * crack, a pitched blip for the colour. [소리] turns them off in this browser; with Gacha Forge Sound installed its
   * master and effect volume (and its effects switch) apply too. */
  const SOUND_KEY = "gfx-games-sound";
  function makeSfx() {
    let ctx = null, out = null, noise = null, enabled = true;
    try { enabled = localStorage.getItem(SOUND_KEY) !== "0"; } catch {}
    const volume = () => {
      try {
        const s = window.__gachaForgeSound;
        if (s?._get) { if (s._get("sfxOn") === false) return 0; const m = Number(s._get("master") ?? 1), v = Number(s._get("sfxVol") ?? 1); return Math.min(1, (m * m * v * v) || 0) * 0.9; }
      } catch {}
      return 0.6;
    };
    const ready = () => {
      if (!enabled) return null;
      try {
        if (!ctx) {
          const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return null;
          ctx = new AC();
          const comp = ctx.createDynamicsCompressor(); comp.threshold.value = -10; comp.knee.value = 12; comp.ratio.value = 4;
          out = ctx.createGain(); out.connect(comp); comp.connect(ctx.destination);
          noise = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate);
          const d = noise.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
        }
        if (ctx.state === "suspended") ctx.resume().catch(() => {});
        out.gain.value = volume();
        return out.gain.value > 0.001 ? ctx : null;
      } catch { return null; }
    };
    const env = (g, t, vol, dur, attack = 0.002) => { g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + attack); g.gain.exponentialRampToValueAtTime(0.0001, t + dur); };
    const tone = (type, f0, f1, dur, vol, at = 0) => {
      const t = ctx.currentTime + at, o = ctx.createOscillator(), g = ctx.createGain();
      o.type = type; o.frequency.setValueAtTime(f0, t); if (f1 !== f0) o.frequency.exponentialRampToValueAtTime(f1, t + dur);
      env(g, t, vol, dur); o.connect(g); g.connect(out); o.start(t); o.stop(t + dur + 0.02);
    };
    const burst = (dur, vol, kind, f0, f1 = f0, at = 0, q = 0.9) => {
      const t = ctx.currentTime + at, s = ctx.createBufferSource(), f = ctx.createBiquadFilter(), g = ctx.createGain();
      s.buffer = noise; f.type = kind; f.Q.value = q; f.frequency.setValueAtTime(f0, t); if (f1 !== f0) f.frequency.exponentialRampToValueAtTime(f1, t + dur);
      env(g, t, vol, dur, 0.001); s.connect(f); f.connect(g); g.connect(out); s.start(t, Math.random() * 0.5); s.stop(t + dur + 0.02);
    };
    // The body of every hit: a sine dropping fast to a thump.
    const kick = (f, dur, vol, at = 0) => tone("sine", f, 42, dur, vol, at);
    const notes = (list, gap, type = "triangle", vol = 0.16, dur = 0.16) => list.forEach((f, k) => tone(type, f, f, dur, vol, k * gap));
    const SOUNDS = {
      tap: () => tone("triangle", 1500, 900, 0.035, 0.1),
      move: () => tone("triangle", 300, 200, 0.045, 0.12),
      turn: () => { tone("square", 700, 980, 0.04, 0.05); burst(0.03, 0.08, "highpass", 3000); },
      flip: () => { burst(0.05, 0.16, "bandpass", 2600, 1600); tone("sine", 560, 320, 0.06, 0.12); },
      pop: (p = 1) => { tone("sine", 320 * (1 + p * 0.12), 1200 * (1 + p * 0.12), 0.07, 0.2); burst(0.04, 0.1, "highpass", 2500); },
      bounce: () => { kick(220, 0.07, 0.3); tone("sine", 480, 300, 0.05, 0.08); },
      hit: (p = 1) => {
        p = Math.max(1, Math.min(3, p));
        kick(140 + 30 * p, 0.12 + 0.04 * p, 0.45 + 0.15 * p);
        burst(0.035 + 0.015 * p, 0.25 + 0.1 * p, "bandpass", 1600 + 700 * p, 900, 0, 1.2);
        tone("square", 440 * Math.pow(2, p / 4), 330 * Math.pow(2, p / 4), 0.07, 0.05 + 0.02 * p, 0.005);
      },
      coin: () => { tone("square", 988, 988, 0.06, 0.07); tone("square", 1319, 1319, 0.16, 0.07, 0.06); kick(200, 0.06, 0.2); },
      lock: () => { kick(120, 0.09, 0.45); burst(0.05, 0.18, "lowpass", 1400, 500); },
      slam: () => { burst(0.09, 0.22, "bandpass", 3200, 500, 0, 0.7); kick(95, 0.24, 0.95, 0.05); burst(0.09, 0.45, "lowpass", 900, 200, 0.05); },
      clear: (n = 1) => {
        kick(150, 0.22, 0.85); burst(0.3, 0.3, "highpass", 600, 5000, 0, 0.6);
        notes([523, 659, 784, 1047, 1319].slice(0, Math.min(5, n + 1)), 0.055, "triangle", 0.15, 0.18);
        if (n >= 4) { notes([1568, 2093], 0.07, "sine", 0.09, 0.4); kick(80, 0.35, 0.7, 0.12); }
      },
      match: () => { notes([784, 1175], 0.07, "triangle", 0.14, 0.15); burst(0.05, 0.08, "highpass", 4000); },
      hurt: () => { tone("sawtooth", 330, 70, 0.28, 0.13); kick(85, 0.28, 0.8); burst(0.16, 0.3, "lowpass", 1200, 200); },
      level: () => notes([659, 784, 988, 1319], 0.06, "square", 0.06, 0.12),
      win: () => { notes([523, 659, 784, 1047, 1319], 0.09, "triangle", 0.17, 0.3); kick(130, 0.2, 0.6); burst(0.5, 0.07, "highpass", 6000, 9000, 0.3); },
      lose: () => { notes([392, 330, 262], 0.16, "square", 0.07, 0.2); kick(70, 0.4, 0.8, 0.32); },
      end: () => { notes([784, 1047], 0.12, "triangle", 0.15, 0.3); kick(140, 0.15, 0.5); },
      nope: () => { tone("square", 150, 130, 0.07, 0.07); tone("square", 150, 120, 0.07, 0.07, 0.09); },
    };
    const lastAt = {};
    return {
      get enabled() { return enabled; },
      set enabled(v) { enabled = !!v; try { localStorage.setItem(SOUND_KEY, enabled ? "1" : "0"); } catch {} },
      play(name, p) {
        const fn = SOUNDS[name]; if (!fn || !ready()) return;
        // The same sound at most once per 30 ms, so a burst of points is one hit, not a buzz.
        const now = performance.now(); if (now - (lastAt[name] || 0) < 30) return; lastAt[name] = now;
        try { fn(p); } catch {}
      },
      unlock: () => { ready(); },
    };
  }
  const sfx = makeSfx();
  // Best records per game and level, kept in this browser only (a convenience; losing them loses nothing).
  const GAME_BEST_KEY = "gfx-games-best";
  function gameBest(key) { try { return (JSON.parse(localStorage.getItem(GAME_BEST_KEY) || "{}") || {})[key]; } catch { return undefined; } }
  function saveGameBest(key, value, lower) {
    let all = {};
    try { all = JSON.parse(localStorage.getItem(GAME_BEST_KEY) || "{}") || {}; } catch {}
    const old = all[key];
    if (old != null && (lower ? value >= old : value <= old)) return false;
    all[key] = value;
    try { localStorage.setItem(GAME_BEST_KEY, JSON.stringify(all)); } catch {}
    return true;
  }
  const clock = (ms) => { const s = Math.max(0, Math.round(ms / 1000)); return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0"); };
  function makeLoadingGames(overlay) {
    const panel = el('section', 'gfx-load-games');
    panel.setAttribute('aria-label', '로딩 미니게임');
    const nav = el('div', 'gfx-game-nav'), content = el('div', 'gfx-game-content');
    const button = (label, fn, cls = '') => { const b = el('button', cls, label); b.type = 'button'; on(b, 'click', fn); return b; };
    // One picture per character of this world, for the memory cards.
    // The 말랑 extension shares its SD sprites when it is on; without it the cards are fruit.
    const faces = () => { try { return [...new Set(window.__GFX_SD_FACES?.() || [])].filter(Boolean); } catch { return []; } };
    const GAMES = {
      mines: { name: '지뢰찾기', icon: '💣', level: 'easy', levels: [['easy', '쉬움', '8×8 · 10개'], ['normal', '보통', '10×10 · 18개'], ['hard', '어려움', '12×12 · 30개']], make: (lv) => newMineGame(Math.random, lv) },
      fruits: { name: '사과 상자', icon: '🍎', level: 'normal', levels: [['easy', '쉬움', '3분 · 1~5'], ['normal', '보통', '2분 · 1~9'], ['hard', '어려움', '1분 30초']], make: (lv) => newFruitGame(Math.random, lv) },
      merge: { name: '2048', icon: '🔢', level: 'normal', levels: [['easy', '쉬움', '5×5'], ['normal', '보통', '4×4'], ['hard', '어려움', '3×3 · 256']], make: (lv) => new2048Game(Math.random, lv) },
      memory: { name: '짝 맞추기', icon: '🃏', level: 'easy', levels: [['easy', '쉬움', '6쌍'], ['normal', '보통', '8쌍'], ['hard', '어려움', '12쌍']], make: (lv) => newMemoryGame(Math.random, lv, faces()) },
      shop: { name: '쿠키 가게', icon: '🍪', level: 'normal', levels: [['easy', '쉬움', '목표 6,000원 · 손님 느긋 · ♥5'], ['normal', '보통', '목표 10,000원 · ♥4'], ['hard', '어려움', '목표 15,000원 · 손님 급함 · ♥3']], make: (lv) => newShopGame(Math.random, lv) },
      pinball: { name: '디저트 핀볼', tab: '핀볼', icon: '🎱', level: 'normal', levels: [['easy', '쉬움', '공 5개 · 볼 세이브 10초 · 넓은 플리퍼'], ['normal', '보통', '공 3개 · 볼 세이브 5초'], ['hard', '어려움', '공 3개 · 세이브 없음 · 짧은 플리퍼']], make: (lv) => newPinballGame(Math.random, lv) },
      bricks: { name: '비스킷 벽돌깨기', tab: '벽돌깨기', icon: '🧁', level: 'normal', levels: [['easy', '쉬움', '하트 5개 · 넓은 뒤집개 · 느리게'], ['normal', '보통', '하트 3개 · 초코 비스킷 한 줄'], ['hard', '어려움', '하트 3개 · 좁은 뒤집개 · 빠르게']], make: (lv) => newBrickGame(Math.random, lv) },
      block: { name: '젤리 블록', tab: '젤리 블록', icon: '🧩', level: 'normal', levels: [['easy', '쉬움', '9×9 · 작은 조각 위주'], ['normal', '보통', '8×8'], ['hard', '어려움', '8×8 · 큰 조각 자주']], make: (lv) => newBlockGame(Math.random, lv) },
      drop: { name: '마카롱 낙하', tab: '마카롱 낙하', icon: '🍬', level: 'normal', ownSfx: true, levels: [['easy', '쉬움', '10×20 · 천천히 · 보관 가능'], ['normal', '보통', '10×20 · 보관 가능'], ['hard', '어려움', '레벨 6부터 · 보관 없음']], make: (lv) => newDropGame(Math.random, lv) },
      snake: { name: '스네이크', icon: '🐍', level: 'normal', levels: [['easy', '쉬움', '12×12 · 느리게'], ['normal', '보통', '15×15'], ['hard', '어려움', '18×18 · 빠르게']], make: (lv) => newSnakeGame(Math.random, lv) },
      recipe: { name: '딸기 우유 레시피', tab: '딸기 우유', icon: '🥛', level: 'normal', levels: [['easy', '쉬움', '재료 4 · 천천히'], ['normal', '보통', '재료 4'], ['hard', '어려움', '재료 6 · 빠르게']], make: (lv) => newRecipeGame(Math.random, lv) },
      pop: { name: '초코칩 터뜨리기', tab: '초코칩', icon: '🍫', level: 'normal', levels: [['easy', '쉬움', '8×6 · 3색'], ['normal', '보통', '10×8 · 4색'], ['hard', '어려움', '12×9 · 5색']], make: (lv) => newPopGame(Math.random, lv) },
      slide: { name: '꽃밭 퍼즐', icon: '🌸', level: 'easy', levels: [['easy', '쉬움', '3×3'], ['normal', '보통', '4×4'], ['hard', '어려움', '5×5']], make: (lv) => newSlideGame(Math.random, lv) },
      lights: { name: '별 밝히기', icon: '🌟', level: 'normal', levels: [['easy', '쉬움', '4×4'], ['normal', '보통', '5×5'], ['hard', '어려움', '6×6']], make: (lv) => newLightsGame(Math.random, lv) },
      candy: { name: '캔디 크러시', tab: '캔디', icon: '🍭', level: 'normal', ownSfx: true, levels: [['easy', '쉬움', '5색 · 이동 25번'], ['normal', '보통', '6색 · 이동 20번'], ['hard', '어려움', '6색 · 이동 16번']], make: lv => newCandyGame(Math.random, lv) },
      water: { name: '물 색깔 정리', tab: '물 정리', icon: '🧪', level: 'normal', ownSfx: true, levels: [['easy', '쉬움', '3색부터 · 레벨마다 늘어남'], ['normal', '보통', '4색부터 · 레벨마다 늘어남'], ['hard', '어려움', '6색부터 · 최대 10색']], make: lv => newWaterSortGame(Math.random, lv) },
      knife: { name: '칼 던지기', tab: '칼 던지기', icon: '🔪', level: 'normal', ownSfx: true, levels: [['easy', '쉬움', '느리게 돌아요 · 칼 5개부터'], ['normal', '보통', '칼 6개부터 · 5판마다 보스'], ['hard', '어려움', '빠르게 돌아요 · 칼 7개부터']], make: lv => newKnifeGame(Math.random, lv) },
      count: { name: '인원 모으기', tab: '인원 모으기', icon: '🏃', level: 'normal', ownSfx: true, levels: [['easy', '쉬움', '5명 출발 · 적 무리 작게'], ['normal', '보통', '1명 출발'], ['hard', '어려움', '1명 출발 · 나쁜 문과 적 많이']], make: lv => newCountMastersGame(Math.random, lv) },
      dino: { name: '공룡 달리기', tab: '공룡', icon: '🦖', level: 'normal', ownSfx: true, hidden: true, levels: [['easy', '쉬움', '천천히 · 최고 속도 낮게'], ['normal', '보통', '크롬 공룡과 같은 속도'], ['hard', '어려움', '빠르게 시작 · 빨리 빨라짐']], make: lv => newDinoGame(Math.random, lv) },
    };
    const fresh = (which) => ({ game: GAMES[which].make(GAMES[which].level), level: GAMES[which].level, started: 0, stopped: 0, hints: 3, recorded: false, hideResult: false });
    const states = {};
    let eggTaps = 0, eggLast = 0, mode = '', flagMode = false, anchor = null, pointer = null, moved = false, end = null, paintNow = null;
    // Timers of the game on screen (the cookie oven, the recipe playback, the pinball frame); cleared when it changes or
    // closes. A game that runs on the clock pauses then (st.pause).
    let live = 0, frame = 0, timers = [], panelStopped = false;
    const stopTimers = () => { clearInterval(live); live = 0; cancelAnimationFrame(frame); frame = 0; timers.forEach(clearTimeout); timers = []; if (mode) states[mode]?.pause?.(); };
    const tabs = Object.entries(GAMES).filter(([, g]) => !g.hidden).map(([key, g]) => {
      const b = button('', () => show(key), 'gfx-game-tab');
      const icon = el('i', '', g.icon); icon.setAttribute('aria-hidden', 'true');
      b.append(icon, el('span', '', g.tab || g.name)); b.dataset.game = key; b.setAttribute('aria-label', g.name); b.setAttribute('aria-pressed', 'false');
      return b;
    });
    const close = button('게임 접기', () => { stopTimers(); setLarge(false); mode = ''; paintNow = null; overlay.removeAttribute('data-game'); content.replaceChildren(); tabs.forEach((b) => b.setAttribute('aria-pressed', 'false')); }, 'gfx-game-util');
    // 크게 보기: the column leaves the generation panel for the top layer (a popover), filling the window; the
    // boards are sized from the column's height, so they grow with it. Esc or [기본 크기] puts it back. Without
    // popovers it is a fixed box over the page. Leaving the page (the panel is redrawn) drops the top layer, so the
    // clock below puts it back.
    const topLayer = (big) => {
      if (typeof overlay.showPopover !== 'function') return;
      try {
        if (big) { if (!overlay.hasAttribute('popover')) overlay.setAttribute('popover', 'manual'); if (overlay.isConnected && !overlay.matches(':popover-open')) overlay.showPopover(); }
        else if (overlay.hasAttribute('popover')) { if (overlay.matches(':popover-open')) overlay.hidePopover(); overlay.removeAttribute('popover'); }
      } catch {}
    };
    const setLarge = (big) => {
      overlay.toggleAttribute('data-game-large', big); topLayer(big);
      enlarge.textContent = big ? '기본 크기' : '크게 보기'; enlarge.setAttribute('aria-pressed', String(big));
      if (mode) requestAnimationFrame(() => paintNow?.());
    };
    const enlarge = button('크게 보기', () => setLarge(!overlay.hasAttribute('data-game-large')), 'gfx-game-util');
    on(panel, 'keydown', (e) => { if (e.key === 'Escape' && overlay.hasAttribute('data-game-large')) { e.preventDefault(); setLarge(false); } });
    const sound = button('', () => { sfx.enabled = !sfx.enabled; paintSound(); if (sfx.enabled) sfx.play('tap'); }, 'gfx-game-util');
    const paintSound = () => { sound.textContent = sfx.enabled ? '🔊 소리' : '🔇 소리'; sound.setAttribute('aria-pressed', String(sfx.enabled)); sound.setAttribute('aria-label', sfx.enabled ? '효과음 켜짐' : '효과음 꺼짐'); };
    paintSound();
    const utils = el('div', 'gfx-game-utils');
    utils.append(enlarge, sound, close);
    nav.append(...tabs, utils); panel.append(nav, content);
    // The 말랑 colour preset picks the box game's fruit and the minesweeper palette (custom colours: a dark ground
    // reads as 밤하늘, anything else as 크림).
    const GAME_THEMES = { cream: ['사과 상자', '🍎'], berry: ['딸기 상자', '🍓'], mint: ['청사과 상자', '🍏'], lavender: ['포도 상자', '🍇'], night: ['별 상자', '⭐'] };
    // Colours as [r, g, b, a] from any CSS colour (hex, rgb(), color-mix()), read back through a hidden probe.
    const probe = el('i'); probe.hidden = true; panel.append(probe);
    const rgba = (value) => {
      probe.style.color = ''; probe.style.color = value;
      const c = getComputedStyle(probe).color, n = (c.match(/[\d.]+/g) || []).map(Number);
      if (/^color\(/.test(c)) return [n[0] * 255, n[1] * 255, n[2] * 255, n.length > 3 ? n[3] : 1];
      return n.length >= 3 ? [n[0], n[1], n[2], n.length > 3 ? n[3] : 1] : null;
    };
    const hex = ([r, g, b]) => '#' + [r, g, b].map((v) => Math.round(Math.max(0, Math.min(255, v))).toString(16).padStart(2, '0')).join('');
    const mix = (a, b, w) => a.map((v, i) => v * w + b[i] * (1 - w));
    const lum = ([r, g, b]) => (0.299 * r + 0.587 * g + 0.114 * b) / 255;
    // Without 말랑 the game's own UI style (기본·오로라·블룸·시그널·엠버, or one an extension adds) dresses the games:
    // its surface, text, accent and corner radius, read from the tokens every style sets on the game's arena.
    const SKIN = ['--gfx-card', '--gfx-text', '--gfx-line', '--gfx-ink', '--gfx-pick', '--gfx-accent', '--gfx-r', '--gfx-pill'];
    const gameSkin = () => {
      try {
        const host = overlay.getRootNode?.()?.host;
        if (host?.getAttribute('data-gfx-style') === 'trickcal') return null;
        const cs = getComputedStyle(overlay), tok = (k) => cs.getPropertyValue(k).trim();
        if (!tok('--surface') || !tok('--coral')) return null;
        const ground = rgba(tok('--ground-1') || tok('--ink-2') || '#17212F'), surf = rgba(tok('--surface')), text = rgba(tok('--on-surface') || tok('--text'));
        const accent = rgba(tok('--coral')), steel = rgba(tok('--steel') || '#4A6E96'), dark = rgba(tok('--steel-dark') || '#23374F'), faint = rgba(tok('--steel-faint') || '#8AA2BC');
        if (!ground || !surf || !text || !accent) return null;
        // A see-through surface (오로라, 시그널) is laid over the ground to give a solid card.
        const card = mix(surf, ground, surf[3]), light = lum(card) > 0.55;
        const line = light ? mix(dark, card, 0.9) : mix(steel, ground, 0.4);
        const ink = light ? mix(card, faint, 0.82) : mix(card, ground, 0.55);
        const r = parseFloat(tok('--radius')) || 0, rs = parseFloat(tok('--radius-sm')) || 0;
        return { '--gfx-card': hex(card), '--gfx-text': hex(text), '--gfx-line': hex(line), '--gfx-ink': hex(ink), '--gfx-pick': hex(light ? mix(accent, card, 0.3) : mix(steel, card, 0.5)),
          '--gfx-accent': hex(accent), '--gfx-r': Math.max(r, 2) + 'px', '--gfx-pill': r >= 14 ? '999px' : Math.max(rs + 2, 3) + 'px', dark: !light };
      } catch { return null; }
    };
    const themeNow = (skin) => {
      try {
        if (skin) return skin.dark ? 'night' : 'cream';
        // 말랑 marks its preset on the game element; a picked palette is judged by its ground colour.
        const preset = overlay.getRootNode?.()?.host?.getAttribute('data-gfx-preset') || '';
        if (GAME_THEMES[preset]) return preset;
        const ink = rgba(getComputedStyle(overlay).getPropertyValue('--gfx-ink').trim() || '#FFF4D9');
        if (ink && lum(ink) < 0.4) return 'night';
      } catch {}
      return 'cream';
    };
    let skinKey = '';
    const retheme = () => {
      const skin = gameSkin(), key = skin ? JSON.stringify(skin) : '';
      if (key !== skinKey) { skinKey = key; for (const k of SKIN) if (skin) panel.style.setProperty(k, skin[k]); else panel.style.removeProperty(k); }
      panel.toggleAttribute('data-skin', !!skin);
      const t = themeNow(skin), [name, icon] = GAME_THEMES[t], tab = tabs.find((b) => b.dataset.game === 'fruits');
      panel.dataset.theme = t; GAMES.fruits.name = name; GAMES.fruits.icon = icon;
      tab.setAttribute('aria-label', name); tab.querySelector('i').textContent = icon; tab.querySelector('span').textContent = name;
    };
    retheme();
    panel.retheme = retheme;
    for (const event of ['pointerdown', 'pointerup', 'click', 'dblclick', 'keydown', 'keyup']) on(panel, event, (e) => e.stopPropagation());
    // The clock: time-attack countdown and elapsed time. Stops by itself once the panel has been gone a while.
    let goneSince = 0, beat = 0;
    const tick = setInterval(() => {
      if (!panel.isConnected) { goneSince ||= performance.now(); if (performance.now() - goneSince > 60000) clearInterval(tick); return; }
      goneSince = 0;
      if (paintNow && !document.hidden) paintNow(true);
      // Once a second: follow a UI style picked meanwhile, and keep 크게 보기 in the top layer.
      if (++beat % 4 === 0) { retheme(); if (overlay.hasAttribute('data-game-large')) topLayer(true); }
    }, 250);
    panel.dispose = () => { panelStopped = true; clearInterval(tick); stopTimers(); };
    /* Sound for every game: each frame the game on screen is compared with the last frame (points, rows, hearts,
     * cells opened, the end), and what changed is heard; a strong hit also bumps the board. A game that plays its
     * own sounds (ownSfx) is left to itself. */
    on(panel, 'pointerdown', (e) => {
      sfx.unlock();
      const b = e.target.closest?.('button');
      if (b && !b.closest('.gfx-game-board, .gfx-pin-pad, .gfx-drop-pad')) sfx.play('tap');
    });
    const bump = (how) => {
      const b = content.querySelector('.gfx-game-board');
      if (!b?.animate || matchMedia('(prefers-reduced-motion: reduce)').matches) return;
      const k = how === 'shake' ? [{ translate: '0 0' }, { translate: '-4px 0' }, { translate: '4px 0' }, { translate: '-2px 0' }, { translate: '0 0' }]
        : [{ translate: '0 0', scale: 1 }, { translate: '0 ' + (how === 'big' ? 6 : 3) + 'px', scale: how === 'big' ? 0.985 : 1 }, { translate: '0 0', scale: 1 }];
      b.animate(k, { duration: how === 'shake' ? 260 : 150, easing: 'ease-out' });
    };
    panel.sfx = sfx; panel.bump = bump;
    const snap = (g) => {
      let open = 0, done = 0;
      if (Array.isArray(g.cells) && g.cells[0] && typeof g.cells[0] === 'object') for (const c of g.cells) { if (c.open) open++; if (c.done) done++; }
      return { g, s: g.score ?? g.money ?? 0, e: !!g.ended, w: g.won, m: g.moves || 0, l: g.lives ?? g.hearts ?? g.balls ?? 0, n: g.lines || 0,
        r: (g.round || 0) + (g.stage || 0), a: g.at || 0, bo: g.bounces || 0, f: g.flippers ? g.flippers.filter((x) => x.held).length : 0,
        bricks: g.bricks ? g.bricks.length : 0, open, done, fr: g.fresh ?? -1, sv: g.served || 0, len: g.body ? g.body.length : 0 };
    };
    let heard = null;
    const listen = () => {
      if (life.signal.aborted || panelStopped) return;
      requestAnimationFrame(listen);
      if (!panel.isConnected || document.hidden || !mode || GAMES[mode]?.ownSfx) { heard = null; return; }
      const g = states[mode]?.game; if (!g) return;
      const c = snap(g), p = heard; heard = c;
      if (!p || p.g !== g) return;
      if (c.e && !p.e) { sfx.play(c.w === false ? 'lose' : c.w ? 'win' : 'end'); if (c.w === false) bump('shake'); return; }
      if (c.l < p.l) { sfx.play('hurt'); bump('shake'); navigator.vibrate?.(30); }
      if (c.r > p.r) sfx.play('level');
      if (c.n > p.n) { sfx.play('clear', c.n - p.n); bump('big'); }
      else if (c.done > p.done) sfx.play('match');
      else if (c.s > p.s) {
        const d = c.s - p.s;
        if (mode === 'shop') sfx.play('coin');
        else if (mode === 'snake' || mode === 'fruits') sfx.play('pop', Math.min(4, d));
        else { const pw = d >= 300 ? 3 : d >= 40 ? 2 : 1; sfx.play('hit', pw); if (pw > 1) bump(pw > 2 ? 'big' : 'small'); }
      }
      else if (c.bricks < p.bricks) sfx.play('hit', 1);
      else if (c.open > p.open) sfx.play(mode === 'memory' ? 'flip' : 'pop', Math.min(4, c.open - p.open));
      else if (c.fr !== p.fr || c.m > p.m) sfx.play('move');
      else if (c.a > p.a) sfx.play('pop', c.a % 5);
      if (c.bo > p.bo) sfx.play('bounce');
      if (c.f > p.f) sfx.play('flip');
    };
    requestAnimationFrame(listen);
    function show(next) {
      stopTimers(); mode = next; anchor = null; pointer = null; overlay.setAttribute('data-game', mode); retheme();
      tabs.forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.game === mode)));
      const g = GAMES[mode], st = states[mode] ||= fresh(mode), game = st.game;
      content.replaceChildren();
      content.dataset.kind = mode;
      const head = el('div', 'gfx-game-head'), title = el('b', 'gfx-game-title'), stats = el('div', 'gfx-game-stats');
      const titleIcon = el('i', '', g.icon); titleIcon.setAttribute('aria-hidden', 'true');
      // Easter egg: tap a game's icon five times quickly for the hidden offline T-Rex.
      on(titleIcon, 'click', () => {
        const now = performance.now(); eggTaps = now - eggLast < 600 ? eggTaps + 1 : 1; eggLast = now;
        if (eggTaps >= 5 && mode !== 'dino') { eggTaps = 0; sfx.play('level'); show('dino'); }
      });
      title.append(titleIcon, el('span', '', g.name));
      const tools = el('div', 'gfx-game-tools'), levels = el('div', 'gfx-game-levels');
      levels.setAttribute('role', 'radiogroup'); levels.setAttribute('aria-label', '난이도 (바꾸면 새 판)');
      for (const [value, label, detail] of g.levels) {
        const b = button(label, () => { if (st.level === value) return; stopTimers(); g.level = value; states[mode] = fresh(mode); show(mode); });
        // One short word per level; the board size or time is in its tooltip and accessible name.
        b.title = detail; b.setAttribute('role', 'radio'); b.setAttribute('aria-checked', String(st.level === value)); b.setAttribute('aria-label', label + ' ' + detail);
        levels.append(b);
      }
      const renew = () => { stopTimers(); states[mode] = fresh(mode); show(mode); };
      tools.append(levels, button('새 판', renew, 'gfx-game-new'));
      const info = el('div', 'gfx-game-info'), stage = el('div', 'gfx-game-stage'), board = el('div', 'gfx-game-board'), result = el('div', 'gfx-game-result');
      info.setAttribute('aria-live', 'polite'); result.hidden = true;
      on(result, 'click', (e) => { if (e.target === result) { st.hideResult = true; result.hidden = true; } });
      stage.append(board, result);
      // Title, level, new game (and the game's own tool) and the counters share one compact row.
      head.append(title, tools, stats);
      content.append(head, info, stage);
      const best = () => gameBest(mode + '-' + st.level);
      const begin = () => { if (!st.started) st.started = performance.now(); };
      const elapsed = () => st.started ? (st.stopped || performance.now()) - st.started : 0;
      const finish = (lower, value) => {
        if (st.stopped) return;
        st.stopped = performance.now();
        if (value != null && !st.recorded) { st.recorded = true; st.newBest = saveGameBest(mode + '-' + st.level, value, lower); }
      };
      const chips = (list) => stats.replaceChildren(...list.filter(Boolean).map(([text, alert]) => { const s = el('span', '', text); if (alert) s.dataset.alert = ''; return s; }));
      const showResult = (headline, line) => {
        if (st.hideResult) { result.hidden = true; return; }
        if (!result.hidden && result.dataset.headline === headline) return;
        const card = el('div'), again = button('다시 하기', renew, 'gfx-game-again');
        card.append(el('b', '', headline), el('span', '', line));
        if (st.newBest) card.append(el('em', '', '최고 기록!'));
        card.append(again);
        result.dataset.headline = headline; result.replaceChildren(card); result.hidden = false;
      };
      board.style.setProperty('--cols', String(game.cols));
      // The board's shape, for its size: the fruit box is wide, the memory cards are 3:4.
      board.style.setProperty('--fit', String(['fruits', 'pop'].includes(mode) ? game.cols / game.rows : mode === 'memory' ? game.cols * 3 / (game.rows * 4) : mode === 'shop' ? 0.95 : 1));
      board.dataset.kind = mode;
      let paint = () => {};

      if (mode === 'mines') {
        const flags = button('깃발 모드', () => { flagMode = !flagMode; flags.setAttribute('aria-pressed', String(flagMode)); }, 'gfx-game-flag');
        flags.setAttribute('aria-pressed', String(flagMode)); tools.append(flags);
        let held = null, heldFired = false;
        const buttons = game.cells.map((_, i) => {
          const b = button('', () => {
            if (heldFired) { heldFired = false; return; }
            const c = game.cells[i];
            if (c.open) game.chord(i);
            else if (flagMode) game.flag(i);
            else { begin(); game.reveal(i); }
            paint();
          });
          b.dataset.cell = String(i); board.append(b);
          on(b, 'contextmenu', (e) => { e.preventDefault(); game.flag(i); paint(); });
          // Touch: press and hold to place a flag.
          on(b, 'pointerdown', (e) => { if (e.pointerType !== 'touch') return; clearTimeout(held); heldFired = false; held = setTimeout(() => { if (!game.cells[i].open) { game.flag(i); heldFired = true; navigator.vibrate?.(15); paint(); } }, 430); });
          for (const t of ['pointerup', 'pointercancel', 'pointerleave']) on(b, t, () => clearTimeout(held));
          return b;
        });
        paint = (clockOnly) => {
          const flags = game.cells.filter((c) => c.flag).length, b0 = best();
          chips([['💣 ' + Math.max(0, game.mines - flags)], ['⏱ ' + clock(elapsed())], b0 != null && ['🏆 ' + clock(b0 * 1000)]]);
          if (clockOnly) return;
          if (game.ended) finish(true, game.won ? Math.round(elapsed() / 1000) : null);
          info.textContent = game.ended ? (game.won ? '성공! 지뢰를 모두 피했어요.' : '펑! 지뢰를 밟았어요.') : !game.started ? '첫 칸은 언제나 안전해요 · 우클릭/길게 눌러 깃발' : '숫자를 누르면 깃발 수가 맞을 때 주변이 한 번에 열려요';
          buttons.forEach((b, i) => {
            const c = game.cells[i], showMine = c.mine && game.ended && !c.flag;
            b.textContent = c.flag ? '깃발' : c.open && !c.mine ? (c.count || '') : '';
            b.dataset.open = String(c.open); b.dataset.flag = String(c.flag); b.dataset.n = c.open && !c.mine ? String(c.count) : '';
            b.dataset.mine = String(showMine); b.dataset.boom = String(i === game.boom); b.dataset.wrong = String(game.ended && !game.won && c.flag && !c.mine);
            b.disabled = game.ended;
            b.setAttribute('aria-label', (i + 1) + '번 칸 ' + (c.flag ? '깃발' : c.open ? (c.mine ? '지뢰' : '주변 지뢰 ' + c.count) : '닫힘'));
          });
          if (game.ended) showResult(game.won ? '클리어!' : '게임 오버', game.won ? '기록 ' + clock(elapsed()) : '새 판으로 다시 도전해 보세요');
        };
      }

      if (mode === 'fruits') {
        let hintIds = [], hintTimer = 0;
        const hint = button('힌트', () => {
          if (game.ended || st.hints <= 0) return;
          const m = game.findMove(); if (!m) return;
          st.hints--; hintIds = game.select(m.a, m.b).ids; clearTimeout(hintTimer);
          hintTimer = setTimeout(() => { hintIds = []; paint(); }, 1600); paint();
        }, 'gfx-game-hint');
        tools.append(hint);
        const buttons = game.cells.map((_, i) => {
          const b = button('', () => {
            // Keyboard and assistive-technology activation uses the same two-corner selection.
            if (pointer !== null || game.ended) return;
            begin();
            if (anchor === null) anchor = i; else { game.select(anchor, i, true); anchor = null; }
            paint();
          });
          b.dataset.cell = String(i); board.append(b);
          return b;
        });
        // The dragged rectangle, drawn as one thick box round the cells with the running sum on its corner:
        // tinting each apple alone was hard to see.
        // No running sum on it: adding the apples up is the game.
        const frame = el('div', 'gfx-fruit-frame');
        frame.setAttribute('aria-hidden', 'true'); frame.hidden = true; board.append(frame);
        const placeFrame = (selected) => {
          if (!selected || game.ended) { frame.hidden = true; return; }
          const first = buttons[Math.min(...selected.ids)], last = buttons[Math.max(...selected.ids)];
          frame.style.left = first.offsetLeft + 'px'; frame.style.top = first.offsetTop + 'px';
          frame.style.width = (last.offsetLeft + last.offsetWidth - first.offsetLeft) + 'px';
          frame.style.height = (last.offsetTop + last.offsetHeight - first.offsetTop) + 'px';
          frame.dataset.state = selected.sum === 10 ? 'ok' : selected.sum > 10 ? 'over' : '';
          frame.hidden = false;
        };
        const left = () => game.time * 1000 - elapsed();
        paint = (clockOnly, selection = null) => {
          if (!game.ended && st.started && left() <= 0) { game.ended = true; anchor = null; }
          const b0 = best(), remain = st.started ? left() : game.time * 1000;
          chips([[g.icon + ' ' + game.score + '점'], ['⏱ ' + clock(remain), st.started && !game.ended && remain < 15000], b0 != null && ['🏆 ' + b0 + '점']]);
          hint.textContent = '힌트 ' + st.hints; hint.disabled = game.ended || st.hints <= 0;
          if (clockOnly && (!game.ended || st.endPainted)) return;
          // Only after a move, not on every drag step: the search is the costly part.
          if (!game.ended && st.started && !selection && !game.findMove()) game.ended = true;
          st.endPainted = game.ended;
          if (game.ended) finish(false, game.score);
          const selected = selection || (anchor !== null ? game.select(anchor, anchor) : null);
          info.replaceChildren(document.createTextNode('점수 ' + game.score + ' · '));
          if (game.ended) info.append(left() <= 0 ? '시간 종료!' : '더 지울 수 있는 사과가 없어요');
          else if (selected) info.append('합이 10이면 손을 떼세요');
          else info.append(st.started ? '합이 10이 되게 사각형으로 묶으세요' : '합이 10이 되게 드래그하세요 · 첫 선택부터 시간이 흘러요');
          buttons.forEach((b, i) => {
            const v = game.cells[i];
            b.replaceChildren(); if (v) b.append(el('span', '', String(v)));
            b.dataset.empty = String(!v); b.dataset.selected = String(!!selected?.ids.includes(i)); b.dataset.hint = String(hintIds.includes(i));
            b.dataset.ok = String(!!selected && selected.sum === 10);
            b.disabled = game.ended;
            b.setAttribute('aria-label', (i + 1) + '번 사과 ' + v);
          });
          placeFrame(selected);
          if (game.ended) showResult(left() <= 0 ? '시간 종료!' : '상자 정리 끝!', '사과 ' + game.score + '개를 지웠어요');
        };
        // Measured from the first and last cell, not the board box: the board's padding put a drag one row off.
        const cellAt = (e) => {
          const r0 = buttons[0].getBoundingClientRect(), r1 = buttons.at(-1).getBoundingClientRect();
          if (e.clientX < r0.left || e.clientX >= r1.right || e.clientY < r0.top || e.clientY >= r1.bottom) return null;
          const x = Math.floor((e.clientX - r0.left) / (r1.right - r0.left) * game.cols), y = Math.floor((e.clientY - r0.top) / (r1.bottom - r0.top) * game.rows);
          return Math.min(game.rows - 1, Math.max(0, y)) * game.cols + Math.min(game.cols - 1, Math.max(0, x));
        };
        on(board, 'pointerdown', (e) => { if (e.button !== 0 || pointer !== null || game.ended) return; const i = cellAt(e); if (i === null) return; e.preventDefault(); begin(); pointer = e.pointerId; moved = false; end = i; if (anchor === null) anchor = i; board.setPointerCapture(e.pointerId); paint(false, game.select(anchor, i)); });
        on(board, 'pointermove', (e) => { if (pointer !== e.pointerId) return; const i = cellAt(e); if (i !== null) { moved ||= i !== end; end = i; paint(false, game.select(anchor, end)); } });
        on(board, 'pointerup', (e) => { if (pointer !== e.pointerId) return; e.preventDefault(); if (moved || end !== anchor) { game.select(anchor, end, true); anchor = null; } pointer = null; board.releasePointerCapture(e.pointerId); paint(); });
        on(board, 'pointercancel', () => { pointer = null; anchor = null; paint(); });
        // Pointer input is handled above; prevent its synthetic click from selecting twice.
        on(board, 'click', (e) => { if (e.detail) { e.preventDefault(); e.stopImmediatePropagation(); } }, { capture: true });
      }

      if (mode === 'merge') {
        board.tabIndex = 0; board.setAttribute('role', 'application'); board.setAttribute('aria-label', '2048 판 · 방향키나 스와이프로 밀기');
        const tiles = game.cells.map((_, i) => { const t = el('div'); t.dataset.cell = String(i); board.append(t); return t; });
        const pad = el('div', 'gfx-game-pad');
        const push = (dir) => { if (game.ended) return; begin(); if (game.move(dir)) paint(); board.focus({ preventScroll: true }); };
        for (const [dir, label, arrow] of [['up', '위로', '▲'], ['left', '왼쪽으로', '◀'], ['down', '아래로', '▼'], ['right', '오른쪽으로', '▶']]) { const b = button(arrow, () => push(dir)); b.setAttribute('aria-label', label); b.dataset.dir = dir; pad.append(b); }
        stage.append(pad);
        const KEYS = { ArrowUp: 'up', ArrowDown: 'down', ArrowLeft: 'left', ArrowRight: 'right', w: 'up', s: 'down', a: 'left', d: 'right', W: 'up', S: 'down', A: 'left', D: 'right' };
        on(board, 'keydown', (e) => { const dir = KEYS[e.key]; if (!dir) return; e.preventDefault(); push(dir); });
        let from = null;
        on(board, 'pointerdown', (e) => { from = [e.clientX, e.clientY, e.pointerId]; board.setPointerCapture?.(e.pointerId); });
        on(board, 'pointerup', (e) => {
          if (!from || from[2] !== e.pointerId) return;
          const dx = e.clientX - from[0], dy = e.clientY - from[1]; from = null;
          if (Math.max(Math.abs(dx), Math.abs(dy)) < 24) { board.focus({ preventScroll: true }); return; }
          push(Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 'right' : 'left') : (dy > 0 ? 'down' : 'up'));
        });
        on(board, 'pointercancel', () => { from = null; });
        let shownWin = false;
        paint = (clockOnly) => {
          const b0 = best(), top = Math.max(...game.cells);
          chips([['⭐ ' + game.score], ['🔝 ' + top], b0 != null && ['🏆 ' + b0]]);
          if (clockOnly) return;
          if (game.ended) finish(false, game.score);
          info.textContent = game.ended ? '더 움직일 수 없어요.' : game.won ? game.goal + ' 달성! 계속 더 높이 올라가 보세요.' : '같은 숫자끼리 밀어서 합치세요 · 목표 ' + game.goal + ' · 방향키·스와이프';
          tiles.forEach((t, i) => {
            const v = game.cells[i];
            t.textContent = v || ''; t.dataset.v = String(v); t.dataset.d = String(String(v).length);
            t.toggleAttribute('data-new', i === game.fresh); t.toggleAttribute('data-merged', game.merged.includes(i));
          });
          if (game.ended) showResult('게임 끝', '점수 ' + game.score + ' · 최고 타일 ' + top);
          else if (game.won && !shownWin && !st.shownWin) { shownWin = st.shownWin = true; info.textContent = '🎉 ' + game.goal + ' 달성! 계속할 수 있어요.'; }
        };
      }

      if (mode === 'memory') {
        let busy = 0;
        const buttons = game.cells.map((c, i) => {
          const b = button('', () => {
            if (busy) return;
            begin();
            const r = game.flip(i);
            if (r === 'miss') { busy = setTimeout(() => { busy = 0; game.hide(); paint(); }, 800); }
            paint();
          });
          b.dataset.cell = String(i); board.append(b);
          const face = el('span', 'face');
          if (/^(blob:|https?:|\/|data:)/.test(c.face)) { const img = typeof heroNode === 'function' ? heroNode(c.face) : Object.assign(el('img'), { src: c.face, alt: '' }); face.append(img); }
          else face.append(el('i', '', c.face));
          b.append(face, el('span', 'back'));
          return b;
        });
        paint = (clockOnly) => {
          const b0 = best(), found = game.cells.filter((c) => c.done).length / 2;
          chips([['🃏 ' + found + '/' + game.pairs], ['🔁 ' + game.moves + '번'], ['⏱ ' + clock(elapsed())], b0 != null && ['🏆 ' + b0 + '번']]);
          if (clockOnly) return;
          if (game.ended) finish(true, game.moves);
          info.textContent = game.ended ? '모두 찾았어요!' : '같은 그림 두 장을 찾아 뒤집으세요';
          buttons.forEach((b, i) => { const c = game.cells[i]; b.dataset.open = String(c.open); b.dataset.done = String(c.done); b.setAttribute('aria-label', (i + 1) + '번 카드 ' + (c.open ? '앞면' : '뒷면')); });
          if (game.ended) showResult('완성!', game.moves + '번 만에 ' + clock(elapsed()));
        };
      }
      if (mode === 'shop') {
        const NAME = Object.fromEntries(SHOP_TOOLS);
        const people = faces();
        let tool = 'butter';
        // The shop front: awning and sign, the window, the menu board, the guests and the counter.
        const front = el('div', 'gfx-shop-front');
        const awning = el('div', 'gfx-shop-awning'), sign = el('b', 'gfx-shop-sign', '말랑 쿠키');
        const win = el('div', 'gfx-shop-window'), menu = el('div', 'gfx-shop-menu');
        menu.append(el('b', '', 'MENU'), ...Object.entries(SHOP_ORDERS).map(([k, label]) => { const r = el('span'); r.innerHTML = SHOP_COOKIE_SVG(k); r.append(el('i', '', label)); return r; }));
        const guests = el('div', 'gfx-shop-guests'), counter = el('div', 'gfx-shop-counter'), say = el('span', 'gfx-shop-say'), till = el('span', 'gfx-shop-till');
        counter.append(say, till);
        front.append(awning, sign, win, menu, guests, counter);
        // Each guest keeps one node while they wait; one who leaves walks off.
        const seated = new Map();
        const guestNode = (g) => {
          const n = el('div', 'gfx-shop-guest'), fig = el('span', 'fig'), order = el('span', 'order'), wait = el('i', 'wait');
          if (people.length) { const img = el('img'); img.alt = ''; img.src = people[g.id % people.length]; fig.append(img); fig.dataset.sd = ''; }
          else { fig.innerHTML = SHOP_GUEST_SVG; const [hair, shirt] = SHOP_GUEST_LOOKS[g.id % SHOP_GUEST_LOOKS.length]; fig.style.setProperty('--hair', hair); fig.style.setProperty('--shirt', shirt); }
          order.innerHTML = SHOP_COOKIE_SVG(g.want); order.append(el('i', '', SHOP_ORDERS[g.want]));
          order.append(wait); n.append(order, fig); n.dataset.want = g.want;
          return { n, wait };
        };
        // The shelf: pick a tool, then press an oven (or keys 1–7).
        const shelf = el('div', 'gfx-shop-shelf');
        const tools7 = SHOP_TOOLS.map(([k, label], n) => {
          const b = button('', () => { tool = k; paint(); }, 'gfx-shop-tool');
          const icon = el('span', 'icon'); icon.innerHTML = '<svg viewBox="0 0 44 44" aria-hidden="true">' + SHOP_TOOL_SVG[k] + '</svg>';
          b.append(el('kbd', '', String(n + 1)), icon, el('span', 'label', label)); b.dataset.tool = k; b.title = label + ' · ' + (n + 1) + '번 키'; shelf.append(b);
          return b;
        });
        // The dial's coloured zones: raw, golden, too long; the rest of the half circle is burnt.
        const span = game.bake + game.ready + game.over, arc = (a, b, cls) => {
          const p = (t) => [50 + 8.5 * Math.cos(Math.PI + Math.PI * t), 22 + 8.5 * Math.sin(Math.PI + Math.PI * t)].map((v) => v.toFixed(2)).join(' ');
          return '<path class="' + cls + '" d="M' + p(a) + 'A8.5 8.5 0 0 1 ' + p(b) + '"/>';
        };
        const zones = arc(0, game.bake / span, 'z-raw') + arc(game.bake / span, (game.bake + game.ready) / span, 'z-ready') + arc((game.bake + game.ready) / span, 1, 'z-over');
        const kitchen = el('div', 'gfx-shop-ovens');
        const ovens = game.ovens.map((_, i) => {
          const b = button('', () => {
            if (game.ended) return;
            const now = performance.now();
            begin(); game.open(now); if (!live) go();
            const r = game.use(tool, i, now);
            if (r === 'served') { coin(i, game.last); if (game.last.perfect) sparkle(i); }
            if (r === 'nobody') say.textContent = '기다리는 손님이 없어요';
            if (r === '' && tool !== 'serve') { b.dataset.nope = ''; timers.push(setTimeout(() => delete b.dataset.nope, 300)); }
            paint(false, r === 'nobody');
          });
          b.className = 'gfx-shop-oven'; b.dataset.oven = String(i);
          b.innerHTML = SHOP_OVEN_SVG(zones);
          const tag = el('span', 'tag'); b.append(tag); kitchen.append(b);
          return { b, tag };
        });
        // +price over the oven that served, and a burst of stars for a perfect cookie.
        const coin = (i, last) => {
          const p = el('span', 'gfx-shop-coin', '+' + last.price.toLocaleString() + (last.tip ? ' (팁)' : ''));
          if (!last.price) p.dataset.zero = '';
          p.style.left = (12.5 + i * 25) + '%'; board.append(p); timers.push(setTimeout(() => p.remove(), 1100));
        };
        const sparkle = (i) => { const s = el('span', 'gfx-shop-sparkle'); s.style.left = (12.5 + i * 25) + '%'; board.append(s); timers.push(setTimeout(() => s.remove(), 900)); };
        board.append(front, shelf, kitchen);
        on(board, 'keydown', (e) => { const n = Number(e.key); if (n >= 1 && n <= SHOP_TOOLS.length) { tool = SHOP_TOOLS[n - 1][0]; e.preventDefault(); paint(); } });
        board.tabIndex = 0;
        const go = () => { clearInterval(live); live = setInterval(() => { if (!game.ended) paint(); }, 100); };
        // Leaving the shop for another game pauses it: the clocks move on by the time away.
        if (st.pausedAt) { const d = performance.now() - st.pausedAt; st.pausedAt = 0; if (st.started && !game.ended) { game.shift(d); st.started += d; } }
        st.pause = () => { if (st.started && !game.ended) st.pausedAt = performance.now(); };
        if (st.started && !game.ended) go();
        let lastSaid;
        paint = (clockOnly, keepSay) => {
          const now = performance.now(), b0 = best();
          if (!clockOnly) game.update(now);
          chips([['🪙 ' + game.money.toLocaleString() + ' / ' + game.goal.toLocaleString()], ['♥'.repeat(Math.max(0, game.hearts)) || '♡', game.hearts <= 1], ['예비 오븐 ' + game.spares, !game.spares], ['⏱ ' + clock(elapsed())], b0 != null && ['🏆 ' + clock(b0 * 1000)]]);
          if (clockOnly && (!game.ended || st.endPainted)) return;
          st.endPainted = game.ended;
          if (game.ended) finish(true, game.won ? Math.round(elapsed() / 1000) : null);
          // The counter: the last guest's word, and the till.
          if (game.last !== lastSaid && !keepSay) {
            lastSaid = game.last;
            say.textContent = game.last ? game.last.line + (game.last.price != null ? ' ' + game.last.price.toLocaleString() + '원' : '') : (st.started ? '어서 오세요!' : '오늘도 영업 시작!');
            say.dataset.mood = !game.last ? '' : game.last.gone || game.last.price < 500 ? 'bad' : game.last.perfect ? 'good' : '';
            if (game.last) { delete say.dataset.pop; void say.offsetWidth; say.dataset.pop = ''; }
          }
          till.textContent = game.money.toLocaleString() + '원';
          // The guests: newcomers step in, those served or tired of waiting step out.
          const here = new Set(game.queue.map((g) => g.id));
          for (const [id, s] of seated) if (!here.has(id)) {
            seated.delete(id); s.n.dataset.leave = game.last && game.last.guest === id && !game.last.gone ? (game.last.price >= 800 ? 'happy' : 'ok') : 'angry';
            timers.push(setTimeout(() => s.n.remove(), 700));
          }
          game.queue.forEach((g) => {
            let s = seated.get(g.id);
            if (!s) { s = guestNode(g); seated.set(g.id, s); guests.append(s.n); }
            const left = Math.max(0, 1 - (now - g.came) / game.patience);
            s.wait.style.setProperty('--w', left.toFixed(3));
            s.n.dataset.mood = left > 0.55 ? 'happy' : left > 0.25 ? 'ok' : 'angry';
            s.n.setAttribute('aria-label', '손님 · ' + SHOP_ORDERS[g.want] + ' 쿠키 주문');
          });
          info.textContent = game.ended ? (game.won ? '목표 달성! 오늘 장사 끝~' : game.hearts <= 0 ? '손님들이 화가 나서 다 가 버렸어요…' : '오븐이 모두 타 버렸어요…')
            : !st.started ? '버터 → 불 켜기 → (예열 램프가 초록이면) 반죽 → 설탕 · 김이 나면 주문대로 토핑 → 접시'
            : '도구: ' + NAME[tool] + ' · 오븐을 누르세요 (숫자키 1~7)';
          tools7.forEach((b) => { b.setAttribute('aria-pressed', String(b.dataset.tool === tool)); b.disabled = game.ended; });
          game.ovens.forEach((o, i) => {
            const v = ovens[i], stage = game.stage(o, now), d = v.b.dataset;
            d.stage = stage || 'cold';
            v.b.disabled = game.ended || o === null;
            if (o) {
              d.butter = String(o.butter); d.lit = String(o.lit != null); d.dough = String(o.dough != null); d.flat = String(o.flat); d.sugar = String(o.sugar);
              d.chip = String(!!o.chip); d.cream = String(!!o.cream);
              // An empty oven smokes once it has been hot a while.
              d.warn = String(o.dough == null ? stage === 'hot' && game.dial(o, now) > 0.7 : stage === 'over');
            }
            v.b.style.setProperty('--p', game.dial(o, now).toFixed(3));
            const words = { cold: o && o.butter ? '버터 OK' : '대기', heat: '예열 중…', hot: '예열 완료!', raw: '굽는 중', ready: '지금! 노릇노릇', over: '타기 직전!', burnt: '탔다! 눌러서 치우기', gone: '고장' };
            v.tag.textContent = words[d.stage];
            v.b.setAttribute('aria-label', '오븐 ' + (i + 1) + ' · ' + words[d.stage]);
          });
          if (game.ended) showResult(game.won ? '오늘의 목표 달성!' : '가게 문을 닫았어요', '🪙 ' + game.money.toLocaleString() + '원 (팁 ' + game.tips.toLocaleString() + ') · 쿠키 ' + game.served + '개 · 완벽 ' + game.perfect + '개');
        };
      }

      if (mode === 'pinball') {
        const { W, H, R, LANE } = game;
        board.style.setProperty('--fit', (W / (H + 70)).toFixed(3));
        const canvas = el('canvas', 'gfx-pin-table'), ctx = canvas.getContext('2d');
        canvas.setAttribute('role', 'img'); canvas.setAttribute('aria-label', '핀볼 테이블');
        const pad = el('div', 'gfx-pin-pad');
        const hold = (b, down, up) => {
          on(b, 'pointerdown', (e) => { e.preventDefault(); b.setPointerCapture?.(e.pointerId); b.dataset.held = ''; down(); board.focus({ preventScroll: true }); });
          for (const t of ['pointerup', 'pointercancel', 'lostpointercapture']) on(b, t, () => { if (b.dataset.held == null) return; delete b.dataset.held; up(); });
          return b;
        };
        const leftBtn = hold(button('◀ 왼쪽', () => {}, 'gfx-pin-flip'), () => game.press(-1, true), () => game.press(-1, false));
        const launchBtn = hold(button('발사 (꾹)', () => {}, 'gfx-pin-launch'), () => { begin(); game.pull(true); }, () => game.pull(false));
        const rightBtn = hold(button('오른쪽 ▶', () => {}, 'gfx-pin-flip'), () => game.press(1, true), () => game.press(1, false));
        pad.append(leftBtn, launchBtn, rightBtn);
        board.append(canvas, pad);
        board.tabIndex = 0; board.setAttribute('role', 'application'); board.setAttribute('aria-label', '핀볼 · 왼쪽·오른쪽 방향키(또는 Z·/)로 플리퍼, 스페이스로 발사');
        // Keys: ←/Z/A and →/'/'/D flip, Space/↓/Enter pulls the plunger. Touch: the left or right half of the table.
        const KEYS = { ArrowLeft: 'L', z: 'L', Z: 'L', a: 'L', A: 'L', Shift: 'L', ArrowRight: 'R', '/': 'R', d: 'R', D: 'R', m: 'R', M: 'R', ' ': 'P', ArrowDown: 'P', Enter: 'P' };
        const act = (k, down) => { if (k === 'L') game.press(-1, down); else if (k === 'R') game.press(1, down); else { if (down) begin(); game.pull(down); } };
        on(board, 'keydown', (e) => { const k = KEYS[e.key]; if (!k) return; e.preventDefault(); if (!e.repeat) act(k, true); });
        on(board, 'keyup', (e) => { const k = KEYS[e.key]; if (!k) return; e.preventDefault(); act(k, false); });
        on(board, 'blur', () => { game.press(-1, false); game.press(1, false); game.pull(false); });
        const touches = new Map();
        on(canvas, 'pointerdown', (e) => {
          e.preventDefault(); board.focus({ preventScroll: true }); canvas.setPointerCapture?.(e.pointerId);
          const r = canvas.getBoundingClientRect(), x = (e.clientX - r.left) / r.width * W;
          const k = game.ball.lane && x > LANE - 10 ? 'P' : x < W / 2 ? 'L' : 'R';
          touches.set(e.pointerId, k); act(k, true);
        });
        for (const t of ['pointerup', 'pointercancel']) on(canvas, t, (e) => { const k = touches.get(e.pointerId); if (!k) return; touches.delete(e.pointerId); act(k, false); });
        // Colours from the 말랑 theme; the table itself is drawn once into a layer and redrawn on resize.
        const css = getComputedStyle(board), col = (v, d) => css.getPropertyValue(v).trim() || d;
        const C = { line: col('--gfx-line', '#6B4528'), ink: col('--gfx-ink', '#FFF4D9'), card: col('--gfx-card', '#FFFDF5'), accent: col('--gfx-accent', '#F0763A'), pick: col('--gfx-pick', '#FFE17A') };
        const night = panel.dataset.theme === 'night';
        let layer = null, scale = 0;
        const path = (c, pts) => { c.beginPath(); pts.forEach(([x, y], k) => (k ? c.lineTo(x, y) : c.moveTo(x, y))); };
        const drawTable = (c) => {
          c.fillStyle = C.line; c.fillRect(0, 0, W, H);
          // The playfield: the rim closed along the bottom.
          path(c, [...game.rim, [308, H], [12, H]]); c.closePath(); c.fillStyle = night ? '#22253D' : C.ink; c.fill();
          // Sprinkles on the field, the same every time.
          let seed = 7; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
          const SPR = night ? ['#FFF6C2', '#8EC5FF', '#D3B5FF'] : ['#F7A8C4', '#8FDDBA', '#9CC9F5', '#FFD84D', '#C9B6FF'];
          c.save(); path(c, [...game.rim, [LANE, 510], [12, 510]]); c.closePath(); c.clip();
          for (let k = 0; k < 90; k++) { const x = 16 + rnd() * 268, y = 20 + rnd() * 480; c.save(); c.translate(x, y); c.rotate(rnd() * Math.PI); c.fillStyle = SPR[k % SPR.length]; c.globalAlpha = night ? 0.5 : 0.55; c.beginPath(); c.roundRect ? c.roundRect(-3.5, -1.2, 7, 2.4, 1.2) : c.rect(-3.5, -1.2, 7, 2.4); c.fill(); c.restore(); }
          c.restore();
          // The logo and the multiplier lamps' plates.
          c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillStyle = night ? '#3B4068' : 'rgba(107,69,40,.16)';
          c.font = '26px Jua, "Malgun Gothic", sans-serif'; c.fillText('말랑 핀볼', game.cx, 318);
          // Under the inlane guides is solid rim.
          c.fillStyle = C.line; for (const pts of [[[12, 392], [90, 447], [90, H], [12, H]], [[LANE, 392], [208, 447], [208, H], [LANE, H]]]) { path(c, pts); c.closePath(); c.fill(); }
          // The launch lane.
          c.fillStyle = night ? '#171A2E' : '#EBD9BC'; c.fillRect(LANE, 150, 308 - LANE, 340);
          // Walls, guides and posts: thick, round-capped strokes.
          c.lineCap = 'round'; c.lineJoin = 'round'; c.strokeStyle = C.line;
          c.lineWidth = 6; path(c, game.rim); c.stroke();
          for (const s of game.walls.slice(game.rim.length - 1)) { c.beginPath(); c.moveTo(s[0], s[1]); c.lineTo(s[2], s[3]); c.stroke(); }
          // The slingshot triangles.
          for (const [x1, y1, x2, y2] of game.slings.map((s) => s.s)) { path(c, [[x1, y1], [x1, y2 - 26], [x2, y2]]); c.closePath(); c.fillStyle = C.pick; c.fill(); c.lineWidth = 4; c.stroke(); }
          // Arrows up the lane.
          c.fillStyle = night ? '#3B4068' : '#D9BF97';
          for (const y of [250, 300, 350]) { path(c, [[297, y - 8], [303, y + 2], [291, y + 2]]); c.closePath(); c.fill(); }
        };
        const flipperPath = (f) => {
          const tx = f.x + Math.cos(f.a) * f.len, ty = f.y + Math.sin(f.a) * f.len, nx = -Math.sin(f.a), ny = Math.cos(f.a);
          ctx.beginPath(); ctx.moveTo(f.x + nx * 7.5, f.y + ny * 7.5); ctx.lineTo(tx + nx * 4, ty + ny * 4);
          ctx.arc(tx, ty, 4, f.a + Math.PI / 2, f.a - Math.PI / 2, true); ctx.lineTo(f.x - nx * 7.5, f.y - ny * 7.5);
          ctx.arc(f.x, f.y, 7.5, f.a - Math.PI / 2, f.a + Math.PI / 2, true); ctx.closePath();
        };
        const draw = () => {
          const w = Math.round(canvas.clientWidth * (window.devicePixelRatio || 1));
          if (!w) return;
          if (w !== scale) {
            scale = w; canvas.width = w; canvas.height = Math.round(w * H / W);
            layer = document.createElement('canvas'); layer.width = canvas.width; layer.height = canvas.height;
            const c = layer.getContext('2d'); c.setTransform(w / W, 0, 0, w / W, 0, 0); drawTable(c);
          }
          const k = w / W;
          ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(layer, 0, 0); ctx.setTransform(k, 0, 0, k, 0, 0);
          ctx.lineCap = 'round'; ctx.lineJoin = 'round';
          // The top lanes: a star each, gold once rolled over.
          for (const l of game.lanes) {
            ctx.beginPath(); for (let j = 0; j < 10; j++) { const a = -Math.PI / 2 + j * Math.PI / 5, r = j % 2 ? 3.6 : 8; ctx.lineTo(l.x + Math.cos(a) * r, l.y + Math.sin(a) * r); } ctx.closePath();
            ctx.fillStyle = l.lit ? '#FFD84D' : (night ? '#3B4068' : 'rgba(107,69,40,.2)'); ctx.fill(); if (l.lit) { ctx.strokeStyle = C.line; ctx.lineWidth = 2; ctx.stroke(); }
          }
          // The multiplier lamps.
          ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.font = '13px Jua, "Malgun Gothic", sans-serif';
          [2, 3, 4, 5].forEach((m, j) => {
            const x = game.cx - 54 + j * 36, on2 = game.mult >= m;
            ctx.beginPath(); ctx.arc(x, 290, 11, 0, Math.PI * 2); ctx.fillStyle = on2 ? C.accent : (night ? '#2E3254' : 'rgba(255,255,255,.7)'); ctx.fill();
            ctx.lineWidth = 2.5; ctx.strokeStyle = C.line; ctx.stroke(); ctx.fillStyle = on2 ? '#fff' : (night ? '#6A70A8' : '#B59C80'); ctx.fillText('×' + m, x, 291);
          });
          // The bumpers: donuts with icing and sprinkles; they swell when hit.
          const ICE = ['#F7A8C4', '#8FDDBA', '#FFD84D'];
          game.bumpers.forEach((p, j) => {
            const s = 1 + p.flash * 1.2, r = p.r * s;
            if (p.flash) { ctx.beginPath(); ctx.arc(p.x, p.y, r + 7 * (1 - p.flash * 5), 0, Math.PI * 2); ctx.strokeStyle = 'rgba(255,255,255,.9)'; ctx.lineWidth = 3; ctx.stroke(); }
            ctx.beginPath(); ctx.arc(p.x, p.y + 2, r, 0, Math.PI * 2); ctx.fillStyle = 'rgba(0,0,0,.18)'; ctx.fill();
            ctx.beginPath(); ctx.arc(p.x, p.y, r, 0, Math.PI * 2); ctx.fillStyle = '#E7A552'; ctx.fill(); ctx.lineWidth = 3; ctx.strokeStyle = C.line; ctx.stroke();
            ctx.beginPath(); for (let q = 0; q <= 16; q++) { const a = q / 16 * Math.PI * 2, rr = r * (0.82 + (q % 2) * 0.06); ctx.lineTo(p.x + Math.cos(a) * rr, p.y + Math.sin(a) * rr); }
            ctx.fillStyle = p.flash ? '#fff' : ICE[j % ICE.length]; ctx.fill();
            ctx.beginPath(); ctx.arc(p.x, p.y, r * 0.32, 0, Math.PI * 2); ctx.fillStyle = night ? '#22253D' : C.ink; ctx.fill(); ctx.lineWidth = 2.5; ctx.stroke();
            ['#fff', '#3E2616', '#9CC9F5', '#fff', '#3E2616'].forEach((c2, q) => { const a = q * 1.3 + j, rr = r * 0.6; ctx.save(); ctx.translate(p.x + Math.cos(a) * rr, p.y + Math.sin(a) * rr); ctx.rotate(a); ctx.fillStyle = c2; ctx.fillRect(-2.2, -0.9, 4.4, 1.8); ctx.restore(); });
          });
          // Slingshots flash white when they kick.
          for (const sl of game.slings) if (sl.flash) { const [x1, y1, x2, y2] = sl.s; ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.strokeStyle = '#fff'; ctx.lineWidth = 5; ctx.stroke(); }
          // The flippers.
          for (const f of game.flippers) {
            ctx.save(); ctx.translate(0, 2.5); flipperPath(f); ctx.fillStyle = 'rgba(0,0,0,.2)'; ctx.fill(); ctx.restore();
            flipperPath(f); ctx.fillStyle = C.accent; ctx.fill(); ctx.lineWidth = 2.8; ctx.strokeStyle = C.line; ctx.stroke();
            ctx.beginPath(); ctx.arc(f.x, f.y, 2.6, 0, Math.PI * 2); ctx.fillStyle = '#fff'; ctx.fill();
          }
          // The plunger spring squeezes as it is pulled.
          const top = 490 + game.charge * 14;
          ctx.beginPath(); for (let j = 0; j <= 8; j++) ctx.lineTo(j % 2 ? 291 : 303, top + j * (512 - top) / 8); ctx.strokeStyle = night ? '#8EC5FF' : '#B59C80'; ctx.lineWidth = 2.5; ctx.stroke();
          ctx.fillStyle = C.accent; ctx.fillRect(289, top - 3, 16, 5);
          if (game.pulling) { ctx.fillStyle = '#FFD84D'; ctx.fillRect(LANE + 2, 500 - game.charge * 60, 3, game.charge * 60); }
          // The ball: a white gumball with a shine.
          const b = game.ball;
          if (b.y < H + R) {
            ctx.beginPath(); ctx.arc(b.x + 1.5, b.y + 2.5, R, 0, Math.PI * 2); ctx.fillStyle = 'rgba(0,0,0,.22)'; ctx.fill();
            ctx.beginPath(); ctx.arc(b.x, b.y, R, 0, Math.PI * 2); ctx.fillStyle = '#fff'; ctx.fill(); ctx.lineWidth = 2.4; ctx.strokeStyle = C.line; ctx.stroke();
            ctx.beginPath(); ctx.arc(b.x - 2.2, b.y - 2.4, 2, 0, Math.PI * 2); ctx.fillStyle = '#C9E6FF'; ctx.fill();
          }
          // Score popups and the table's announcements.
          ctx.font = '12px Jua, "Malgun Gothic", sans-serif'; ctx.lineWidth = 3;
          for (const p of game.popups) { const y = p.y - p.t * 30; ctx.globalAlpha = Math.max(0, 1 - p.t / 0.8); ctx.strokeStyle = C.line; ctx.strokeText(p.text, p.x, y); ctx.fillStyle = '#FFD84D'; ctx.fillText(p.text, p.x, y); }
          ctx.globalAlpha = 1;
          if (game.note) {
            const a = Math.min(1, (1.6 - game.note.t) * 3); ctx.globalAlpha = Math.max(0, a); ctx.font = '22px Jua, "Malgun Gothic", sans-serif'; ctx.lineWidth = 5;
            ctx.strokeStyle = C.line; ctx.strokeText(game.note.text, game.cx, 360); ctx.fillStyle = '#fff'; ctx.fillText(game.note.text, game.cx, 360); ctx.globalAlpha = 1;
          }
          if (!st.started && b.lane) {
            ctx.font = '14px Jua, "Malgun Gothic", sans-serif'; ctx.lineWidth = 4; ctx.strokeStyle = C.line; ctx.fillStyle = '#fff';
            ctx.strokeText('꾹 눌렀다 떼면 발사!', game.cx, 352); ctx.fillText('꾹 눌렀다 떼면 발사!', game.cx, 352);
          }
        };
        // The loop: physics by real time, drawing each frame; it stops once the table is off screen.
        let last = 0, shown = '';
        const loop = (t) => {
          frame = 0;
          if (!content.contains(board) || !board.isConnected) return;
          const ms = last ? Math.min(50, t - last) : 16; last = t;
          if (!game.ended) game.step(ms);
          draw();
          const sig = game.score + '/' + game.balls + '/' + game.ended + '/' + game.mult + '/' + game.ball.lane;
          if (sig !== shown) { shown = sig; paint(); }
          if (!game.ended) frame = requestAnimationFrame(loop);
        };
        frame = requestAnimationFrame(loop);
        paint = (clockOnly) => {
          const b0 = best();
          chips([['🎯 ' + game.score.toLocaleString()], ['● '.repeat(Math.max(0, game.balls)).trim() || '—', game.balls === 1], ['×' + game.mult], b0 != null && ['🏆 ' + b0.toLocaleString()]]);
          if (clockOnly) return;
          if (game.ended) finish(false, game.score);
          launchBtn.disabled = game.ended || !game.ball.lane; leftBtn.disabled = rightBtn.disabled = game.ended;
          info.textContent = game.ended ? '공을 모두 잃었어요!' : game.ball.lane ? '스페이스(또는 [발사])를 꾹 눌렀다 떼서 공을 쏘아요' : '←·Z 왼쪽 / →·D 오른쪽 플리퍼 · 위쪽 별 3개를 다 켜면 배수 업!';
          if (game.ended) { draw(); showResult('게임 오버', game.score.toLocaleString() + '점 · 최고 배수 ×' + game.top); }
        };
      }

      if (mode === 'bricks') {
        const { W, H, R, PY, BW, BH } = game;
        board.style.setProperty('--fit', (W / (H + 60)).toFixed(3));
        const canvas = el('canvas', 'gfx-pin-table'), ctx = canvas.getContext('2d');
        canvas.style.aspectRatio = W + ' / ' + H;
        canvas.setAttribute('role', 'img'); canvas.setAttribute('aria-label', '벽돌깨기 판');
        const pad = el('div', 'gfx-pin-pad');
        const hold = (b, down, up) => {
          on(b, 'pointerdown', (e) => { e.preventDefault(); b.setPointerCapture?.(e.pointerId); b.dataset.held = ''; down(); board.focus({ preventScroll: true }); });
          for (const t of ['pointerup', 'pointercancel', 'lostpointercapture']) on(b, t, () => { if (b.dataset.held == null) return; delete b.dataset.held; up(); });
          return b;
        };
        const leftBtn = hold(button('◀', () => {}, 'gfx-pin-flip'), () => game.move(-1), () => game.move(0));
        const launchBtn = hold(button('발사', () => {}, 'gfx-pin-launch'), () => { begin(); game.launch(); }, () => {});
        const rightBtn = hold(button('▶', () => {}, 'gfx-pin-flip'), () => game.move(1), () => game.move(0));
        leftBtn.setAttribute('aria-label', '왼쪽으로'); rightBtn.setAttribute('aria-label', '오른쪽으로');
        pad.append(leftBtn, launchBtn, rightBtn);
        board.append(canvas, pad);
        board.tabIndex = 0; board.setAttribute('role', 'application'); board.setAttribute('aria-label', '벽돌깨기 · 마우스나 방향키로 뒤집개를 움직이고 스페이스로 발사');
        // Keys move the spatula; the pointer over the table steers it, and a tap launches.
        const held = { L: false, R: false };
        const KEYS = { ArrowLeft: 'L', a: 'L', A: 'L', ArrowRight: 'R', d: 'R', D: 'R', ' ': 'P', ArrowUp: 'P', Enter: 'P' };
        const steer = () => game.move((held.R ? 1 : 0) - (held.L ? 1 : 0));
        on(board, 'keydown', (e) => { const k = KEYS[e.key]; if (!k) return; e.preventDefault(); if (k === 'P') { begin(); game.launch(); } else { held[k] = true; steer(); } });
        on(board, 'keyup', (e) => { const k = KEYS[e.key]; if (!k || k === 'P') return; e.preventDefault(); held[k] = false; steer(); });
        on(board, 'blur', () => { held.L = held.R = false; game.move(0); });
        const toX = (e) => { const r = canvas.getBoundingClientRect(); return (e.clientX - r.left) / r.width * W; };
        on(canvas, 'pointermove', (e) => game.aim(toX(e)));
        on(canvas, 'pointerdown', (e) => { e.preventDefault(); board.focus({ preventScroll: true }); canvas.setPointerCapture?.(e.pointerId); game.aim(toX(e)); begin(); game.launch(); });
        // Colours from the 말랑 theme; the gingham cloth is drawn once into a layer and redrawn on resize.
        const css = getComputedStyle(board), col = (v, d) => css.getPropertyValue(v).trim() || d;
        const C = { line: col('--gfx-line', '#6B4528'), ink: col('--gfx-ink', '#FFF4D9'), accent: col('--gfx-accent', '#F0763A'), pick: col('--gfx-pick', '#FFE17A') };
        const night = panel.dataset.theme === 'night';
        const ROW = ['#F7A8C4', '#FFC27A', '#FFE07A', '#8FDDBA', '#9CC9F5', '#C9B6FF', '#F7A8C4', '#FFC27A'];
        let layer = null, scale = 0;
        const rr = (c, x, y, w, h, r) => { c.beginPath(); c.roundRect ? c.roundRect(x, y, w, h, r) : c.rect(x, y, w, h); };
        const drawCloth = (c) => {
          c.fillStyle = night ? '#22253D' : C.ink; c.fillRect(0, 0, W, H);
          c.fillStyle = night ? 'rgba(140,150,230,.08)' : 'rgba(240,118,58,.08)';
          for (let x = 0; x < W; x += 40) c.fillRect(x, 0, 20, H);
          for (let y = 0; y < H; y += 40) c.fillRect(0, y, W, 20);
          c.strokeStyle = C.line; c.lineWidth = 8; c.strokeRect(0, 0, W, H);
        };
        const draw = () => {
          const w = Math.round(canvas.clientWidth * (window.devicePixelRatio || 1));
          if (!w) return;
          if (w !== scale) {
            scale = w; canvas.width = w; canvas.height = Math.round(w * H / W);
            layer = document.createElement('canvas'); layer.width = canvas.width; layer.height = canvas.height;
            const c = layer.getContext('2d'); c.setTransform(w / W, 0, 0, w / W, 0, 0); drawCloth(c);
          }
          const k = w / W;
          ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(layer, 0, 0); ctx.setTransform(k, 0, 0, k, 0, 0);
          ctx.lineJoin = 'round'; ctx.lineCap = 'round';
          // Biscuits: icing by row, sugar dots; chocolate ones crack after the first hit.
          for (const b of game.bricks) {
            const choc = b.max > 1, lift = b.hit ? -1.5 : 0;
            rr(ctx, b.x, b.y + 2, BW, BH, 5); ctx.fillStyle = 'rgba(0,0,0,.15)'; ctx.fill();
            rr(ctx, b.x, b.y + lift, BW, BH, 5); ctx.fillStyle = choc ? '#6B4528' : '#E7A552'; ctx.fill(); ctx.lineWidth = 2.2; ctx.strokeStyle = C.line; ctx.stroke();
            rr(ctx, b.x + 3, b.y + 2.5 + lift, BW - 6, BH - 6, 3.5); ctx.fillStyle = b.hit ? '#fff' : choc ? '#8A5A33' : ROW[b.row % ROW.length]; ctx.fill();
            ctx.fillStyle = choc ? '#C2803F' : 'rgba(255,255,255,.85)';
            for (const [dx, dy] of [[8, 5], [17, 8], [26, 5]]) { ctx.beginPath(); ctx.arc(b.x + dx, b.y + dy + lift, 1.1, 0, Math.PI * 2); ctx.fill(); }
            if (choc && b.hp < b.max) { ctx.beginPath(); ctx.moveTo(b.x + 10, b.y + 2 + lift); ctx.lineTo(b.x + 15, b.y + 8 + lift); ctx.lineTo(b.x + 12, b.y + 13 + lift); ctx.moveTo(b.x + 15, b.y + 8 + lift); ctx.lineTo(b.x + 22, b.y + 10 + lift); ctx.strokeStyle = '#2A180C'; ctx.lineWidth = 1.4; ctx.stroke(); }
          }
          // Falling treats.
          ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
          for (const it of game.items) {
            ctx.beginPath(); ctx.arc(it.x, it.y, 8, 0, Math.PI * 2); ctx.fillStyle = it.kind === 'heart' ? '#F2557F' : C.pick; ctx.fill(); ctx.lineWidth = 2; ctx.strokeStyle = C.line; ctx.stroke();
            ctx.fillStyle = it.kind === 'heart' ? '#fff' : C.line; ctx.font = '11px Jua, "Malgun Gothic", sans-serif'; ctx.fillText(it.kind === 'heart' ? '♥' : '길', it.x, it.y + 0.5);
          }
          // The spatula: a wooden handle under a rounded blade.
          const p = game.paddle, half = (p.long > 0 ? p.w * 1.5 : p.w) / 2;
          rr(ctx, p.x - 5, PY + 9, 10, 14, 3); ctx.fillStyle = '#B07A47'; ctx.fill(); ctx.lineWidth = 2; ctx.strokeStyle = C.line; ctx.stroke();
          rr(ctx, p.x - half, PY + 2, half * 2, 10, 5); ctx.fillStyle = 'rgba(0,0,0,.18)'; ctx.fill();
          rr(ctx, p.x - half, PY, half * 2, 10, 5); ctx.fillStyle = p.long > 0 && (p.long > 2 || Math.floor(p.long * 6) % 2) ? C.pick : C.accent; ctx.fill(); ctx.lineWidth = 2.5; ctx.stroke();
          ctx.beginPath(); ctx.moveTo(p.x - half + 6, PY + 3); ctx.lineTo(p.x + half * 0.3, PY + 3); ctx.strokeStyle = 'rgba(255,255,255,.7)'; ctx.lineWidth = 2; ctx.stroke();
          // The gumball.
          const b = game.ball;
          if (b.y < H + R) {
            ctx.beginPath(); ctx.arc(b.x + 1.5, b.y + 2, R, 0, Math.PI * 2); ctx.fillStyle = 'rgba(0,0,0,.2)'; ctx.fill();
            ctx.beginPath(); ctx.arc(b.x, b.y, R, 0, Math.PI * 2); ctx.fillStyle = '#fff'; ctx.fill(); ctx.lineWidth = 2.2; ctx.strokeStyle = C.line; ctx.stroke();
            ctx.beginPath(); ctx.arc(b.x - 1.8, b.y - 2, 1.7, 0, Math.PI * 2); ctx.fillStyle = '#C9E6FF'; ctx.fill();
          }
          // Score popups and announcements.
          ctx.font = '12px Jua, "Malgun Gothic", sans-serif'; ctx.lineWidth = 3;
          for (const q of game.popups) { const y = q.y - q.t * 26; ctx.globalAlpha = Math.max(0, 1 - q.t / 0.8); ctx.strokeStyle = C.line; ctx.strokeText(q.text, q.x, y); ctx.fillStyle = '#FFD84D'; ctx.fillText(q.text, q.x, y); }
          ctx.globalAlpha = 1;
          const say = (text, y, size) => { ctx.font = size + 'px Jua, "Malgun Gothic", sans-serif'; ctx.lineWidth = 5; ctx.strokeStyle = C.line; ctx.strokeText(text, W / 2, y); ctx.fillStyle = '#fff'; ctx.fillText(text, W / 2, y); };
          if (game.note) { ctx.globalAlpha = Math.max(0, Math.min(1, (1.6 - game.note.t) * 3)); say(game.note.text, 290, 22); ctx.globalAlpha = 1; }
          else if (b.stuck && !game.ended) say('스페이스나 탭으로 발사!', 330, 15);
        };
        let last = 0, shown = '';
        const loop = (t) => {
          frame = 0;
          if (!content.contains(board) || !board.isConnected) return;
          const ms = last ? Math.min(50, t - last) : 16; last = t;
          if (!game.ended) game.step(ms);
          draw();
          const sig = game.score + '/' + game.lives + '/' + game.stage + '/' + game.ended + '/' + game.ball.stuck;
          if (sig !== shown) { shown = sig; paint(); }
          if (!game.ended) frame = requestAnimationFrame(loop);
        };
        frame = requestAnimationFrame(loop);
        paint = (clockOnly) => {
          const b0 = best();
          chips([['🧁 ' + game.score.toLocaleString()], ['♥'.repeat(Math.max(0, Math.min(game.lives, 6))) + (game.lives > 6 ? '+' : '') || '♡', game.lives === 1], ['스테이지 ' + game.stage], b0 != null && ['🏆 ' + b0.toLocaleString()]]);
          if (clockOnly) return;
          if (game.ended) finish(false, game.score);
          launchBtn.disabled = game.ended || !game.ball.stuck; leftBtn.disabled = rightBtn.disabled = game.ended;
          info.textContent = game.ended ? '하트를 모두 잃었어요!' : game.ball.stuck ? '스페이스(또는 탭)로 발사 · 뒤집개 끝에 맞을수록 비스듬히 튀어요' : '마우스·←→로 뒤집개 이동 · 초코 비스킷은 두 번 · 떨어지는 간식을 받아요';
          if (game.ended) { draw(); showResult('게임 오버', game.score.toLocaleString() + '점 · 스테이지 ' + game.stage + ' · 비스킷 ' + game.broken + '개'); }
        };
      }

      if (mode === 'block') {
        const n = game.cols;
        board.style.setProperty('--fit', '0.74');
        const cells = game.cells.map((_, i) => { const d = el('div'); d.dataset.cell = String(i); board.append(d); return d; });
        // The tray under the board: three pieces. Drag one onto the board, or tap it and then tap where it goes.
        const tray = el('div', 'gfx-block-tray');
        tray.style.setProperty('--fit', '0.74');
        board.after(tray);
        let picked = -1, drag = null, preview = null;
        const slots = [0, 1, 2].map((k) => {
          const b = button('', () => {}, 'gfx-block-slot'); b.dataset.slot = String(k); tray.append(b);
          on(b, 'pointerdown', (e) => start(e, k));
          return b;
        });
        const mini = (p) => {
          const g = el('span', 'gfx-block-piece'); g.style.setProperty('--w', String(p.w)); g.style.setProperty('--h', String(p.h));
          const filled = new Set(p.cells.map(([r, c]) => r * p.w + c));
          for (let i = 0; i < p.w * p.h; i++) { const c = el('i'); if (filled.has(i)) c.dataset.c = String(p.color); g.append(c); }
          return g;
        };
        // Board geometry: one cell's size and the step between cells, from the cells themselves.
        const metric = () => { const a = cells[0].getBoundingClientRect(), b = cells[1].getBoundingClientRect(); return { left: a.left, top: a.top, size: a.width, pitch: b.left - a.left }; };
        const hint = (p, row, col) => {
          clearPreview();
          if (!p || row == null) return;
          const ok = game.fits(p, row, col);
          preview = { ok, at: [], line: [] };
          if (!ok) return;
          preview.at = p.cells.map(([r, c]) => (r + row) * n + c + col);
          preview.line = [...game.wouldClear(p, row, col)];
          preview.at.forEach((i) => { cells[i].dataset.prev = String(p.color); });
          preview.line.forEach((i) => { cells[i].dataset.line = ''; });
        };
        const clearPreview = () => { if (!preview) return; preview.at.forEach((i) => delete cells[i].dataset.prev); preview.line.forEach((i) => delete cells[i].dataset.line); preview = null; };
        const put = (k, row, col) => {
          const r = game.place(k, row, col);
          clearPreview(); picked = -1;
          if (!r) return false;
          r.at.forEach((i) => { cells[i].dataset.drop = ''; timers.push(setTimeout(() => delete cells[i].dataset.drop, 260)); });
          r.melted.forEach(([i, c]) => { cells[i].dataset.pop = String(c); timers.push(setTimeout(() => delete cells[i].dataset.pop, 520)); });
          if (r.lines) {
            const m = metric(), sr = stage.getBoundingClientRect(), [i0] = r.at, x = m.left - sr.left + (i0 % n + 0.5) * m.pitch, y = m.top - sr.top + (Math.floor(i0 / n) + 0.5) * m.pitch;
            const words = ['+' + r.gain];
            if (r.combo > 1) words.push('콤보 ×' + r.combo);
            if (r.clean) words.push('싹 비웠다!');
            const pop = el('span', 'gfx-block-pop', words.join(' · ')); pop.style.left = x + 'px'; pop.style.top = y + 'px';
            if (r.combo > 1 || r.clean) pop.dataset.big = '';
            stage.append(pop); timers.push(setTimeout(() => pop.remove(), 1100));
          }
          paint();
          return true;
        };
        // Dragging: the piece follows the pointer (lifted above a finger so it stays in sight) and snaps to the grid.
        const start = (e, k) => {
          const p = game.tray[k];
          if (!p || game.ended || e.button > 0) return;
          e.preventDefault(); begin();
          const m = metric(), ghost = mini(p);
          ghost.classList.add('gfx-block-ghost'); ghost.style.setProperty('--m', m.size + 'px'); ghost.style.setProperty('--gap', (m.pitch - m.size) + 'px');
          // Fixed, not absolute: dragged past the card edge it would grow the card scroll area and show a scrollbar.
          // Its origin is the top left of whatever holds fixed boxes here (the column), measured once.
          stage.append(ghost);
          const o = ghost.getBoundingClientRect();
          slots[k].setPointerCapture?.(e.pointerId);
          drag = { k, p, ghost, ox: o.left, oy: o.top, id: e.pointerId, x0: e.clientX, y0: e.clientY, moved: false, lift: e.pointerType === 'mouse' ? 0 : m.pitch * 1.6, row: null, col: null };
          slots[k].dataset.dragging = '';
          move(e);
        };
        const move = (e) => {
          if (!drag || e.pointerId !== drag.id) return;
          drag.moved ||= Math.hypot(e.clientX - drag.x0, e.clientY - drag.y0) > 6;
          const m = metric(), p = drag.p;
          const left = e.clientX - p.w * m.pitch / 2, top = e.clientY - p.h * m.pitch / 2 - drag.lift;
          drag.ghost.style.left = (left - drag.ox) + 'px'; drag.ghost.style.top = (top - drag.oy) + 'px';
          drag.ghost.hidden = !drag.moved;
          const col = Math.round((left - m.left) / m.pitch), row = Math.round((top - m.top) / m.pitch);
          const near = row > -p.h && row < n && col > -p.w && col < n;
          drag.row = near ? row : null; drag.col = col;
          hint(drag.moved ? p : null, drag.row, col);
          drag.ghost.dataset.bad = String(!!(drag.moved && near && preview && !preview.ok));
        };
        const end = (e) => {
          if (!drag || e.pointerId !== drag.id) return;
          const d = drag; drag = null; d.ghost.remove(); delete slots[d.k].dataset.dragging;
          if (!d.moved) { picked = picked === d.k ? -1 : d.k; clearPreview(); paint(); return; }
          if (d.row == null || !put(d.k, d.row, d.col)) { clearPreview(); paint(); }
        };
        on(tray, 'pointermove', move); on(tray, 'pointerup', end); on(tray, 'pointercancel', end);
        // Tapping: a picked piece previews under the pointer, centred on the cell, and a tap puts it there.
        const centred = (i) => { const p = game.tray[picked]; return [Math.floor(i / n) - Math.floor((p.h - 1) / 2), i % n - Math.floor((p.w - 1) / 2)]; };
        cells.forEach((c, i) => {
          on(c, 'pointerenter', () => { if (picked >= 0 && !drag) hint(game.tray[picked], ...centred(i)); });
          on(c, 'click', () => { if (picked >= 0 && !drag && !game.ended) { if (!put(picked, ...centred(i))) { c.dataset.nope = ''; timers.push(setTimeout(() => delete c.dataset.nope, 300)); } } });
        });
        on(board, 'pointerleave', () => { if (!drag) clearPreview(); });
        paint = (clockOnly) => {
          const b0 = best();
          chips([['🧩 ' + game.score.toLocaleString()], ['줄 ' + game.lines], game.combo > 1 && ['콤보 ×' + game.combo], b0 != null && ['🏆 ' + b0.toLocaleString()]]);
          if (clockOnly) return;
          if (game.ended) finish(false, game.score);
          cells.forEach((c, i) => { const v = game.cells[i]; if (v) c.dataset.c = String(v); else delete c.dataset.c; });
          game.tray.forEach((p, k) => {
            const s = slots[k];
            s.replaceChildren(...(p ? [mini(p)] : []));
            s.disabled = !p || game.ended; s.dataset.dead = String(!!p && !game.canPlace(p)); s.setAttribute('aria-pressed', String(picked === k));
            s.setAttribute('aria-label', p ? (k + 1) + '번 조각 · ' + p.cells.length + '칸' : '빈 자리');
          });
          info.textContent = game.ended ? '더 놓을 자리가 없어요!' : picked >= 0 ? '놓을 곳을 누르세요 (조각을 다시 누르면 취소)' : '조각을 판으로 끌어다 놓아요 · 가로나 세로 한 줄을 채우면 사라져요';
          if (game.ended) showResult('게임 끝', game.score.toLocaleString() + '점 · ' + game.lines + '줄 지움');
        };
      }

      if (mode === 'drop') {
        board.style.setProperty('--fit', '0.46');
        board.tabIndex = 0; board.setAttribute('role', 'application');
        board.setAttribute('aria-label', '마카롱 낙하 · ←→ 움직이기, ↑ 돌리기, ↓ 빨리 내리기, 스페이스 바로 내리기' + (game.holdOk ? ', C 보관' : ''));
        // The well and, beside it, the piece kept (보관) and the next three.
        const row = el('div', 'gfx-drop-row'), side = el('div', 'gfx-drop-side');
        stage.insertBefore(row, board); row.append(board, side);
        const cells = Array.from({ length: game.cols * game.rows }, () => { const d = el('div'); board.append(d); return d; });
        const shown = cells.map(() => '');
        const fx = el('div', 'gfx-drop-fx'); fx.setAttribute('aria-hidden', 'true'); board.append(fx);
        const toast = el('div', 'gfx-drop-toast'); toast.setAttribute('aria-hidden', 'true'); stage.append(toast);
        const mini = (label) => {
          const box = el('div', 'gfx-drop-mini'), grid = el('div', 'gfx-drop-minigrid');
          const dots = Array.from({ length: 8 }, () => { const i = el('i'); grid.append(i); return i; });
          box.append(el('b', '', label), grid); side.append(box);
          return { box, grid, dots, k: '-' };
        };
        const keep = game.holdOk ? mini('보관') : null, nexts = [mini('다음'), mini(''), mini('')];
        const drawMini = (m, k, dim) => {
          if (m.k === k + dim) return; m.k = k + dim;
          const at = new Map();
          if (k) { const s = game.shape(k, 0), y0 = Math.min(...s.map(([, y]) => y)); s.forEach(([x, y]) => at.set((y - y0) * 4 + x, DROP_COLOURS[k])); }
          m.dots.forEach((d, i) => { if (at.has(i)) d.dataset.c = String(at.get(i)); else delete d.dataset.c; });
          m.grid.dataset.w = k === 'I' || k === 'O' ? '4' : '3'; m.box.toggleAttribute('data-dim', dim);
        };
        let lastT = 0, rep = null, chipKey = '';
        const start = () => { lastT = 0; cancelAnimationFrame(frame); frame = requestAnimationFrame(loop); };
        // What a piece landing sounds and looks like: a thud (a crash when slammed), rows melting, a level gained.
        const landed = (rows0, level0, slammed) => {
          const cleared = game.lines - rows0;
          if (slammed) { sfx.play('slam'); bump('big'); navigator.vibrate?.(12); } else sfx.play('lock');
          if (cleared) {
            sfx.play('clear', cleared); if (cleared >= 2) bump('big');
            for (const y of game.last.rows) { const s = el('i'); s.style.setProperty('--y', String(y)); fx.append(s); setTimeout(() => s.remove(), 420); }
            const words = ['', '한 줄!', '두 줄!', '세 줄!', '네 줄! 대박!'];
            toast.textContent = words[cleared] + ' +' + game.last.gained.toLocaleString() + (game.last.combo > 0 ? ' · 연속 ' + game.last.combo : '');
            toast.removeAttribute('data-go'); void toast.offsetWidth; toast.setAttribute('data-go', '');
          }
          if (game.level > level0) sfx.play('level');
          if (game.ended) { sfx.play('lose'); bump('shake'); }
        };
        const act = (fn, sound) => {
          if (game.ended) return false;
          if (!st.started) { begin(); start(); }
          const locks0 = game.locks, rows0 = game.lines, level0 = game.level;
          const done = fn();
          if (game.locks !== locks0) landed(rows0, level0, sound === 'slam');
          else if (done && sound && sound !== 'slam') sfx.play(sound);
          paint();
          return done;
        };
        function loop(t) {
          frame = requestAnimationFrame(loop);
          if (!content.contains(board)) { cancelAnimationFrame(frame); return; }
          const dt = lastT ? Math.min(100, t - lastT) : 0; lastT = t;
          if (!st.started || game.ended) return;
          // Held keys and buttons repeat after a short wait, like a keyboard's own repeat but quicker.
          if (rep && t >= rep.at) { rep.at = t + rep.every; act(rep.fn, rep.sound); }
          const locks0 = game.locks, rows0 = game.lines, level0 = game.level;
          game.step(dt);
          if (game.locks !== locks0) landed(rows0, level0, false);
          paint();
        }
        if (st.started && !game.ended) start();
        const MOVES = { L: [() => game.move(-1), 'move', 150, 45], R: [() => game.move(1), 'move', 150, 45], D: [() => game.soft(), '', 40, 35] };
        const press = (k) => { const [fn, sound, wait, every] = MOVES[k]; act(fn, sound); rep = { k, fn, sound, at: performance.now() + wait, every }; };
        const KEYS = { ArrowLeft: 'L', ArrowRight: 'R', ArrowDown: 'D', a: 'L', d: 'R', s: 'D', A: 'L', D: 'R', S: 'D' };
        on(board, 'keydown', (e) => {
          const k = KEYS[e.key];
          if (k) { e.preventDefault(); if (!e.repeat) press(k); return; }
          if (['ArrowUp', 'x', 'X', 'w', 'W'].includes(e.key)) { e.preventDefault(); act(() => game.rotate(1), 'turn'); }
          else if (['z', 'Z', 'Control'].includes(e.key)) { e.preventDefault(); act(() => game.rotate(-1), 'turn'); }
          else if (e.key === ' ' || e.key === 'Enter') { e.preventDefault(); act(() => game.slam(), 'slam'); }
          else if (['c', 'C', 'Shift'].includes(e.key)) { e.preventDefault(); act(() => game.swap(), 'flip'); }
        });
        on(board, 'keyup', (e) => { const k = KEYS[e.key]; if (k && rep?.k === k) rep = null; });
        on(board, 'blur', () => { rep = null; });
        // Touch and mouse on the well: drag sideways a cell at a time, drag down to fall faster, flick down to drop,
        // flick up to keep, tap to turn.
        let touch = null;
        on(board, 'pointerdown', (e) => { board.focus({ preventScroll: true }); touch = { x: e.clientX, y: e.clientY, id: e.pointerId, t: performance.now(), sx: 0, sy: 0, moved: false }; board.setPointerCapture?.(e.pointerId); });
        on(board, 'pointermove', (e) => {
          if (!touch || touch.id !== e.pointerId) return;
          const cell = board.clientWidth / game.cols, dx = e.clientX - touch.x - touch.sx * cell, dy = e.clientY - touch.y - touch.sy * cell;
          if (Math.abs(dx) >= cell) { const s = Math.sign(dx); touch.sx += s; touch.moved = true; act(() => game.move(s), 'move'); }
          if (dy >= cell * 1.2) { touch.sy += 1; touch.moved = true; act(() => game.soft()); }
        });
        on(board, 'pointerup', (e) => {
          if (!touch || touch.id !== e.pointerId) return;
          const t = touch, ms = performance.now() - t.t, dx = e.clientX - t.x, dy = e.clientY - t.y; touch = null;
          if (ms < 280 && Math.abs(dy) > 50 && Math.abs(dy) > Math.abs(dx) * 1.5) act(dy > 0 ? () => game.slam() : () => game.swap(), dy > 0 ? 'slam' : 'flip');
          else if (!t.moved && ms < 350) act(() => game.rotate(1), 'turn');
        });
        on(board, 'pointercancel', () => { touch = null; });
        // Buttons under the well: ◀ ▶ ▼ repeat while held; a keyboard press on them (detail 0) acts once.
        const pad = el('div', 'gfx-drop-pad');
        const padBtn = (label, aria, fn, held) => {
          const b = button(label, (e) => { if (e.detail === 0) fn(); });
          b.setAttribute('aria-label', aria);
          on(b, 'pointerdown', (e) => { e.preventDefault(); board.focus({ preventScroll: true }); if (held) { b.setPointerCapture?.(e.pointerId); press(held); } else fn(); });
          if (held) for (const t of ['pointerup', 'pointercancel', 'lostpointercapture']) on(b, t, () => { if (rep?.k === held) rep = null; });
          pad.append(b); return b;
        };
        padBtn('◀', '왼쪽으로', () => act(() => game.move(-1), 'move'), 'L');
        padBtn('⟲', '왼쪽으로 돌리기', () => act(() => game.rotate(-1), 'turn'));
        padBtn('⟳', '오른쪽으로 돌리기', () => act(() => game.rotate(1), 'turn'));
        padBtn('▶', '오른쪽으로', () => act(() => game.move(1), 'move'), 'R');
        padBtn('▼', '빨리 내리기', () => act(() => game.soft()), 'D');
        padBtn('⤓', '바로 내리기', () => act(() => game.slam(), 'slam')).dataset.main = '';
        if (game.holdOk) padBtn('보관', '보관하기', () => act(() => game.swap(), 'flip'));
        stage.append(pad);
        paint = (clockOnly) => {
          const b0 = best(), key = [game.score, game.lines, game.level, b0].join();
          if (key !== chipKey || clockOnly) { chipKey = key; chips([['⭐ ' + game.score.toLocaleString()], ['🧱 ' + game.lines + '줄'], ['Lv ' + game.level], b0 != null && ['🏆 ' + b0.toLocaleString()]]); }
          if (clockOnly) return;
          if (game.ended) finish(false, game.score);
          info.textContent = game.ended ? '꼭대기까지 쌓였어요!' : !st.started ? '판을 누르거나 아무 키로 시작 · ←→ 이동 · ↑ 돌리기 · 스페이스 바로 내리기' + (game.holdOk ? ' · C 보관' : '')
            : '가로 한 줄을 채우면 녹아요 · 한 번에 여러 줄일수록 큰 점수';
          const next = game.cells.map((c) => c ? 'c' + c : '');
          if (game.piece) {
            const c = DROP_COLOURS[game.piece.k];
            for (const [x, y] of game.ghost()) if (y >= 0 && !next[y * game.cols + x]) next[y * game.cols + x] = 'g' + c;
            for (const [x, y] of game.blocks()) if (y >= 0) next[y * game.cols + x] = 'p' + c;
          }
          next.forEach((s, i) => {
            if (shown[i] === s) return;
            shown[i] = s; const d = cells[i];
            if (s[0] === 'g') { delete d.dataset.c; d.dataset.ghost = s.slice(1); } else { delete d.dataset.ghost; if (s) d.dataset.c = s.slice(1); else delete d.dataset.c; }
            d.toggleAttribute('data-live', s[0] === 'p');
          });
          if (keep) drawMini(keep, game.hold || '', game.held);
          nexts.forEach((m, k) => drawMini(m, game.next[k] || '', false));
          if (game.ended) showResult('게임 끝', '점수 ' + game.score.toLocaleString() + ' · ' + game.lines + '줄 · Lv ' + game.level);
        };
      }

      if (mode === 'snake') {
        board.tabIndex = 0; board.setAttribute('role', 'application'); board.setAttribute('aria-label', '스네이크 · 방향키나 스와이프로 움직이기');
        const cells = Array.from({ length: game.cols * game.rows }, (_, i) => { const d = el('div'); d.dataset.cell = String(i); board.append(d); return d; });
        const shown = cells.map(() => '');
        const go = () => { clearInterval(live); live = setInterval(() => { game.step(); paint(); if (game.ended) { clearInterval(live); live = 0; } }, game.speed); };
        const push = (dir) => { if (game.ended) return; game.turn(dir); if (!st.started) { begin(); go(); } board.focus({ preventScroll: true }); };
        if (st.started && !game.ended) go();
        const pad = el('div', 'gfx-game-pad');
        for (const [dir, label, arrow] of [['up', '위로', '▲'], ['left', '왼쪽으로', '◀'], ['down', '아래로', '▼'], ['right', '오른쪽으로', '▶']]) { const b = button(arrow, () => push(dir)); b.setAttribute('aria-label', label); b.dataset.dir = dir; pad.append(b); }
        stage.append(pad);
        const KEYS = { ArrowUp: 'up', ArrowDown: 'down', ArrowLeft: 'left', ArrowRight: 'right', w: 'up', s: 'down', a: 'left', d: 'right', W: 'up', S: 'down', A: 'left', D: 'right' };
        on(board, 'keydown', (e) => { const dir = KEYS[e.key]; if (!dir) return; e.preventDefault(); push(dir); });
        let from = null;
        on(board, 'pointerdown', (e) => { from = [e.clientX, e.clientY, e.pointerId]; board.setPointerCapture?.(e.pointerId); });
        on(board, 'pointerup', (e) => {
          if (!from || from[2] !== e.pointerId) return;
          const dx = e.clientX - from[0], dy = e.clientY - from[1]; from = null;
          if (Math.max(Math.abs(dx), Math.abs(dy)) < 20) { board.focus({ preventScroll: true }); return; }
          push(Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 'right' : 'left') : (dy > 0 ? 'down' : 'up'));
        });
        on(board, 'pointercancel', () => { from = null; });
        paint = (clockOnly) => {
          const b0 = best();
          chips([['🐍 ' + game.body.length], ['⭐ ' + game.score], b0 != null && ['🏆 ' + b0]]);
          if (clockOnly) return;
          if (game.ended) finish(false, game.score);
          info.textContent = game.ended ? (game.won ? '판을 꽉 채웠어요!' : '쿵! 다시 해 볼까요?') : !st.started ? '방향키·WASD·스와이프로 시작해요' : '먹을 걸 먹으면 길어져요 · 벽과 몸에 부딪히면 끝';
          // Only the cells that changed are touched each step.
          const next = cells.map(() => '');
          game.body.forEach((i, k) => { next[i] = k ? 'body' : 'head'; });
          if (game.food >= 0) next[game.food] = 'food';
          next.forEach((s, i) => { if (shown[i] !== s) { shown[i] = s; if (s) cells[i].dataset.s = s; else delete cells[i].dataset.s; } });
          cells[game.body[0]].dataset.dir = game.dir;
          if (game.ended) showResult(game.won ? '완벽해요!' : '게임 끝', '먹은 개수 ' + game.score + ' · 길이 ' + game.body.length);
        };
      }

      if (mode === 'recipe') {
        const NAMES = ['딸기', '우유', '설탕', '얼음', '연유', '생크림'];
        board.style.setProperty('--cols', String(game.pads > 4 ? 3 : 2));
        board.style.setProperty('--fit', game.pads > 4 ? '1.5' : '1');
        let playing = false;
        const pads = Array.from({ length: game.pads }, (_, i) => {
          const b = button(NAMES[i], () => {
            if (playing || game.ended) return;
            begin(); flash(i, 180);
            const r = game.press(i);
            if (r === 'round') setTimeout(play, 650);
            paint();
          });
          b.dataset.cell = String(i); b.dataset.pad = String(i); board.append(b); return b;
        });
        const flash = (i, ms) => { pads[i].dataset.lit = ''; setTimeout(() => delete pads[i].dataset.lit, ms); };
        const play = () => {
          if (game.ended || !content.contains(board)) return;
          playing = true; paint();
          game.sequence.forEach((p, k) => { const t = setTimeout(() => flash(p, game.speed * 0.7), 300 + k * game.speed); timers.push(t); });
          timers.push(setTimeout(() => { playing = false; paint(); }, 300 + game.sequence.length * game.speed));
        };
        const startBtn = button('시작', () => { if (playing || st.started) return; begin(); play(); }, 'gfx-game-hint');
        tools.append(startBtn);
        paint = (clockOnly) => {
          const b0 = best();
          chips([['🥛 ' + game.round + '단계'], b0 != null && ['🏆 ' + b0 + '단계']]);
          if (clockOnly) return;
          startBtn.disabled = !!st.started;
          if (game.ended) finish(false, game.round);
          info.textContent = game.ended ? '레시피가 틀렸어요!' : !st.started ? '[시작]을 누르고 재료 순서를 기억하세요' : playing ? '잘 보세요…' : '같은 순서로 넣으세요 (' + game.at + '/' + game.sequence.length + ')';
          pads.forEach((b) => { b.disabled = game.ended || playing || !st.started; });
          if (game.ended) showResult('레시피 실패!', game.round + '단계까지 성공했어요');
        };
      }

      if (mode === 'pop') {
        const cells = game.cells.map((_, i) => {
          const b = button('', () => { if (game.ended) return; begin(); game.pop(i); hover = -1; paint(); });
          b.dataset.cell = String(i); board.append(b);
          on(b, 'pointerenter', () => { hover = i; paint(); }); on(b, 'pointerleave', () => { if (hover === i) { hover = -1; paint(); } });
          return b;
        });
        let hover = -1;
        paint = (clockOnly) => {
          const b0 = best(), left = game.cells.filter(Boolean).length;
          chips([['🍫 ' + game.score + '점'], ['남은 칩 ' + left], b0 != null && ['🏆 ' + b0 + '점']]);
          if (clockOnly) return;
          if (game.ended) finish(false, game.score);
          const group = hover >= 0 ? game.group(hover) : [];
          info.textContent = game.ended ? (game.won ? '모두 터뜨렸어요! +100' : '더 터뜨릴 덩어리가 없어요') : group.length > 1 ? group.length + '개 덩어리 · ' + (group.length - 1) * (group.length - 1) + '점' : '같은 색이 2개 이상 붙어 있으면 눌러 터뜨려요';
          cells.forEach((b, i) => { const v = game.cells[i]; b.dataset.v = String(v); b.dataset.group = String(group.length > 1 && group.includes(i)); b.disabled = game.ended || !v; b.setAttribute('aria-label', (i + 1) + '번 칩 ' + (v || '빈 칸')); });
          if (game.ended) showResult(game.won ? '깨끗하게 비웠어요!' : '게임 끝', game.score + '점');
        };
      }

      if (mode === 'slide') {
        const cells = game.cells.map((_, i) => { const b = button('', () => { begin(); if (game.slide(i)) paint(); }); b.dataset.cell = String(i); board.append(b); return b; });
        paint = (clockOnly) => {
          const b0 = best();
          chips([['🔁 ' + game.moves + '번'], ['⏱ ' + clock(elapsed())], b0 != null && ['🏆 ' + b0 + '번']]);
          if (clockOnly) return;
          if (game.ended) finish(true, game.moves);
          info.textContent = game.ended ? '꽃밭 완성!' : '빈칸 옆 조각을 눌러 1부터 순서대로 맞추세요';
          cells.forEach((b, i) => { const v = game.cells[i]; b.textContent = v ? String(v) : ''; b.dataset.blank = String(!v); b.dataset.home = String(!!v && v === i + 1); b.disabled = game.ended || !v; b.setAttribute('aria-label', v ? v + '번 조각' : '빈칸'); });
          if (game.ended) showResult('꽃밭 완성!', game.moves + '번 · ' + clock(elapsed()));
        };
      }

      if (mode === 'lights') {
        const cells = game.cells.map((_, i) => { const b = button('', () => { begin(); game.press(i); paint(); }); b.dataset.cell = String(i); board.append(b); return b; });
        paint = (clockOnly) => {
          const b0 = best(), lit = game.cells.filter(Boolean).length;
          chips([['⭐ ' + lit + '/' + game.cells.length], ['🔁 ' + game.moves + '번'], b0 != null && ['🏆 ' + b0 + '번']]);
          if (clockOnly) return;
          if (game.ended) finish(true, game.moves);
          info.textContent = game.ended ? '밤하늘이 가득 찼어요!' : '누른 별과 상하좌우가 켜졌다 꺼져요 · 모든 별을 밝히세요';
          cells.forEach((b, i) => { b.dataset.on = String(game.cells[i]); b.disabled = game.ended; b.setAttribute('aria-label', (i + 1) + '번 별 ' + (game.cells[i] ? '켜짐' : '꺼짐')); });
          if (game.ended) showResult('모든 별 반짝!', game.moves + '번 만에');
        };
      }
      if (['dino', 'water', 'candy', 'knife', 'count'].includes(mode)) {
        const kind = mode;
        const [W, H] = ({ dino: [600, 170], water: [360, 460], candy: [360, 452], knife: [360, 520], count: [360, 560] })[kind];
        board.style.setProperty('--fit', String(W / (H + (kind === 'dino' ? 70 : 0))));
        const canvas = el('canvas', 'gfx-arcade-canvas'), ctx = canvas.getContext('2d');
        canvas.style.aspectRatio = W + '/' + H;
        canvas.setAttribute('role', 'img'); canvas.setAttribute('aria-label', g.name + ' 게임 화면');
        board.tabIndex = 0; board.setAttribute('role', 'application'); board.setAttribute('aria-label', g.name);
        board.append(canvas);
        const focus = () => board.focus({ preventScroll: true });
        const toWorld = e => { const r = canvas.getBoundingClientRect(); return { x: (e.clientX - r.left) / r.width * W, y: (e.clientY - r.top) / r.height * H }; };
        const inputLife = new AbortController();
        let paintExtra = () => {}, release = () => {}, drawGame = () => {}, onStep = () => {}, sign = () => '', keyDown = () => {}, keyUp = () => {};
        st.pause = () => { release(); inputLife.abort(); };
        const KEYS = [' ', 'enter', 'arrowup', 'arrowdown', 'arrowleft', 'arrowright', 'w', 'a', 's', 'd'];
        on(board, 'keydown', e => { const k = e.key.toLowerCase(); if (!KEYS.includes(k)) return; e.preventDefault(); keyDown(k, e.repeat); });
        on(board, 'keyup', e => { const k = e.key.toLowerCase(); if (KEYS.includes(k)) keyUp(k); });
        on(board, 'blur', () => release());
        window.addEventListener('blur', () => release(), { signal: inputLife.signal });
        const font = (size, weight = 'bold') => weight + ' ' + size + 'px "Malgun Gothic", "Apple SD Gothic Neo", sans-serif';
        const label = (text, x, y, size, color, align = 'center', f) => { ctx.font = f || font(size); ctx.textAlign = align; ctx.textBaseline = 'middle'; ctx.fillStyle = color; ctx.fillText(text, x, y); };
        const fill = (x, y, w, h, c) => { ctx.fillStyle = c; ctx.fillRect(x, y, w, h); };
        const disc = (x, y, r, c) => { ctx.fillStyle = c; ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill(); };
        const ease = p => p < 0 ? 0 : p > 1 ? 1 : p * p * (3 - 2 * p);
        const lerp = (a, b, p) => a + (b - a) * p;

        if (kind === 'dino') {
          // Chrome's offline T-Rex: grey pixel sprites on white, the colours swap every 700 points.
          const GROUND = 150, CELL = 2;
          const BODY = ['............########..', '...........##.#######.', '...........##########.', '...........##########.', '...........##########.', '...........#####......',
            '...........########...', '#.........#####.......', '#.......#######.......', '##.....##########.....', '###...###########.....', '#############..#......', '.############.........',
            '..###########.........', '...#########..........', '....#######...........', '.....#####............'];
          const LEGS = { still: ['.....##.##', '.....#...#', '.....#...#', '.....##..##'], a: ['.....##.##', '.....#...##', '.....#....', '.....##...'], b: ['.....##.##', '.....##..#', '.........#', '.........##'] };
          const DUCK = ['.................##########...', '#...............##.#########..', '##.......#################....', '############################..', '.#####################........',
            '..###############.............', '...############...............', '....##########................'];
          const pixels = (rows, x, top, color, dx = 0) => { ctx.fillStyle = color; rows.forEach((row, r) => { for (let c = 0; c < row.length; c++) if (row[c] === '#') ctx.fillRect(x + (c + dx) * CELL, top + r * CELL, CELL, CELL); }); };
          const BUMPS = Array.from({ length: 34 }, (_, i) => ({ x: (i * 197) % 1200, w: 1 + (i * 7) % 5, y: 3 + (i * 5) % 9, up: i % 9 === 0 }));
          let endedWall = 0, lastHundreds = 0;
          const pad = el('div', 'gfx-arcade-pad'); board.append(pad);
          const restart = () => { if (performance.now() - endedWall > 450) renew(); };
          const press = () => { if (game.ended) return restart(); if (game.jump()) { begin(); sfx.play('tap'); } focus(); };
          const hold = (text, down, up) => {
            const b = button(text, () => {});
            on(b, 'pointerdown', e => { e.preventDefault(); b.setPointerCapture?.(e.pointerId); b.dataset.held = ''; down(); focus(); });
            for (const ev of ['pointerup', 'pointercancel', 'lostpointercapture']) on(b, ev, () => { delete b.dataset.held; up(); });
            return b;
          };
          pad.append(hold('▲ 점프', press, () => game.release()), hold('▼ 숙이기', () => { if (!game.ended) { game.duck(true); begin(); } }, () => game.duck(false)));
          on(canvas, 'pointerdown', e => { e.preventDefault(); press(); });
          for (const ev of ['pointerup', 'pointercancel']) on(canvas, ev, () => game.release());
          release = () => { game.release(); game.duck(false); };
          keyDown = (k, repeat) => {
            if (k === 'arrowdown' || k === 's') { if (!game.ended) { game.duck(true); begin(); } }
            else if ([' ', 'enter', 'arrowup', 'w'].includes(k) && !repeat) press();
          };
          keyUp = k => { if (k === 'arrowdown' || k === 's') game.duck(false); else game.release(); };
          onStep = dt => {
            game.step(dt);
            if (game.hundreds > lastHundreds) { lastHundreds = game.hundreds; sfx.play('level'); }
            if (game.ended && !endedWall) { endedWall = performance.now(); sfx.play('lose'); navigator.vibrate?.(40); finish(false, game.score); }
          };
          sign = () => [game.ended, game.started, Math.floor(game.score / 100)].join('/');
          drawGame = () => {
            const dark = (panel.dataset.theme === 'night') !== (Math.floor(game.score / 700) % 2 === 1);
            const bg = dark ? '#202124' : '#f7f7f7', ink = dark ? '#d1d1d1' : '#535353', cloud = dark ? '#3c4043' : '#dcdcdc';
            fill(0, 0, W, H, bg);
            if (dark) for (let i = 0; i < 9; i++) fill(((i * 131 - game.distance * 0.05) % W + W) % W, 18 + (i * 37) % 70, 2, 2, cloud);
            for (let i = 0; i < 3; i++) {
              const x = ((i * 230 + 120 - game.distance * 0.2) % 760 + 760) % 760 - 80, y = 34 + (i * 23) % 50;
              fill(x + 12, y, 18, 3, cloud); fill(x + 6, y + 3, 30, 4, cloud); fill(x, y + 7, 46, 5, cloud);
            }
            fill(0, GROUND - 2, W, 1, ink);
            for (const tile of [0, 1200]) for (const b of BUMPS) {
              const x = ((b.x + tile - game.distance) % 2400 + 2400) % 2400 - 600;
              if (x < -10 || x > W) continue;
              if (b.up) fill(x, GROUND - 4, 6, 2, ink); else fill(x, GROUND - 2 + b.y, b.w, 1, ink);
            }
            for (const o of game.obstacles) {
              if (o.kind === 'ptero') {
                const x = Math.round(o.x), top = GROUND - o.y - o.h, up = Math.floor(game.time * 6 + o.seed) % 2 === 0;
                ctx.fillStyle = ink;
                fill(x + 12, top + 18, 26, 6, ink); fill(x + 4, top + 14, 12, 7, ink); fill(x + 9, top + 11, 6, 3, ink);
                ctx.beginPath(); ctx.moveTo(x, top + 18); ctx.lineTo(x + 5, top + 15); ctx.lineTo(x + 5, top + 20); ctx.fill();
                ctx.beginPath(); ctx.moveTo(x + 37, top + 18); ctx.lineTo(x + 46, top + 17); ctx.lineTo(x + 37, top + 24); ctx.fill();
                ctx.beginPath();
                if (up) { ctx.moveTo(x + 16, top + 18); ctx.lineTo(x + 22, top + 1); ctx.lineTo(x + 30, top + 1); ctx.lineTo(x + 30, top + 18); }
                else { ctx.moveTo(x + 16, top + 24); ctx.lineTo(x + 30, top + 24); ctx.lineTo(x + 30, top + 39); ctx.lineTo(x + 23, top + 39); }
                ctx.fill(); fill(x + 8, top + 15, 2, 2, bg);
              } else {
                const unit = o.w / o.size;
                for (let k = 0; k < o.size; k++) {
                  const x = Math.round(o.x + k * unit), w = unit, h = o.h - (k % 2) * (o.kind === 'large' ? 6 : 4), base = GROUND + 1, top = base - h;
                  const tw = Math.round(w * 0.36), tx = Math.round(x + (w - tw) / 2), aw = Math.max(3, Math.round(w * 0.2));
                  fill(tx, top + 2, tw, h - 2, ink); fill(tx + 1, top, tw - 2, 2, ink);
                  fill(x + 1, base - h * 0.74, aw, h * 0.3, ink); fill(x + 1, base - h * 0.48, tx - x - 1, aw, ink);
                  fill(x + w - aw - 1, base - h * 0.84, aw, h * 0.3, ink); fill(tx + tw, base - h * 0.58, x + w - aw - 1 - tx - tw + aw, aw, ink);
                  fill(tx + 2, top + 6, 1, 2, bg); fill(tx + tw - 3, top + 14, 1, 2, bg);
                }
              }
            }
            const feet = GROUND - Math.round(game.y), running = game.started && !game.ended && game.y === 0;
            const legs = running ? (Math.floor(game.distance / 36) % 2 ? LEGS.a : LEGS.b) : LEGS.still;
            if (game.ducking && game.y === 0 && !game.ended) { pixels(DUCK, game.x, feet - 24, ink); pixels(legs, game.x, feet - 8, ink, 2); }
            else {
              pixels(BODY, game.x, feet - 42, ink); pixels(legs, game.x, feet - 8, ink);
              if (game.ended) { fill(game.x + 24, feet - 42, 6, 6, bg); fill(game.x + 26, feet - 40, 2, 2, ink); }
            }
            const pad5 = n => String(Math.min(99999, n)).padStart(5, '0'), hi = best();
            const blink = game.flash > 0 && Math.floor(game.flash * 8) % 2 === 0;
            const shown = game.flash > 0 ? game.hundreds * 100 : game.score;
            label((hi != null ? 'HI ' + pad5(hi) + '  ' : '') + (blink ? '' : pad5(shown)), W - 12, 20, 13, ink, 'right', 'bold 13px "Courier New", monospace');
            if (!game.started) label('스페이스 · 탭으로 시작', W / 2, 68, 13, ink, 'center', font(13, 'normal'));
            if (game.ended) {
              label('G A M E   O V E R', W / 2, 58, 16, ink, 'center', 'bold 16px "Courier New", monospace');
              ctx.strokeStyle = ink; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(W / 2, 94, 11, -0.4 * Math.PI, 1.35 * Math.PI); ctx.stroke();
              ctx.fillStyle = ink; ctx.beginPath(); ctx.moveTo(W / 2 + 3, 79); ctx.lineTo(W / 2 + 12, 85); ctx.lineTo(W / 2 + 2, 89); ctx.fill();
            }
          };
        } else if (kind === 'water') {
          // Water Sort Puzzle: glass tubes on a dark backdrop; the picked tube lifts, flies over the other, tips and pours.
          const COLORS = ['#e53935', '#1e88e5', '#43a047', '#fdd835', '#8e24aa', '#fb8c00', '#ec407a', '#4dd0e1', '#9ccc65', '#6d4c41'];
          const NAMES = ['빨강', '파랑', '초록', '노랑', '보라', '주황', '분홍', '하늘', '연두', '갈색'];
          const TW = 34, LH = 26, TH = LH * 4 + 26, DUR = 820;
          let sel = -1, msg = '', anim = null, clearedSaved = false;
          const doneAt = {};
          const layout = () => {
            const n = game.bottles.length, rows = n > 6 ? 2 : 1, per = Math.ceil(n / rows);
            return game.bottles.map((_, i) => {
              const r = Math.floor(i / per), c = i % per, inRow = r === rows - 1 ? n - per * (rows - 1) : per, gap = (W - inRow * TW) / (inRow + 1);
              const bottom = rows === 1 ? 345 : r ? 425 : 250;
              return { x: gap + c * (TW + gap), top: bottom - TH, bottom };
            });
          };
          const nextLevel = level => { st.game = newWaterSortGame(Math.random, st.level, level); st.started = 0; st.stopped = 0; st.recorded = false; st.newBest = false; show(mode); };
          const undo = button('↶ 되돌리기', () => { if (anim) return; if (game.undo()) { sel = -1; msg = ''; sfx.play('move'); paint(); } });
          const add = button('+ 빈 병', () => { if (anim) return; if (game.addBottle()) { sel = -1; sfx.play('pop'); paint(); } });
          const again = button('⟲ 이 레벨 다시', () => nextLevel(game.level));
          tools.append(undo, add, again);
          const tap = p => {
            if (anim) return;
            if (game.won) return nextLevel(game.level + 1);
            const L = layout(), i = L.findIndex(b => p.x >= b.x - 10 && p.x <= b.x + TW + 10 && p.y >= b.top - 34 && p.y <= b.bottom + 14);
            msg = '';
            if (i < 0) { sel = -1; return; }
            if (sel < 0) { if (game.bottles[i].length && !game.done(i)) { sel = i; sfx.play('tap'); } else sfx.play('nope'); return; }
            if (sel === i) { sel = -1; return; }
            const from = game.bottles[sel], color = from[from.length - 1], n = game.pour(sel, i);
            if (n) { begin(); anim = { from: sel, to: i, n, color, t0: performance.now(), poured: false }; sel = -1; }
            else { sfx.play('nope'); msg = '같은 색 위나 빈 병에만 부을 수 있어요'; sel = game.bottles[i].length && !game.done(i) ? i : -1; }
          };
          on(canvas, 'pointerdown', e => { e.preventDefault(); tap(toWorld(e)); focus(); });
          keyDown = k => { if ((k === ' ' || k === 'enter') && game.won && !anim) nextLevel(game.level + 1); };
          onStep = () => {
            if (!anim) return;
            const p = (performance.now() - anim.t0) / DUR;
            if (p > 0.25 && !anim.poured) { anim.poured = true; sfx.play('pop', 2); }
            if (p >= 1) {
              const to = anim.to; anim = null;
              if (game.done(to)) { doneAt[to] = performance.now(); sfx.play('match'); }
              if (game.won && !clearedSaved) {
                clearedSaved = true; sfx.play('win');
                st.newBest = saveGameBest(mode + '-' + st.level, game.level, false);
              }
              paint();
            }
          };
          sign = () => [game.moves, game.undos, game.extra, game.won, !!anim, msg].join('/');
          const tubePath = (x, top, bottom, inset = 0) => {
            const r = TW / 2 - inset;
            ctx.beginPath(); ctx.moveTo(x + inset, top); ctx.lineTo(x + inset, bottom - TW / 2);
            ctx.arc(x + TW / 2, bottom - TW / 2, r, Math.PI, 0, true); ctx.lineTo(x + TW - inset, top);
          };
          const drawTube = (x, top, bottom, layers, glow) => {
            ctx.save(); tubePath(x, top - 2, bottom, 3); ctx.closePath(); ctx.clip();
            let y = bottom - 3;
            for (const l of layers) { if (l.a <= 0) continue; const h = l.a * LH; fill(x, y - h, TW, h + 0.6, COLORS[l.c]); fill(x, y - h, TW, Math.min(3, h), 'rgba(255,255,255,.22)'); y -= h; }
            fill(x + 6, top, 4, bottom - top, 'rgba(255,255,255,.16)');
            ctx.restore();
            tubePath(x, top, bottom); ctx.lineWidth = 2.5; ctx.strokeStyle = glow || 'rgba(235,242,255,.85)'; ctx.stroke();
            ctx.fillStyle = glow || 'rgba(235,242,255,.9)'; ctx.beginPath(); ctx.roundRect(x - 4, top - 4, TW + 8, 5, 2.5); ctx.fill();
          };
          const layersOf = b => b.map(c => ({ c, a: 1 }));
          drawGame = () => {
            const now = performance.now();
            const grad = ctx.createLinearGradient(0, 0, 0, H); grad.addColorStop(0, '#2d3a5c'); grad.addColorStop(1, '#151b2c');
            ctx.fillStyle = grad; ctx.fillRect(0, 0, W, H);
            label('레벨 ' + game.level, W / 2, 34, 22, '#ffffff');
            label('되돌리기 ' + game.undos + '번 남음' + (game.extra ? '' : ' · 빈 병 1개 추가 가능'), W / 2, 60, 12, 'rgba(220,228,255,.7)', 'center', font(12, 'normal'));
            const L = layout(), p = anim ? Math.min(1, (now - anim.t0) / DUR) : 0, q = anim ? ease((p - 0.25) / 0.45) : 0;
            game.bottles.forEach((b, i) => {
              if (anim && i === anim.from) return;
              const { x, top, bottom } = L[i], lift = i === sel ? 18 : 0;
              let layers = layersOf(b);
              if (anim && i === anim.to) { layers = layersOf(b.slice(0, b.length - anim.n)); layers.push({ c: anim.color, a: anim.n * q }); }
              drawTube(x, top - lift, bottom - lift, layers, i === sel ? '#ffe27a' : null);
              const since = now - (doneAt[i] || -1e9);
              if (game.done(i) && since < 1100) {
                for (let k = 0; k < 8; k++) { const a = k * Math.PI / 4 + since / 400, r = 18 + since / 30; disc(x + TW / 2 + Math.cos(a) * r, top - 6 + Math.sin(a) * r * 0.6, 2.5 * (1 - since / 1100), COLORS[b[0]]); }
              }
            });
            if (anim) {
              const s = L[anim.from], t = L[anim.to], side = s.x < t.x ? -1 : 1;
              const startX = s.x + TW / 2, startY = s.top - 18, endX = t.x + TW / 2 + side * 8, endY = t.top - 14;
              const m = p < 0.7 ? ease(p / 0.25) : 1 - ease((p - 0.7) / 0.3), angle = -side * 1.95 * m;
              const px = lerp(startX, endX, m), py = lerp(startY, endY, m);
              const src = game.bottles[anim.from], layers = layersOf(src); layers.push({ c: anim.color, a: anim.n * (1 - q) });
              if (p > 0.25 && p < 0.72) {
                const surface = t.bottom - 3 - (game.bottles[anim.to].length - anim.n + anim.n * q) * LH;
                fill(px - 2.5, py, 5, Math.max(0, surface - py), COLORS[anim.color]);
              }
              ctx.save(); ctx.translate(px, py); ctx.rotate(angle); drawTube(-TW / 2, 0, TH, layers); ctx.restore();
            }
            if (game.won && !anim) {
              fill(0, 0, W, H, 'rgba(10,14,25,.6)');
              label('레벨 ' + game.level + ' 클리어!', W / 2, H / 2 - 20, 28, '#ffe27a');
              label(game.moves + '번 만에 정리했어요', W / 2, H / 2 + 16, 14, '#ffffff', 'center', font(14, 'normal'));
              label('탭해서 다음 레벨', W / 2, H / 2 + 52, 15, '#ffffff');
            }
          };
          paintExtra = () => {
            undo.textContent = '↶ 되돌리기 ' + game.undos; undo.disabled = !game.history.length || game.undos <= 0 || game.won;
            add.disabled = game.extra || game.won;
            const stuck = !game.won && !game.bottles.some((_, i) => game.bottles.some((_, j) => game.canPour(i, j)));
            info.textContent = game.won ? '다음 레벨로 넘어가려면 화면을 누르세요' : msg || (stuck ? '더 부을 곳이 없어요 · 되돌리기나 빈 병 추가를 써 보세요' : sel >= 0 ? '부을 병을 누르세요' : '병을 누른 뒤 부을 병을 누르세요 · 같은 색끼리 모으면 깨요');
            canvas.setAttribute('aria-label', '레벨 ' + game.level + ' · ' + game.bottles.map((b, i) => (i + 1) + '번 병 ' + (b.length ? b.map(c => NAMES[c]).join(' ') : '빔')).join(' / '));
            const b0 = best(); chips([['레벨 ' + game.level], b0 != null && ['🏆 레벨 ' + b0]]);
          };
        } else if (kind === 'candy') {
          // Candy Crush: glossy candies on a see-through board. Swipe a candy, or tap two neighbours, to swap them.
          const N = 8, CS = 42, BX = 12, BY = 98;
          const COLORS = [['#ff6b78', '#d0142f'], ['#ffb04d', '#dd640c'], ['#fff07a', '#e3ad00'], ['#7de37a', '#219a2c'], ['#6ab8ff', '#1459cf'], ['#d68bff', '#7c22c7']];
          const CHEERS = ['', '', '달콤해!', '맛있어!', '훌륭해!', '환상적!'];
          const disp = new Map();
          let ghosts = [], sel = null, drag = null, idleAt = performance.now(), saved = false, banner = null, bad = null;
          const cellXY = (r, c) => ({ x: BX + c * CS + CS / 2, y: BY + r * CS + CS / 2 });
          const nextLevel = level => { st.game = newCandyGame(Math.random, st.level, level); st.started = 0; st.stopped = 0; st.recorded = false; st.newBest = false; show(mode); };
          tools.append(button('⟲ 이 레벨 다시', () => nextLevel(game.level)));
          const cellAt = p => { const c = Math.floor((p.x - BX) / CS), r = Math.floor((p.y - BY) / CS); return r >= 0 && r < N && c >= 0 && c < N ? [r, c] : null; };
          const attempt = (a, b) => {
            const res = game.trySwap(a, b); sel = null; idleAt = performance.now();
            if (res === 'ok') { begin(); sfx.play('move'); }
            else if (res === 'bad') { sfx.play('nope'); bad = { a, b, t0: performance.now() }; }
          };
          on(canvas, 'pointerdown', e => {
            e.preventDefault(); focus();
            if (game.ended) return nextLevel(game.won ? game.level + 1 : game.level);
            const p = toWorld(e), cell = cellAt(p);
            if (!cell || game.phase !== 'idle') return;
            canvas.setPointerCapture?.(e.pointerId);
            drag = { id: e.pointerId, cell, x: p.x, y: p.y, used: false };
            if (sel && Math.abs(sel[0] - cell[0]) + Math.abs(sel[1] - cell[1]) === 1) { attempt(sel, cell); drag.used = true; }
            else { sel = sel && sel[0] === cell[0] && sel[1] === cell[1] ? null : cell; sfx.play('tap'); }
          });
          on(canvas, 'pointermove', e => {
            if (!drag || drag.id !== e.pointerId || drag.used) return;
            const p = toWorld(e), dx = p.x - drag.x, dy = p.y - drag.y;
            if (Math.max(Math.abs(dx), Math.abs(dy)) < 14) return;
            const [r, c] = drag.cell, to = Math.abs(dx) > Math.abs(dy) ? [r, c + Math.sign(dx)] : [r + Math.sign(dy), c];
            drag.used = true;
            if (to[0] >= 0 && to[0] < N && to[1] >= 0 && to[1] < N) attempt(drag.cell, to);
          });
          for (const ev of ['pointerup', 'pointercancel', 'lostpointercapture']) on(canvas, ev, () => { drag = null; });
          keyDown = k => { if ((k === ' ' || k === 'enter') && game.ended) nextLevel(game.won ? game.level + 1 : game.level); };
          onStep = dt => {
            const s = dt / 1000; let moving = false;
            game.grid.forEach((row, r) => row.forEach((q, c) => {
              if (!q) return;
              const t = cellXY(r, c); let d = disp.get(q.id);
              if (!d) { d = { x: t.x, y: t.y, v: 0 }; disp.set(q.id, d); }
              if (d.x !== t.x) { const k = 400 * s; d.x = Math.abs(t.x - d.x) <= k ? t.x : d.x + Math.sign(t.x - d.x) * k; moving = true; }
              if (d.y !== t.y) {
                if (Math.abs(t.y - d.y) <= CS * 1.05 && d.v === 0) { const k = 400 * s; d.y = Math.abs(t.y - d.y) <= k ? t.y : d.y + Math.sign(t.y - d.y) * k; }
                else { d.v = Math.min(1100, d.v + 3000 * s); const k = Math.max(260, d.v) * s; if (Math.abs(t.y - d.y) <= k) { d.y = t.y; d.v = 0; } else d.y += Math.sign(t.y - d.y) * k; }
                moving = true;
              }
            }));
            for (const g2 of ghosts) g2.t -= s;
            ghosts = ghosts.filter(g2 => g2.t > 0);
            if (bad && performance.now() - bad.t0 > 320) bad = null;
            if (banner && (banner.t -= s) <= 0) banner = null;
            if (game.phase !== 'busy' || moving || ghosts.some(g2 => g2.t > g2.T - 0.16)) return;
            const ev = game.settle();
            if (ev.type === 'clear') {
              for (const q of ev.cleared) { const p = cellXY(q.r, q.c); ghosts.push({ ...q, x: p.x, y: p.y, t: 0.3, T: 0.3 }); disp.delete(q.id); }
              const big = ev.combo || ev.cleared.length > 9;
              sfx.play(big ? 'clear' : 'pop', Math.min(4, game.cascade)); if (ev.created.length) sfx.play('match');
              if (big || game.cascade >= 3) navigator.vibrate?.(15);
              if (CHEERS[Math.min(5, game.cascade)] && !game.sugar) banner = { text: CHEERS[Math.min(5, game.cascade)], t: 1, T: 1 };
            } else if (ev.type === 'fall') {
              const count = {};
              for (const sp of ev.spawned) count[sp.c] = (count[sp.c] || 0) + 1;
              for (const sp of ev.spawned) { const t = cellXY(sp.r, sp.c); disp.set(sp.id, { x: t.x, y: t.y - count[sp.c] * CS - 8, v: 1 }); }
              for (const id of ev.fell) { const d = disp.get(id); if (d) d.v = 1; }
            } else if (ev.type === 'sugar') { if (!banner || banner.text !== '슈가 크러시!') banner = { text: '슈가 크러시!', t: 1.8, T: 1.8 }; sfx.play('level'); }
            else if (ev.type === 'shuffle') { banner = { text: '사탕을 섞어요', t: 1.1, T: 1.1 }; sfx.play('move'); }
            else if (ev.type === 'won' || ev.type === 'lost') {
              sfx.play(ev.type === 'won' ? 'win' : 'lose');
              if (ev.type === 'won' && !saved) { saved = true; st.newBest = saveGameBest(mode + '-' + st.level, game.level, false); }
              paint();
            } else if (ev.type === 'ready') idleAt = performance.now();
          };
          sign = () => [game.score, game.moves, game.phase, game.level].join('/');
          const shapePath = (color, r) => {
            ctx.beginPath();
            if (color === 0) ctx.ellipse(0, 0, r * 1.02, r * 0.7, -0.55, 0, Math.PI * 2);
            else if (color === 1) { ctx.roundRect(-r * 0.66, -r * 0.66, r * 1.32, r * 1.32, r * 0.3); }
            else if (color === 2) { ctx.moveTo(-r * 1.05, 0); ctx.quadraticCurveTo(0, -r * 1.25, r * 1.05, 0); ctx.quadraticCurveTo(0, r * 1.25, -r * 1.05, 0); }
            else if (color === 3) ctx.roundRect(-r * 0.8, -r * 0.8, r * 1.6, r * 1.6, r * 0.32);
            else if (color === 4) ctx.arc(0, 0, r * 0.88, 0, Math.PI * 2);
            else { for (let k = 0; k < 6; k++) { const a = k * Math.PI / 3 - Math.PI / 2; ctx.lineTo(Math.cos(a) * r * 0.95, Math.sin(a) * r * 0.95); } ctx.closePath(); }
          };
          const candyAt = (x, y, q, scale = 1, alpha = 1) => {
            const r = CS * 0.4 * scale;
            ctx.save(); ctx.globalAlpha = alpha; ctx.translate(x, y);
            if (q.kind === 'b') {
              const gr = ctx.createRadialGradient(-r * 0.3, -r * 0.3, 1, 0, 0, r * 0.95); gr.addColorStop(0, '#9a5b2e'); gr.addColorStop(1, '#3d2008');
              disc(0, 0, r * 0.92, gr);
              const dots = ['#ff6b78', '#fff07a', '#7de37a', '#6ab8ff', '#d68bff', '#ffffff'];
              for (let k = 0; k < 14; k++) { const a = k * 2.39, d = r * (0.25 + (k * 37 % 60) / 100); disc(Math.cos(a) * d, Math.sin(a) * d, r * 0.09, dots[k % 6]); }
              ctx.restore(); return;
            }
            const [light, dark] = COLORS[q.color];
            if (q.kind === 'w') {
              ctx.fillStyle = dark; ctx.globalAlpha = alpha * 0.85;
              for (const sd of [-1, 1]) { ctx.beginPath(); ctx.moveTo(sd * r * 0.7, 0); ctx.lineTo(sd * r * 1.2, -r * 0.55); ctx.lineTo(sd * r * 1.2, r * 0.55); ctx.closePath(); ctx.fill(); }
              ctx.globalAlpha = alpha; ctx.lineWidth = 2.5; ctx.strokeStyle = 'rgba(255,255,255,.75)'; ctx.beginPath(); ctx.roundRect(-r * 0.9, -r * 0.9, r * 1.8, r * 1.8, r * 0.4); ctx.stroke();
            }
            const gr = ctx.createRadialGradient(-r * 0.35, -r * 0.4, r * 0.1, 0, 0, r * 1.1); gr.addColorStop(0, light); gr.addColorStop(1, dark);
            shapePath(q.color, r); ctx.fillStyle = gr; ctx.fill(); ctx.lineWidth = 1.5; ctx.strokeStyle = 'rgba(0,0,0,.18)'; ctx.stroke();
            if (q.color === 4) { ctx.strokeStyle = 'rgba(255,255,255,.55)'; ctx.lineWidth = 2; ctx.beginPath(); for (let a = 0; a < 9; a += 0.3) ctx.lineTo(Math.cos(a) * a * r * 0.09, Math.sin(a) * a * r * 0.09); ctx.stroke(); }
            if (q.kind === 'h' || q.kind === 'v') {
              ctx.save(); shapePath(q.color, r); ctx.clip(); ctx.fillStyle = 'rgba(255,255,255,.85)';
              for (let k = -3; k <= 3; k++) { if (q.kind === 'h') ctx.fillRect(-r * 1.3, k * r * 0.34 - r * 0.07, r * 2.6, r * 0.14); else ctx.fillRect(k * r * 0.34 - r * 0.07, -r * 1.3, r * 0.14, r * 2.6); }
              ctx.restore();
            }
            ctx.fillStyle = 'rgba(255,255,255,.55)'; ctx.beginPath(); ctx.ellipse(-r * 0.3, -r * 0.38, r * 0.3, r * 0.15, -0.5, 0, Math.PI * 2); ctx.fill();
            ctx.restore();
          };
          drawGame = () => {
            const now = performance.now();
            const bg = ctx.createLinearGradient(0, 0, 0, H); bg.addColorStop(0, '#8fd0ff'); bg.addColorStop(1, '#4a73d6');
            ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);
            for (let k = 0; k < 18; k++) disc((k * 83) % W, 20 + (k * 53) % (H - 20), 3 + k % 4, 'rgba(255,255,255,.12)');
            // Top bar: moves, level and target, score with three stars.
            ctx.fillStyle = 'rgba(255,255,255,.9)'; ctx.beginPath(); ctx.roundRect(10, 10, 78, 74, 14); ctx.fill();
            label('이동', 49, 28, 13, '#5b4b8a'); label(String(game.moves), 49, 58, 30, game.moves <= 5 ? '#e53950' : '#3a2f6b');
            ctx.fillStyle = 'rgba(255,255,255,.9)'; ctx.beginPath(); ctx.roundRect(96, 10, 254, 74, 14); ctx.fill();
            label('레벨 ' + game.level + ' · 목표 ' + game.target.toLocaleString(), 223, 26, 13, '#5b4b8a');
            label(game.score.toLocaleString(), 223, 50, 22, '#3a2f6b');
            const full = game.target * 2, fx = 110, fw = 226;
            fill(fx, 68, fw, 8, '#e3dcf5'); fill(fx, 68, fw * Math.min(1, game.score / full), 8, '#ff5c9a');
            for (const [m, need] of [[0.5, 1], [0.75, 1.5], [1, 2]]) {
              const sx = fx + fw * m - (m === 1 ? 6 : 0), on2 = game.score >= game.target * need;
              ctx.fillStyle = on2 ? '#ffd23f' : '#cfc6e6'; ctx.beginPath();
              for (let k = 0; k < 10; k++) { const a = k * Math.PI / 5 - Math.PI / 2, rr = k % 2 ? 3.5 : 8; ctx.lineTo(sx + Math.cos(a) * rr, 72 + Math.sin(a) * rr); }
              ctx.closePath(); ctx.fill();
            }
            ctx.fillStyle = 'rgba(25,30,80,.32)'; ctx.beginPath(); ctx.roundRect(BX - 4, BY - 4, CS * N + 8, CS * N + 8, 12); ctx.fill();
            for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) if ((r + c) % 2) fill(BX + c * CS, BY + r * CS, CS, CS, 'rgba(255,255,255,.07)');
            if (sel && game.phase === 'idle') { ctx.fillStyle = 'rgba(255,255,255,.35)'; ctx.beginPath(); ctx.roundRect(BX + sel[1] * CS + 2, BY + sel[0] * CS + 2, CS - 4, CS - 4, 8); ctx.fill(); }
            const hint = game.phase === 'idle' && !game.ended && now - idleAt > 5000 ? game.hint() : null;
            ctx.save(); ctx.beginPath(); ctx.rect(BX - 4, BY - 4, CS * N + 8, CS * N + 8); ctx.clip();
            game.grid.forEach((row, r) => row.forEach((q, c) => {
              if (!q) return;
              const d = disp.get(q.id) || cellXY(r, c); let x = d.x, y = d.y, sc = 1;
              if (bad) {
                const p = Math.sin(Math.min(1, (now - bad.t0) / 320) * Math.PI) * 0.45 * CS;
                for (const [m, o] of [[bad.a, bad.b], [bad.b, bad.a]]) if (m[0] === r && m[1] === c) { x += (o[1] - m[1]) * p; y += (o[0] - m[0]) * p; }
              }
              if (hint && hint.some(([hr, hc]) => hr === r && hc === c)) sc = 1 + 0.08 * Math.sin(now / 120);
              if (sel && sel[0] === r && sel[1] === c && game.phase === 'idle') sc = 1.08;
              candyAt(x, y, q, sc);
            }));
            ctx.restore();
            for (const g2 of ghosts) {
              const p = 1 - g2.t / g2.T;
              candyAt(g2.x, g2.y, g2, 1 + p * 0.5, 1 - p);
              const col = g2.kind === 'b' ? '#ffffff' : COLORS[g2.color][0];
              for (let k = 0; k < 5; k++) { const a = k * 1.26 + g2.id, d = 8 + p * 26; disc(g2.x + Math.cos(a) * d, g2.y + Math.sin(a) * d, 3 * (1 - p), col); }
              if (g2.kind === 'h' || g2.kind === 'v') { ctx.globalAlpha = 1 - p; if (g2.kind === 'h') fill(BX, g2.y - 4, CS * N, 8, 'rgba(255,255,255,.8)'); else fill(g2.x - 4, BY, 8, CS * N, 'rgba(255,255,255,.8)'); ctx.globalAlpha = 1; }
            }
            if (banner) {
              const p = 1 - banner.t / banner.T, s2 = Math.min(1, p * 5);
              ctx.save(); ctx.globalAlpha = Math.min(1, banner.t * 3); ctx.translate(W / 2, BY + CS * 4); ctx.scale(0.6 + 0.4 * s2, 0.6 + 0.4 * s2);
              ctx.font = font(34); ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.lineJoin = 'round';
              ctx.lineWidth = 7; ctx.strokeStyle = '#7a1f5c'; ctx.strokeText(banner.text, 0, 0); ctx.fillStyle = '#ffe14d'; ctx.fillText(banner.text, 0, 0);
              ctx.restore();
            }
            if (game.ended) {
              fill(0, 0, W, H, 'rgba(20,20,60,.6)');
              if (game.won) {
                label('레벨 ' + game.level + ' 클리어!', W / 2, 170, 28, '#ffe14d');
                for (let k = 0; k < 3; k++) {
                  const sx = W / 2 + (k - 1) * 46, on2 = k < game.stars();
                  ctx.fillStyle = on2 ? '#ffd23f' : 'rgba(255,255,255,.25)'; ctx.beginPath();
                  for (let j = 0; j < 10; j++) { const a = j * Math.PI / 5 - Math.PI / 2, rr = j % 2 ? 8 : 19; ctx.lineTo(sx + Math.cos(a) * rr, 225 + Math.sin(a) * rr); }
                  ctx.closePath(); ctx.fill();
                }
                label(game.score.toLocaleString() + '점', W / 2, 272, 20, '#ffffff');
                label('탭해서 다음 레벨', W / 2, 316, 15, '#ffffff', 'center', font(15, 'normal'));
              } else {
                label('이동이 끝났어요', W / 2, 190, 26, '#ffffff');
                label('목표까지 ' + (game.target - game.score).toLocaleString() + '점', W / 2, 232, 16, '#ffd1e6', 'center', font(16, 'normal'));
                label('탭해서 다시 하기', W / 2, 280, 15, '#ffffff', 'center', font(15, 'normal'));
              }
            }
          };
          paintExtra = () => {
            const b0 = best(); chips([['레벨 ' + game.level], ['⭐ ' + game.score.toLocaleString()], b0 != null && ['🏆 레벨 ' + b0]]);
            info.textContent = game.ended ? (game.won ? '화면을 누르면 다음 레벨' : '화면을 누르면 이 레벨을 다시 해요')
              : '사탕을 밀거나 이웃한 두 개를 눌러 바꾸세요 · 4개는 줄무늬, ㄱ·T자는 포장, 5개는 초코볼';
          };
        } else if (kind === 'knife') {
          // Knife Hit: a wooden log turns at the top; knives wait at the bottom; every fifth log is a boss (a wheel of cheese).
          const CX = 180, CY = 200, R = 72;
          let lastHit = -9, lastApple = -9, lastBroke = -9, lastStage = game.stage, failSeen = false;
          const fire = () => { if (game.throwKnife()) { begin(); sfx.play('move'); } focus(); };
          on(canvas, 'pointerdown', e => { e.preventDefault(); fire(); });
          keyDown = (k, repeat) => { if ([' ', 'enter', 'arrowup', 'w'].includes(k) && !repeat) fire(); };
          onStep = dt => {
            game.step(dt);
            if (game.hitAt !== lastHit) { lastHit = game.hitAt; sfx.play('hit', 1); navigator.vibrate?.(8); }
            if (game.appleAt !== lastApple) { lastApple = game.appleAt; sfx.play('coin'); }
            if (game.brokeAt !== lastBroke) { lastBroke = game.brokeAt; sfx.play('clear', 2); }
            if (game.stage !== lastStage) { lastStage = game.stage; if (game.boss) sfx.play('level'); }
            if (game.ended && !failSeen) { failSeen = true; sfx.play('lose'); navigator.vibrate?.(60); finish(false, game.score); }
          };
          sign = () => [game.score, game.apples, game.stage, game.remaining, game.ended, game.ended && game.time - game.fail.t > 0.9].join('/');
          const knifeAt = (x, y, rot) => {
            ctx.save(); ctx.translate(x, y); ctx.rotate(rot);
            ctx.fillStyle = '#e4e9ee'; ctx.beginPath(); ctx.moveTo(0, -36); ctx.lineTo(5.5, -23); ctx.lineTo(5.5, 0); ctx.lineTo(-5.5, 0); ctx.lineTo(-5.5, -25); ctx.closePath(); ctx.fill();
            ctx.fillStyle = '#b4bec8'; ctx.beginPath(); ctx.moveTo(0, -36); ctx.lineTo(5.5, -23); ctx.lineTo(5.5, 0); ctx.lineTo(0, 0); ctx.closePath(); ctx.fill();
            fill(-8, 0, 16, 4, '#4a505c');
            ctx.fillStyle = '#25282f'; ctx.beginPath(); ctx.roundRect(-4.5, 4, 9, 26, 3); ctx.fill();
            fill(-4.5, 11, 9, 1.5, '#3c414c'); fill(-4.5, 17, 9, 1.5, '#3c414c'); fill(-4.5, 23, 9, 1.5, '#3c414c');
            ctx.restore();
          };
          const apple = (x, y) => { disc(x, y, 9, '#e8383d'); disc(x - 3, y - 3, 2.6, 'rgba(255,255,255,.55)'); fill(x - 0.8, y - 13, 1.8, 5, '#5b3a1e'); ctx.fillStyle = '#4caf50'; ctx.beginPath(); ctx.ellipse(x + 4, y - 11, 4, 2, -0.5, 0, Math.PI * 2); ctx.fill(); };
          const wood = (boss) => {
            if (boss) {
              disc(0, 0, R, '#e2a92a'); disc(0, 0, R - 6, '#f7cd4a');
              for (const [a, d, r] of [[0.3, 30, 9], [1.9, 44, 7], [2.8, 22, 6], [4.0, 46, 10], [5.2, 28, 7], [3.4, 56, 5], [0.9, 58, 5]]) disc(Math.cos(a) * d, Math.sin(a) * d, r, '#e0ad2c');
              return;
            }
            disc(0, 0, R, '#7a4b22'); disc(0, 0, R - 7, '#d49b5d');
            ctx.strokeStyle = '#b97a40'; ctx.lineWidth = 2;
            for (const r of [R - 20, R - 33, R - 46, R - 58]) { ctx.beginPath(); ctx.arc(0, 0, r, 0, Math.PI * 2); ctx.stroke(); }
            ctx.strokeStyle = '#a5672f'; ctx.lineWidth = 1.5;
            for (const a of [0.4, 2.1, 3.6, 5.0]) { ctx.beginPath(); ctx.moveTo(Math.cos(a) * 6, Math.sin(a) * 6); ctx.lineTo(Math.cos(a + 0.12) * (R - 14), Math.sin(a + 0.12) * (R - 14)); ctx.stroke(); }
            disc(0, 0, 5, '#9a6232');
            for (let k = 0; k < 14; k++) { const a = k * Math.PI / 7; disc(Math.cos(a) * (R - 3), Math.sin(a) * (R - 3), 2, '#5e3615'); }
          };
          drawGame = () => {
            const grad = ctx.createRadialGradient(CX, 230, 40, CX, 260, 380); grad.addColorStop(0, '#3a3f52'); grad.addColorStop(1, '#1b1d26');
            ctx.fillStyle = grad; ctx.fillRect(0, 0, W, H);
            ctx.save();
            if (game.ended && game.time - game.fail.t < 0.35) { const k = (0.35 - (game.time - game.fail.t)) * 22; ctx.translate(Math.sin(game.time * 90) * k, Math.cos(game.time * 70) * k * 0.5); }
            label(String(game.score), 22, 38, 32, '#ffffff', 'left');
            apple(W - 28, 38); label(String(game.apples), W - 46, 39, 20, '#ffffff', 'right');
            const idx = (game.stage - 1) % 5;
            for (let k = 0; k < 5; k++) {
              const x = CX + (k - 2) * 24, boss = k === 4;
              disc(x, 30, boss ? 8 : 6, k < idx ? '#f4c542' : boss ? (k === idx ? '#ff5252' : '#5d2f36') : k === idx ? '#ffffff' : '#4b5063');
            }
            label(game.boss ? '보스 스테이지' : '스테이지 ' + game.stage, CX, 54, 14, game.boss ? '#ff6b6b' : '#c9cfdc');
            const bump = game.time - game.hitAt < 0.07 ? -6 : 0;
            if (game.wait > 0) {
              const t = game.time - game.brokeAt;
              ctx.globalAlpha = Math.max(0, 1 - t / 1.0);
              for (let k = 0; k < 4; k++) {
                const a = game.angle + k * Math.PI / 2 + Math.PI / 4, off = 170 * t, fall = 420 * t * t;
                ctx.save(); ctx.translate(CX + Math.cos(a) * off, CY + Math.sin(a) * off + fall); ctx.rotate(game.angle + t * (k % 2 ? 3 : -3));
                ctx.beginPath(); ctx.moveTo(0, 0); ctx.arc(0, 0, R, k * Math.PI / 2, (k + 1) * Math.PI / 2); ctx.closePath(); ctx.clip(); wood(game.boss); ctx.restore();
              }
              game.knives.forEach((a, k) => { const w = a + game.angle, off = R + 18 + 260 * t; knifeAt(CX + Math.cos(w) * off, CY + Math.sin(w) * off + 300 * t * t, w - Math.PI / 2 + t * (k % 2 ? 6 : -6)); });
              ctx.globalAlpha = 1;
              if (t < 0.12) fill(0, 0, W, H, 'rgba(255,255,255,' + (0.35 * (1 - t / 0.12)) + ')');
            } else {
              ctx.save(); ctx.translate(CX, CY + bump); ctx.rotate(game.angle);
              for (const a of game.knives) { ctx.save(); ctx.rotate(a); ctx.translate(R + 18, 0); knifeAt(0, 0, -Math.PI / 2); ctx.restore(); }
              wood(game.boss);
              if (game.time - game.hitAt < 0.06) disc(0, 0, R, 'rgba(255,255,255,.35)');
              for (const a of game.fruit) apple(Math.cos(a) * (R + 9), Math.sin(a) * (R + 9));
              ctx.restore();
              if (game.boss && game.stageTime < 1.4 && !game.ended) label('보스 등장!', CX, 330, 28, '#ff5252');
            }
            if (!game.ended && game.wait <= 0) {
              const p = game.flight == null ? 0 : Math.min(1, game.flight / 0.09);
              knifeAt(CX, lerp(452, CY + R + 18, p), 0);
            }
            if (game.ended) {
              const t = game.time - game.fail.t;
              knifeAt(CX + game.fail.side * 150 * t, CY + R + 18 - 240 * t + 1150 * t * t, game.fail.side * 10 * t);
            }
            for (let i = 0; i < game.total; i++) {
              const y = 500 - i * 19, live = i < game.remaining - (game.flight != null || game.ended || game.wait > 0 ? 0 : 1);
              ctx.fillStyle = live ? '#ffffff' : '#4b5063';
              ctx.beginPath(); ctx.moveTo(22, y - 13); ctx.lineTo(26, y - 7); ctx.lineTo(26, y); ctx.lineTo(18, y); ctx.lineTo(18, y - 7); ctx.closePath(); ctx.fill();
              fill(19.5, y + 1, 5, 6, live ? '#ffffff' : '#4b5063');
            }
            if (!game.started) label('탭해서 칼을 던지세요', CX, 380, 16, '#c9cfdc');
            ctx.restore();
          };
        } else {
          // Count Masters: blue stickmen run a road over the sea; blue gates add, red ones take; then the bonus stairs.
          const HZ = 150, CAMH = 9, F = 300, BACK = 11;
          const P = (zr, wx, elev = 0) => { const d = Math.max(0.6, zr + BACK), s = F / d; return { x: 180 + wx * s, y: HZ + (CAMH - elev) * s, s }; };
          const SPOTS = Array.from({ length: 160 }, (_, i) => ({ i, ...game.man(i) })).sort((a, b) => b.dz - a.dz);
          let anchor = null, lastCount = game.count, hitT = 0, lastSteps = 0, endSeen = false;
          on(canvas, 'pointerdown', e => { e.preventDefault(); canvas.setPointerCapture?.(e.pointerId); anchor = { id: e.pointerId, x: e.clientX, t: game.target, w: canvas.getBoundingClientRect().width }; game.start(); begin(); focus(); });
          on(canvas, 'pointermove', e => { if (anchor && anchor.id === e.pointerId) game.aim(anchor.t + (e.clientX - anchor.x) / anchor.w * 2.6); });
          for (const ev of ['pointerup', 'pointercancel', 'lostpointercapture']) on(canvas, ev, () => { anchor = null; });
          const held = new Set();
          const steer = () => game.move((held.has('arrowright') || held.has('d') ? 1 : 0) - (held.has('arrowleft') || held.has('a') ? 1 : 0));
          keyDown = k => { held.add(k); game.start(); begin(); steer(); };
          keyUp = k => { held.delete(k); steer(); };
          release = () => { held.clear(); game.move(0); anchor = null; };
          onStep = dt => {
            game.step(dt); hitT -= dt / 1000;
            if (game.count > lastCount) sfx.play('pop', 2);
            else if (game.count < lastCount) { if (game.phase === 'fight') { if (hitT <= 0) { sfx.play('hit', 1); hitT = 0.12; } } else if (game.phase !== 'stairs') { sfx.play('hurt'); navigator.vibrate?.(20); } }
            if (game.steps > lastSteps) { lastSteps = game.steps; sfx.play('tap'); }
            lastCount = game.count;
            if (game.ended && !endSeen) { endSeen = true; sfx.play(game.won ? 'win' : 'lose'); finish(false, game.score); }
          };
          sign = () => [game.count, game.ended, game.started, game.phase].join('/');
          const man = (x, y, s, color, phase) => {
            const sw = Math.sin(phase) * 0.12 * s;
            ctx.fillStyle = 'rgba(0,0,0,.12)'; ctx.beginPath(); ctx.ellipse(x, y, 0.2 * s, 0.06 * s, 0, 0, Math.PI * 2); ctx.fill();
            ctx.strokeStyle = color; ctx.lineCap = 'round'; ctx.lineWidth = Math.max(1, 0.1 * s);
            ctx.beginPath(); ctx.moveTo(x, y - 0.28 * s); ctx.lineTo(x - sw, y); ctx.moveTo(x, y - 0.28 * s); ctx.lineTo(x + sw, y); ctx.stroke();
            ctx.fillStyle = color; ctx.beginPath(); ctx.roundRect(x - 0.11 * s, y - 0.56 * s, 0.22 * s, 0.32 * s, 0.08 * s); ctx.fill();
            disc(x, y - 0.66 * s, 0.12 * s, color);
          };
          const crowd = (n, wx0, zr0, elev, color, spread = 1) => {
            for (const m of SPOTS) {
              if (m.i >= n) continue;
              const p = P(zr0 + m.dz * spread, (wx0 + m.dx * 5 * spread), elev);
              if (p.y > H + 20) continue;
              man(p.x, p.y, p.s, color, game.time * 14 + m.i);
            }
          };
          const pill = (text, x, y, size, bg, fg) => {
            ctx.font = font(size); const w = ctx.measureText(text).width + size;
            ctx.fillStyle = bg; ctx.beginPath(); ctx.roundRect(x - w / 2, y - size * 0.8, w, size * 1.6, size * 0.8); ctx.fill(); label(text, x, y + 1, size, fg);
          };
          const quad = (a, b, c, d, color) => { ctx.fillStyle = color; ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.lineTo(c.x, c.y); ctx.lineTo(d.x, d.y); ctx.closePath(); ctx.fill(); };
          drawGame = () => {
            const stairs = game.phase === 'stairs' || game.ended && game.won;
            const camZ = stairs ? game.length + game.steps * 2 : game.z, elev = stairs ? game.steps * 0.5 : 0;
            const sky = ctx.createLinearGradient(0, 0, 0, HZ); sky.addColorStop(0, '#5db7f5'); sky.addColorStop(1, '#cdeeff');
            ctx.fillStyle = sky; ctx.fillRect(0, 0, W, HZ); fill(0, HZ, W, H - HZ, '#4fb0e6');
            for (let i = 0; i < 6; i++) fill(((i * 97 - game.time * 6) % W + W) % W, HZ + 12 + i * 22, 40 + i * 6, 2, 'rgba(255,255,255,.35)');
            const roadEnd = game.length - camZ, far = Math.min(200, roadEnd);
            // Rails and road, then stripes across it.
            if (far > -10) {
              const z0 = -BACK + 1.2;
              quad(P(far, -5.5, -elev), P(far, 5.5, -elev), P(z0, 5.5, -elev), P(z0, -5.5, -elev), '#aab4c8');
              quad(P(far, -5, -elev), P(far, 5, -elev), P(z0, 5, -elev), P(z0, -5, -elev), '#eef1f7');
              for (let z = Math.ceil((camZ - 10) / 6) * 6; z < camZ + far; z += 6) { if (Math.round(z / 6) % 2) continue; const a = z - camZ, b = Math.min(far, a + 3); if (b < z0) continue; quad(P(b, -5, -elev), P(b, 5, -elev), P(Math.max(z0, a), 5, -elev), P(Math.max(z0, a), -5, -elev), '#e1e6f0'); }
              // Finish line: a checker band.
              const fz = roadEnd;
              if (fz > z0 && fz < 200) for (let c = 0; c < 10; c++) for (let r = 0; r < 2; r++) quad(P(fz + r * 0.5 + 0.5, -5 + c, -elev), P(fz + r * 0.5 + 0.5, -4 + c, -elev), P(fz + r * 0.5, -4 + c, -elev), P(fz + r * 0.5, -5 + c, -elev), (c + r) % 2 ? '#222' : '#fff');
            }
            // The bonus stairs, far ones first.
            for (let k = game.maxSteps; k >= 1; k--) {
              const zr = game.length + (k - 1) * 2 - camZ, top = k * 0.5 - elev;
              if (zr > 200 || zr + 2 < -BACK + 1.2) continue;
              const hue = (k * 23) % 360, near = Math.max(-BACK + 1.2, zr);
              quad(P(zr + 2, -5, top), P(zr + 2, 5, top), P(near, 5, top), P(near, -5, top), 'hsl(' + hue + ',70%,72%)');
              if (zr > -BACK + 1.2) {
                quad(P(zr, -5, top), P(zr, 5, top), P(zr, 5, top - 0.5), P(zr, -5, top - 0.5), 'hsl(' + hue + ',62%,58%)');
                const c = P(zr, 0, top - 0.25); if (c.s > 7) label('×' + (1 + k * 0.1).toFixed(1), c.x, c.y, Math.min(22, c.s * 0.45), '#ffffff');
              }
            }
            const evs = game.events.filter(e => (!e.done || e === game.fight) && e.z - camZ < 170 && e.z - camZ > -3).sort((a, b) => b.z - a.z);
            for (const e of evs) {
              const zr = e.z - camZ;
              if (e.type === 'gate') {
                e.gates.forEach((gt, i) => {
                  const good = gt.op === '+' || gt.op === '*', x0 = i ? 0.15 : -5, x1 = i ? 5 : -0.15;
                  const bl = P(zr, x0), br = P(zr, x1), tl = P(zr, x0, 3.2);
                  ctx.globalAlpha = 0.6; fill(bl.x, tl.y, br.x - bl.x, bl.y - tl.y, good ? '#2f80ed' : '#eb5757'); ctx.globalAlpha = 1;
                  fill(bl.x, tl.y, br.x - bl.x, Math.max(2, 0.15 * bl.s), '#ffffff');
                  fill(bl.x, tl.y, Math.max(2, 0.15 * bl.s), bl.y - tl.y, '#ffffff'); fill(br.x - Math.max(2, 0.15 * bl.s), tl.y, Math.max(2, 0.15 * bl.s), bl.y - tl.y, '#ffffff');
                  label((gt.op === '*' ? '×' : gt.op === '/' ? '÷' : gt.op === '-' ? '−' : '+') + gt.v, (bl.x + br.x) / 2, (bl.y + tl.y) / 2, Math.max(8, 1.15 * bl.s), '#ffffff');
                });
              } else if (e.type === 'block') {
                const x0 = e.from * 5, x1 = e.to * 5;
                quad(P(zr + 0.8, x0, 1.6), P(zr + 0.8, x1, 1.6), P(zr, x1, 1.6), P(zr, x0, 1.6), '#c8cfdd');
                const a = P(zr, x0), b = P(zr, x1, 1.6); fill(a.x, b.y, b.x - a.x, a.y - b.y, '#8d97ab');
                for (let k = 0; k < 6; k++) { const s0 = P(zr, x0 + (x1 - x0) * k / 6), s1 = P(zr, x0 + (x1 - x0) * (k + 0.5) / 6, 1.6); if (k % 2 === 0) fill(s0.x, s1.y + (a.y - b.y) * 0.35, s1.x - s0.x, (a.y - b.y) * 0.3, '#f2c94c'); }
              } else if (e.type === 'saw') {
                const wx = game.sawAt(e) * 5, c = P(zr, wx, 1.2), r = 1.25 * c.s;
                const sl = P(zr, -5), sr = P(zr, 5); fill(sl.x, sl.y - 2, sr.x - sl.x, Math.max(2, 0.12 * sl.s), '#7b8394');
                ctx.save(); ctx.translate(c.x, c.y); ctx.rotate(game.time * 9);
                ctx.fillStyle = '#9aa1ad'; ctx.beginPath();
                for (let k = 0; k < 24; k++) { const a = k * Math.PI / 12, rr = k % 2 ? r : r * 0.82; ctx.lineTo(Math.cos(a) * rr, Math.sin(a) * rr); }
                ctx.closePath(); ctx.fill(); disc(0, 0, r * 0.7, '#c9ced8'); disc(0, 0, r * 0.18, '#5d6472'); ctx.restore();
              } else if (e.type === 'enemy') {
                const n = Math.min(160, e.left), z = e === game.fight ? Math.max(1.6, zr) : zr;
                crowd(n, 0, z + 0.6, 0, '#e53935', 1);
                const top = P(z, 0, 2.2); pill(String(e.left), top.x, top.y, Math.max(10, Math.min(16, top.s * 0.6)), '#e53935', '#ffffff');
              }
            }
            crowd(game.shown(), game.x * 5, 0, 0, '#2f80ed');
            const head = P(0, game.x * 5, 2.1);
            if (game.count) pill(String(game.count), head.x, head.y, 15, '#ffffff', '#2f80ed');
            if (game.noteTime > 0) label(game.note, head.x, head.y - 34 - (1 - game.noteTime) * 26, 24, game.noteGood ? '#ffffff' : '#ffd1d1', 'center');
            fill(60, 16, 240, 8, 'rgba(255,255,255,.55)'); fill(60, 16, 240 * Math.min(1, game.z / game.length), 8, '#2f80ed');
            if (stairs) label('×' + game.mult.toFixed(1), W / 2, 50, 24, '#ffffff');
            if (!game.started) {
              fill(0, H - 150, W, 90, 'rgba(15,35,70,.55)');
              label('화면을 좌우로 끌어서 시작', W / 2, H - 118, 18, '#ffffff');
              label('파란 문은 늘고 빨간 문은 줄어요', W / 2, H - 88, 13, '#dbe9ff', 'center', font(13, 'normal'));
            }
          };
        }

        const draw = () => {
          const size = Math.max(1, canvas.getBoundingClientRect().width), scale = Math.min(2, window.devicePixelRatio || 1) * size / W;
          const width = Math.round(W * scale), height = Math.round(H * scale);
          if (canvas.width !== width || canvas.height !== height) { canvas.width = width; canvas.height = height; }
          ctx.setTransform(width / W, 0, 0, height / H, 0, 0);
          ctx.lineCap = 'butt'; ctx.lineJoin = 'miter'; ctx.globalAlpha = 1;
          drawGame();
        };
        paint = () => {
          if (kind === 'water' || kind === 'candy') return paintExtra();
          const b0 = best();
          if (kind === 'dino') { chips([b0 != null && ['🏆 ' + b0.toLocaleString()]]); info.textContent = '탭·스페이스로 점프(길게 누르면 높이) · ↓나 숙이기로 새를 피해요'; }
          else if (kind === 'knife') {
            chips([['⭐ ' + game.score], ['🍎 ' + game.apples], b0 != null && ['🏆 ' + b0]]);
            info.textContent = '탭·스페이스로 칼 던지기 · 꽂힌 칼에 닿으면 끝 · 사과를 맞혀 보세요';
            if (game.ended && game.time - game.fail.t > 0.9) showResult('칼이 튕겨 나갔어요', '점수 ' + game.score + ' · 스테이지 ' + game.stage + ' · 사과 ' + game.apples);
          } else {
            chips([['👥 ' + game.count], b0 != null && ['🏆 ' + b0.toLocaleString()]]);
            info.textContent = '좌우로 끌거나 ←→로 이동 · 파란 문으로 인원을 늘리고 장애물과 적 무리를 넘어 계단으로';
            if (game.ended) showResult(game.won ? '×' + game.mult.toFixed(1) + ' 계단까지!' : '인원이 모두 사라졌어요', game.won ? '도착 ' + game.finishCount + '명 × ' + game.mult.toFixed(1) + ' = ' + game.score.toLocaleString() + '점' : '다른 문을 골라 보세요');
          }
        };
        let last = 0, gone = 0, signature = '';
        const loop = t => {
          frame = 0;
          if (life.signal.aborted || panelStopped || !content.contains(board)) return;
          if (!board.isConnected || document.hidden) {
            last = 0; release();
            if (!board.isConnected) { gone ||= t; if (t - gone > 60000) return; }
            frame = requestAnimationFrame(loop); return;
          }
          gone = 0;
          const dt = last ? Math.min(50, t - last) : 0; last = t;
          onStep(dt); draw();
          const next = sign();
          if (next !== signature) { signature = next; paint(); }
          frame = requestAnimationFrame(loop);
        };
        frame = requestAnimationFrame(loop);
      }
      paintNow = (clockOnly) => { if (!content.contains(board)) return; paint(clockOnly); };
      paint();
      // Games played with the keyboard take focus, so arrow and number keys work straight away.
      if (['merge', 'snake', 'shop', 'pinball', 'bricks', 'drop', 'dino', 'water', 'candy', 'knife', 'count'].includes(mode)) board.focus({ preventScroll: true });
    }
    return panel;
  }


  const CSS = "/* Buttons: the 말랑 capsule that presses down. */\n.gfx-load-games button { font:inherit; color:var(--gfx-text, #5A3A24); background:var(--gfx-card, #FFFDF5); border:2.5px solid var(--gfx-line, #6B4528); border-radius:999px; padding:.42em .95em; cursor:pointer;\n  box-shadow:0 3px 0 var(--gfx-line, #6B4528); transition:translate .1s ease, box-shadow .1s ease, background .15s ease; }\n.gfx-load-games button:not(.gfx-game-board > *, .gfx-shop-oven):hover:not(:disabled) { background:color-mix(in srgb,var(--gfx-pick, #FFE17A) 45%,var(--gfx-card, #FFFDF5)); }\n.gfx-load-games button:active:not(:disabled) { translate:0 2px; box-shadow:0 1px 0 var(--gfx-line, #6B4528); }\n.gfx-load-games button:disabled { cursor:default; }\n.gfx-load-games button[aria-pressed=\"true\"] { background:var(--gfx-pick, #FFE17A); }\n.gfx-load-games button:focus-visible, .gfx-game-board:focus-visible { outline:3px solid var(--gfx-accent, #F0763A); outline-offset:2px; }\n/* The game shelf: one card per game. */\n.gfx-game-nav { display:flex; flex-wrap:wrap; justify-content:center; align-items:center; gap:8px; margin-bottom:10px; padding:8px; border:3px solid var(--gfx-line, #6B4528); border-radius:22px;\n  background:color-mix(in srgb,var(--gfx-card, #FFFDF5) 94%,transparent); box-shadow:0 4px 0 var(--gfx-line, #6B4528); }\n.gfx-game-tab { display:flex; flex-direction:column; align-items:center; gap:1px; border-radius:16px !important; padding:.4em .75em !important; min-width:5.4em; }\n.gfx-game-tab i { font-style:normal; font-size:1.7em; line-height:1.15; }\n.gfx-game-tab span { font-size:.9em; white-space:nowrap; }\n.gfx-game-tab[aria-pressed=\"true\"] { background:var(--gfx-accent, #F0763A) !important; color:#fff !important; }\n.gfx-game-utils { display:flex; flex-wrap:wrap; justify-content:center; gap:6px; }\n.gfx-game-util { font-size:.82em !important; padding:.35em .8em !important; box-shadow:0 2px 0 var(--gfx-line, #6B4528) !important; }\n/* The game card. */\n.gfx-game-content:empty { display:none; }\n.gfx-game-content { background:var(--gfx-card, #FFFDF5); border:3px solid var(--gfx-line, #6B4528); border-radius:22px; padding:12px 14px 14px; box-shadow:0 5px 0 var(--gfx-line, #6B4528); }\n.gfx-game-head { display:flex; align-items:center; justify-content:space-between; gap:6px 10px; flex-wrap:wrap; margin-bottom:6px; }\n.gfx-game-title { display:flex; align-items:center; gap:.3em; font-size:1.12em; font-weight:normal; white-space:nowrap; }\n.gfx-game-title i { font-style:normal; }\n.gfx-game-stats { display:flex; gap:6px; flex-wrap:wrap; justify-content:flex-end; }\n.gfx-game-stats { font-size:.86em; }\n.gfx-game-stats span { padding:.1em .6em; border-radius:999px; background:var(--gfx-ink, #FFF4D9); border:2px solid color-mix(in srgb,var(--gfx-line, #6B4528) 35%,transparent); font-variant-numeric:tabular-nums; white-space:nowrap; }\n.gfx-game-stats span[data-alert] { background:#FFD9D4; color:#A1281C; border-color:#E0786B; animation:gfx-game-blink .8s ease-in-out infinite; }\n@keyframes gfx-game-blink { 50% { opacity:.55; } }\n/* Level, new game and the game tool: one small row inside the header. */\n.gfx-game-tools { flex:1 1 auto; display:flex; flex-wrap:wrap; align-items:center; justify-content:center; gap:5px; font-size:.82em; }\n.gfx-game-tools > button { padding:.2em .75em; border-width:2px; box-shadow:0 2px 0 var(--gfx-line, #6B4528); }\n.gfx-game-levels { display:inline-flex; gap:2px; padding:2px; border:2px solid var(--gfx-line, #6B4528); border-radius:999px; background:var(--gfx-ink, #FFF4D9); }\n.gfx-game-levels button { line-height:1.2; padding:.16em .7em; border:0; background:transparent; box-shadow:none; }\n.gfx-game-levels button:active:not(:disabled) { translate:none; box-shadow:none; }\n.gfx-game-levels button[aria-checked=\"true\"] { background:var(--gfx-accent, #F0763A); color:#fff; }\n.gfx-game-new { background:var(--gfx-pick, #FFE17A) !important; }\n.gfx-game-flag[aria-pressed=\"true\"] { background:#FFD9D4 !important; }\n.gfx-game-info { min-height:1.5em; text-align:center; margin-bottom:8px; font-size:.95em; }\n.gfx-game-info b { font-weight:normal; padding:0 .4em; border-radius:999px; background:var(--gfx-ink, #FFF4D9); }\n.gfx-game-info b[data-ok] { background:#C9F0D6; color:#1C7A43; }\n.gfx-game-info b[data-over] { background:#FFD9D4; color:#A1281C; }\n/* The board: square cells sized from the board's own width. */\n.gfx-game-stage { position:relative; }\n.gfx-game-board { display:grid; grid-template-columns:repeat(var(--cols),minmax(0,1fr)); gap:4px; width:min(100%, max(170px, var(--room) * var(--fit, 1))); margin:auto; padding:6px; box-sizing:border-box;\n  border-radius:16px; background:color-mix(in srgb,var(--gfx-line, #6B4528) 16%,var(--gfx-ink, #FFF4D9)); touch-action:none; user-select:none; -webkit-user-select:none; container-type:inline-size; }\n.gfx-game-board > * { position:relative; aspect-ratio:1; min-width:0; min-height:0; padding:0 !important; display:grid; place-items:center; border-radius:9px !important; box-sizing:border-box;\n  font-size:calc(100cqw / var(--cols) * .46); line-height:1; }\n/* 지뢰찾기 */\n.gfx-game-board[data-kind=\"mines\"] > button { background:var(--gfx-pick, #FFE17A); border-width:2px; box-shadow:0 2px 0 var(--gfx-line, #6B4528); }\n.gfx-game-board[data-kind=\"mines\"] > button[data-open=\"true\"] { background:var(--gfx-card, #FFFDF5); border-color:color-mix(in srgb,var(--gfx-line, #6B4528) 25%,transparent); box-shadow:none; translate:none; }\n.gfx-game-board > button[data-mine=\"true\"]::before { content:\"\"; width:52%; aspect-ratio:1; border-radius:50%; background:#262626;\n  box-shadow:0 0 0 .12em #1f1f1f, 0 -.28em 0 -.16em #1f1f1f, 0 .28em 0 -.16em #1f1f1f, .28em 0 0 -.16em #1f1f1f, -.28em 0 0 -.16em #1f1f1f; }\n.gfx-game-board > button[data-boom=\"true\"] { background:#FF6B5E !important; animation:gfx-game-shake .35s ease; }\n.gfx-game-board > button[data-wrong=\"true\"] { opacity:.45; }\n@keyframes gfx-game-shake { 25% { translate:-3px 0; } 75% { translate:3px 0; } }\n.gfx-game-board button[data-flag=\"true\"] { font-size:0 !important; background:var(--gfx-card, #FFFDF5); }\n.gfx-game-board button[data-flag=\"true\"]::before { content:\"\"; position:absolute; left:34%; top:18%; height:62%; border-left:3px solid #432e23; }\n.gfx-game-board button[data-flag=\"true\"]::after { content:\"\"; position:absolute; left:calc(34% + 3px); top:18%; width:42%; height:36%; background:#e13f35; clip-path:polygon(0 0,100% 25%,0 100%); }\n/* 사과 상자 */\n.gfx-game-board[data-kind=\"fruits\"] { gap:2px; position:relative; }\n.gfx-game-board > .gfx-fruit-frame { position:absolute; z-index:2; aspect-ratio:auto; display:block; pointer-events:none; box-sizing:border-box; border-radius:14px !important;\n  border:4px solid var(--gfx-accent, #F0763A); background:color-mix(in srgb,var(--gfx-accent, #F0763A) 22%,transparent); box-shadow:0 0 0 2px #fff, 0 0 14px color-mix(in srgb,var(--gfx-accent, #F0763A) 70%,transparent);\n  transition:left .06s linear, top .06s linear, width .06s linear, height .06s linear; }\n.gfx-game-board > .gfx-fruit-frame[hidden] { display:none; }\n\n.gfx-game-board > .gfx-fruit-frame[data-state=\"ok\"] { border-color:#2FA95E; background:color-mix(in srgb,#2FA95E 26%,transparent); box-shadow:0 0 0 2px #fff, 0 0 16px #2FA95EAA; }\n\n.gfx-game-board > .gfx-fruit-frame[data-state=\"over\"] { border-color:#E0483C; background:color-mix(in srgb,#E0483C 16%,transparent); box-shadow:0 0 0 2px #fff; }\n\n/* A sticker-outlined apple (stem, leaf, shine) drawn once as an SVG; the number sits on its belly. */\n.gfx-game-board[data-kind=\"fruits\"] > button, .gfx-game-board[data-kind=\"fruits\"] > button:active:not(:disabled) { background:transparent; border:0; box-shadow:none; translate:none; border-radius:28% !important; transition:background .12s ease; }\n.gfx-game-board[data-kind=\"fruits\"] > button::before { content:\"\"; position:absolute; inset:2%; background:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Cellipse cx='50' cy='93' rx='26' ry='4' fill='%236B4528' opacity='.18'/%3E%3Cpath d='M50 31C40 22 16 22 13 47 10 72 29 92 42 91c3-.3 5-1.4 8-1.4s5 1.1 8 1.4c13 1 32-19 29-44C84 22 60 22 50 31Z' fill='%23EF4B3F' stroke='%236B2318' stroke-width='3.5' stroke-linejoin='round'/%3E%3Cpath d='M27 40c-4 6-5 13-3 19' fill='none' stroke='%23fff' stroke-width='5' stroke-linecap='round' opacity='.55'/%3E%3Ccircle cx='31' cy='34' r='3' fill='%23fff' opacity='.6'/%3E%3Cpath d='M50 31c0-7 1-13 4-18' fill='none' stroke='%236B4528' stroke-width='4.5' stroke-linecap='round'/%3E%3Cpath d='M54 18c6-9 19-10 26-5-5 9-17 11-26 5Z' fill='%237ED36A' stroke='%233E7A33' stroke-width='3' stroke-linejoin='round'/%3E%3Cpath d='M57 17c6-2 12-3 18-3' fill='none' stroke='%233E7A33' stroke-width='1.8' stroke-linecap='round' opacity='.7'/%3E%3C/svg%3E\") center / contain no-repeat; transition:scale .14s cubic-bezier(.3,1.6,.5,1), filter .12s ease; }\n.gfx-game-board[data-kind=\"fruits\"] > button span { position:relative; z-index:1; margin-top:22%; color:#fff; font-size:calc(100cqw / var(--cols) * .36); letter-spacing:0;\n  -webkit-text-stroke:.16em #6B2318; paint-order:stroke fill; }\n.gfx-game-board[data-kind=\"fruits\"] > button[data-empty=\"true\"]::before { display:none; }\n.gfx-game-board[data-kind=\"fruits\"] > button[data-selected=\"true\"]::before { scale:1.1; filter:brightness(1.08); }\n.gfx-game-board[data-kind=\"fruits\"] > button[data-hint=\"true\"] { background:color-mix(in srgb,#FFD84D 55%,transparent); }\n.gfx-game-board[data-kind=\"fruits\"] > button[data-hint=\"true\"]::before { animation:gfx-game-hint .5s ease-in-out infinite alternate; }\n@keyframes gfx-game-hint { to { scale:1.12; } }\n/* 2048 */\n.gfx-game-board[data-kind=\"merge\"] { gap:6px; padding:8px; }\n.gfx-game-board[data-kind=\"merge\"] > div { background:color-mix(in srgb,var(--gfx-card, #FFFDF5) 60%,transparent); color:#5A3A24; font-size:calc(100cqw / var(--cols) * .36); }\n.gfx-game-board[data-kind=\"merge\"] > div[data-d=\"3\"] { font-size:calc(100cqw / var(--cols) * .3); } .gfx-game-board[data-kind=\"merge\"] > div[data-d=\"4\"] { font-size:calc(100cqw / var(--cols) * .24); }\n.gfx-game-board[data-kind=\"merge\"] > div[data-d=\"5\"] { font-size:calc(100cqw / var(--cols) * .2); }\n.gfx-game-board[data-kind=\"merge\"] > div:not([data-v=\"0\"]) { border:2px solid var(--gfx-line, #6B4528); box-shadow:0 3px 0 var(--gfx-line, #6B4528); }\n.gfx-game-board > div[data-v=\"2\"] { background:#FFF6DF; } .gfx-game-board > div[data-v=\"4\"] { background:#FFE7AE; } .gfx-game-board > div[data-v=\"8\"] { background:#FFC27A; color:#fff; }\n.gfx-game-board > div[data-v=\"16\"] { background:#FF9F68; color:#fff; } .gfx-game-board > div[data-v=\"32\"] { background:#FF7F6E; color:#fff; } .gfx-game-board > div[data-v=\"64\"] { background:#F25C5C; color:#fff; }\n.gfx-game-board > div[data-v=\"128\"] { background:#FFD84D; color:#fff; } .gfx-game-board > div[data-v=\"256\"] { background:#FFC933; color:#fff; } .gfx-game-board > div[data-v=\"512\"] { background:#FFB81C; color:#fff; }\n.gfx-game-board > div[data-v=\"1024\"] { background:#8FD16B; color:#fff; } .gfx-game-board > div[data-v=\"2048\"] { background:#4FC1A0; color:#fff; }\n.gfx-game-board[data-kind=\"merge\"] > div:not([data-v=\"0\"]):is([data-v^=\"4096\"],[data-v^=\"8192\"],[data-v^=\"16384\"],[data-v^=\"32768\"],[data-v^=\"65536\"]) { background:#8C6CF0; color:#fff; }\n.gfx-game-board[data-kind=\"merge\"] > div:is([data-v=\"8\"],[data-v=\"16\"],[data-v=\"32\"],[data-v=\"64\"],[data-v=\"128\"],[data-v=\"256\"],[data-v=\"512\"],[data-v=\"1024\"],[data-v=\"2048\"]) { text-shadow:0 .05em 0 #0003; }\n.gfx-game-board > div[data-new] { animation:gfx-tile-in .18s ease both; }\n.gfx-game-board > div[data-merged] { animation:gfx-tile-pop .2s ease both; }\n@keyframes gfx-tile-in { from { scale:.3; opacity:0; } }\n@keyframes gfx-tile-pop { 50% { scale:1.14; } }\n.gfx-game-pad { position:absolute; right:0; bottom:0; display:grid; grid-template-columns:repeat(3,2.4em); grid-template-areas:\". up .\" \"left down right\"; gap:4px; }\n.gfx-game-pad button { padding:.25em 0 !important; border-radius:12px !important; }\n.gfx-game-pad [data-dir=\"up\"] { grid-area:up; } .gfx-game-pad [data-dir=\"left\"] { grid-area:left; } .gfx-game-pad [data-dir=\"down\"] { grid-area:down; } .gfx-game-pad [data-dir=\"right\"] { grid-area:right; }\n@media (pointer:coarse) { .gfx-game-pad { display:none; } }\n/* 짝 맞추기 */\n.gfx-game-board[data-kind=\"memory\"] { gap:6px; }\n.gfx-game-board[data-kind=\"memory\"] > button { aspect-ratio:3 / 4; border-radius:12px !important; overflow:hidden; background:var(--gfx-card, #FFFDF5); border-width:2.5px; box-shadow:0 3px 0 var(--gfx-line, #6B4528); }\n.gfx-game-board[data-kind=\"memory\"] > button > span { position:absolute; inset:0; display:grid; place-items:center; transition:opacity .18s ease, scale .22s cubic-bezier(.3,1.5,.5,1); }\n.gfx-game-board[data-kind=\"memory\"] > button > .back { background:var(--gfx-accent, #F0763A); box-shadow:inset 0 0 0 .3em color-mix(in srgb,#fff 35%,var(--gfx-accent, #F0763A)); }\n.gfx-game-board[data-kind=\"memory\"] > button > .face { opacity:0; scale:.6; padding:6%; box-sizing:border-box; }\n.gfx-game-board[data-kind=\"memory\"] > button > .face img { width:100%; height:100%; object-fit:contain; object-position:50% 100%; }\n.gfx-game-board[data-kind=\"memory\"] > button > .face i { font-style:normal; font-size:calc(100cqw / var(--cols) * .5); }\n.gfx-game-board[data-kind=\"memory\"] > button[data-open=\"true\"] > .face { opacity:1; scale:1; }\n.gfx-game-board[data-kind=\"memory\"] > button[data-open=\"true\"] > .back { opacity:0; scale:.6; }\n.gfx-game-board[data-kind=\"memory\"] > button[data-done=\"true\"] { background:color-mix(in srgb,#C9F0D6 70%,var(--gfx-card, #FFFDF5)); border-color:#2FA95E; box-shadow:0 3px 0 #2FA95E; }\n/* Theme pieces: the box game's fruit and the minesweeper board follow the chosen 말랑 colour preset. */\n.gfx-load-games[data-theme=\"berry\"] .gfx-game-board[data-kind=\"fruits\"] > button::before { background-image:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Cellipse cx='50' cy='93' rx='26' ry='4' fill='%233A2A20' opacity='.18'/%3E%3Cpath d='M50 93C31 86 12 64 14 43 16 28 31 25 50 30 69 25 84 28 86 43 88 64 69 86 50 93Z' fill='%23F0456A' stroke='%237A1E33' stroke-width='3.5' stroke-linejoin='round'/%3E%3Cellipse cx='28' cy='48' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='42' cy='44' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='58' cy='44' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='72' cy='48' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='24' cy='62' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='38' cy='60' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='52' cy='62' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='66' cy='60' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='78' cy='62' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='34' cy='74' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='48' cy='76' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='62' cy='74' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='44' cy='86' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='56' cy='86' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cpath d='M27 46c-3 5-3 11-1 16' fill='none' stroke='%23fff' stroke-width='4.5' stroke-linecap='round' opacity='.55'/%3E%3Cpath d='M50 34 40 38 30 33 38 27 32 19 44 22 50 13 56 22 68 19 62 27 70 33 60 38Z' fill='%236CC25E' stroke='%232F6E2A' stroke-width='3' stroke-linejoin='round'/%3E%3Cpath d='M50 22c0-5 1-9 3-12' fill='none' stroke='%232F6E2A' stroke-width='4' stroke-linecap='round'/%3E%3C/svg%3E\"); }\n.gfx-load-games[data-theme=\"berry\"] .gfx-game-board[data-kind=\"fruits\"] > button span { -webkit-text-stroke-color:#7A1E33; }\n.gfx-load-games[data-theme=\"mint\"] .gfx-game-board[data-kind=\"fruits\"] > button::before { background-image:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Cellipse cx='50' cy='93' rx='26' ry='4' fill='%233A2A20' opacity='.18'/%3E%3Cpath d='M50 31C40 22 16 22 13 47 10 72 29 92 42 91c3-.3 5-1.4 8-1.4s5 1.1 8 1.4c13 1 32-19 29-44C84 22 60 22 50 31Z' fill='%238ACF4E' stroke='%232F5E1C' stroke-width='3.5' stroke-linejoin='round'/%3E%3Cpath d='M27 40c-4 6-5 13-3 19' fill='none' stroke='%23fff' stroke-width='5' stroke-linecap='round' opacity='.6'/%3E%3Ccircle cx='31' cy='34' r='3' fill='%23fff' opacity='.65'/%3E%3Cpath d='M50 31c0-7 1-13 4-18' fill='none' stroke='%236B4528' stroke-width='4.5' stroke-linecap='round'/%3E%3Cpath d='M54 18c6-9 19-10 26-5-5 9-17 11-26 5Z' fill='%233FA56B' stroke='%231F5E3A' stroke-width='3' stroke-linejoin='round'/%3E%3Ccircle cx='70' cy='70' r='3.2' fill='%235A3A24' opacity='.85'/%3E%3Ccircle cx='30' cy='72' r='2.6' fill='%235A3A24' opacity='.85'/%3E%3Ccircle cx='62' cy='50' r='2.4' fill='%235A3A24' opacity='.85'/%3E%3C/svg%3E\"); }\n.gfx-load-games[data-theme=\"mint\"] .gfx-game-board[data-kind=\"fruits\"] > button span { -webkit-text-stroke-color:#2F5E1C; }\n.gfx-load-games[data-theme=\"lavender\"] .gfx-game-board[data-kind=\"fruits\"] > button::before { background-image:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Cellipse cx='50' cy='93' rx='26' ry='4' fill='%233A2A20' opacity='.18'/%3E%3Cpath d='M52 24c0-6 2-11 6-15' fill='none' stroke='%236B4528' stroke-width='4.5' stroke-linecap='round'/%3E%3Cpath d='M56 16c8-8 20-6 25 0-7 8-18 8-25 0Z' fill='%237ED36A' stroke='%233E7A33' stroke-width='3' stroke-linejoin='round'/%3E%3Ccircle cx='30' cy='34' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='26' cy='30' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='50' cy='32' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='46' cy='28' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='70' cy='34' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='66' cy='30' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='22' cy='52' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='18' cy='48' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='40' cy='50' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='36' cy='46' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='60' cy='50' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='56' cy='46' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='78' cy='52' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='74' cy='48' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='31' cy='68' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='27' cy='64' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='50' cy='67' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='46' cy='63' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='69' cy='68' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='65' cy='64' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='40' cy='84' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='36' cy='80' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='60' cy='84' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='56' cy='80' r='2.6' fill='%23fff' opacity='.7'/%3E%3C/svg%3E\"); }\n.gfx-load-games[data-theme=\"lavender\"] .gfx-game-board[data-kind=\"fruits\"] > button span { -webkit-text-stroke-color:#3D2470; }\n.gfx-load-games[data-theme=\"night\"] .gfx-game-board[data-kind=\"fruits\"] > button::before { background-image:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Cellipse cx='50' cy='93' rx='24' ry='4' fill='%23000' opacity='.25'/%3E%3Cpath d='M45.8 17.4Q50 10 54.2 17.4L61.6 30.2Q64.1 34.6 69.1 35.6L83.5 38.7Q91.8 40.4 86.1 46.7L76.2 57.6Q72.8 61.4 73.4 66.5L75 81.1Q75.9 89.6 68.1 86.1L54.7 80.1Q50 78 45.3 80.1L31.9 86.1Q24.1 89.6 25 81.1L26.6 66.5Q27.2 61.4 23.8 57.6L13.9 46.7Q8.2 40.4 16.5 38.7L30.9 35.6Q35.9 34.6 38.4 30.2Z' fill='%23FFCF3D' stroke='%238A5A00' stroke-width='3.5' stroke-linejoin='round'/%3E%3Cpath d='M38 40c-3 3-4 7-4 11' fill='none' stroke='%23fff' stroke-width='4' stroke-linecap='round' opacity='.75'/%3E%3Ccircle cx='85' cy='15' r='4' fill='%23FFF6C2'/%3E%3Ccircle cx='13' cy='76' r='3' fill='%23FFF6C2'/%3E%3C/svg%3E\"); }\n.gfx-load-games[data-theme=\"night\"] .gfx-game-board[data-kind=\"fruits\"] > button span { -webkit-text-stroke-color:#7A4E00; }\n.gfx-load-games[data-theme=\"lavender\"] .gfx-game-board[data-kind=\"fruits\"] > button span { margin-top:30%; }\n.gfx-load-games[data-theme=\"night\"] .gfx-game-board[data-kind=\"fruits\"] > button span { margin-top:14%; }\n.gfx-load-games[data-theme=\"berry\"] .gfx-game-board[data-kind=\"fruits\"] > button span { margin-top:26%; }\n/* Minesweeper palettes: covered tile (two stops), opened tile, its rim, the board, the flag and the eight numbers. */\n.gfx-load-games { --mc1:#FFF3C4; --mc2:#FFD86B; --mo:#FFFDF5; --mol:#E8D9BE; --mb:#E8D9BE; --mflag:#E13F35;\n  --n1:#2F6FD6; --n2:#2E8B43; --n3:#D23B3B; --n4:#6A3FB5; --n5:#A0522D; --n6:#13817F; --n7:#333; --n8:#777; }\n.gfx-load-games[data-theme=\"berry\"] { --mc1:#FFE1EA; --mc2:#FFAEC6; --mo:#FFF8FA; --mol:#F6CFDC; --mb:#F3C6D4; --mflag:#D91E4F; }\n.gfx-load-games[data-theme=\"mint\"] { --mc1:#DDF8EA; --mc2:#8FDDBA; --mo:#F6FFFA; --mol:#C4E9D7; --mb:#BFE4D2; --mflag:#6B4528; }\n.gfx-load-games[data-theme=\"lavender\"] { --mc1:#EFE8FF; --mc2:#C3AEFF; --mo:#FCFBFF; --mol:#DCD0F7; --mb:#D5C8F5; --mflag:#E0483C; }\n.gfx-load-games[data-theme=\"night\"] { --mc1:#5C6299; --mc2:#3E4374; --mo:#22253D; --mol:#3B4068; --mb:#171A2E; --mflag:#FFD166;\n  --n1:#8EC5FF; --n2:#8EE6A8; --n3:#FF9B9B; --n4:#D3B5FF; --n5:#FFC48A; --n6:#7FE0DA; --n7:#F0F0F0; --n8:#BBBBBB; }\n.gfx-game-board[data-kind=\"mines\"] { background:var(--mb); }\n/* Solid tiles; the lighter shade is a top edge, not a gradient. */\n.gfx-game-board[data-kind=\"mines\"] > button { background:var(--mc2); box-shadow:inset 0 3px 0 var(--mc1), 0 2px 0 var(--gfx-line, #6B4528); }\n.gfx-load-games[data-theme=\"night\"] .gfx-game-board[data-kind=\"mines\"] > button:not([data-open=\"true\"]) {\n  background:var(--mc2); box-shadow:inset 0 3px 0 var(--mc1), 0 2px 0 #14162A; border-color:#14162A; box-shadow:0 2px 0 #14162A; }\n.gfx-game-board[data-kind=\"mines\"] > button[data-open=\"true\"] { background:var(--mo); border-color:var(--mol); }\n.gfx-game-board > button[data-n=\"1\"] { color:var(--n1); } .gfx-game-board > button[data-n=\"2\"] { color:var(--n2); } .gfx-game-board > button[data-n=\"3\"] { color:var(--n3); }\n.gfx-game-board > button[data-n=\"4\"] { color:var(--n4); } .gfx-game-board > button[data-n=\"5\"] { color:var(--n5); } .gfx-game-board > button[data-n=\"6\"] { color:var(--n6); }\n.gfx-game-board > button[data-n=\"7\"] { color:var(--n7); } .gfx-game-board > button[data-n=\"8\"] { color:var(--n8); }\n.gfx-game-board[data-kind=\"mines\"] button[data-flag=\"true\"]::after { background:var(--mflag); }\n/* 밤하늘: a gold star instead of the flag, a glowing orb instead of the bomb. */\n.gfx-load-games[data-theme=\"night\"] .gfx-game-board[data-kind=\"mines\"] button[data-flag=\"true\"] { background:var(--mc2); }\n.gfx-load-games[data-theme=\"night\"] .gfx-game-board[data-kind=\"mines\"] button[data-flag=\"true\"]::before { display:none; }\n.gfx-load-games[data-theme=\"night\"] .gfx-game-board[data-kind=\"mines\"] button[data-flag=\"true\"]::after { left:18%; top:16%; width:64%; height:64%;\n  clip-path:none; -webkit-mask:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Cpath d='M45.6 12.3Q50 4 54.4 12.3L62 26.8Q64.7 31.8 70.3 32.7L86.4 35.5Q95.7 37.2 89.1 43.9L77.7 55.7Q73.8 59.7 74.6 65.3L76.9 81.5Q78.2 90.8 69.7 86.7L55.1 79.5Q50 77 44.9 79.5L30.3 86.7Q21.8 90.8 23.1 81.5L25.4 65.3Q26.2 59.7 22.3 55.7L10.9 43.9Q4.3 37.2 13.6 35.5L29.7 32.7Q35.3 31.8 38 26.8Z'/%3E%3C/svg%3E\") center / contain no-repeat; mask:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Cpath d='M45.6 12.3Q50 4 54.4 12.3L62 26.8Q64.7 31.8 70.3 32.7L86.4 35.5Q95.7 37.2 89.1 43.9L77.7 55.7Q73.8 59.7 74.6 65.3L76.9 81.5Q78.2 90.8 69.7 86.7L55.1 79.5Q50 77 44.9 79.5L30.3 86.7Q21.8 90.8 23.1 81.5L25.4 65.3Q26.2 59.7 22.3 55.7L10.9 43.9Q4.3 37.2 13.6 35.5L29.7 32.7Q35.3 31.8 38 26.8Z'/%3E%3C/svg%3E\") center / contain no-repeat; filter:drop-shadow(0 0 3px #FFD166); }\n.gfx-load-games[data-theme=\"night\"] .gfx-game-board > button[data-mine=\"true\"]::before { background:#8C6CF0;\n  box-shadow:0 0 .35em #9C82FF, 0 0 0 .1em #2A1F66; }\n/* 민트 초코: the mine is a chocolate chip. */\n.gfx-load-games[data-theme=\"mint\"] .gfx-game-board > button[data-mine=\"true\"]::before { width:56%; border-radius:52% 48% 46% 54% / 60% 58% 42% 40%;\n  background:#5A3A24; box-shadow:0 .08em 0 #2A180C; }\n/* The result card over the board; a tap beside it shows the board again. */\n.gfx-game-result { position:absolute; inset:0; display:grid; place-items:center; z-index:2; border-radius:16px; background:color-mix(in srgb,var(--gfx-ink, #FFF4D9) 45%,transparent); cursor:pointer; }\n.gfx-game-result[hidden] { display:none; }\n.gfx-game-result > div { display:grid; justify-items:center; gap:.35em; padding:1em 1.6em; background:var(--gfx-card, #FFFDF5); border:3px solid var(--gfx-line, #6B4528); border-radius:22px; box-shadow:0 5px 0 var(--gfx-line, #6B4528); cursor:default; animation:gfx-game-pop .35s cubic-bezier(.3,1.6,.5,1) both; }\n.gfx-game-result b { font-size:1.6em; font-weight:normal; color:var(--gfx-accent, #F0763A); }\n.gfx-game-result em { font-style:normal; padding:.1em .8em; border-radius:999px; background:#FFD84D; color:#5A3A10; }\n.gfx-game-again { background:var(--gfx-accent, #F0763A) !important; color:#fff !important; margin-top:.2em; }\n@keyframes gfx-game-pop { from { scale:.6; opacity:0; } }\n@media (prefers-reduced-motion: reduce) { .gfx-load-games *, .gfx-load-games *::before { animation:none !important; transition:none !important; } }\n/* Placement: a column of game cards on the right of the generation screen, the game beside it. */\n:host { position:absolute; inset:12px 12px 12px auto; width:min(880px,96%); z-index:5; display:block; pointer-events:none; container-type:size; }\n:host([data-game-large]) { width:calc(100% - 24px); }\n.gfx-load-games { height:100%; display:flex; flex-direction:row-reverse; align-items:flex-start; gap:10px; --room:calc(100cqh - 150px);\n  color:var(--gfx-text, #5A3A24); font:clamp(12px,1.5vw,16px)/1.35 var(--body, \"Jua\"), \"Malgun Gothic\", sans-serif; }\n.gfx-load-games > * { pointer-events:auto; }\n.gfx-game-nav { flex:0 0 112px; flex-direction:column; flex-wrap:nowrap; align-items:stretch; max-height:100%; overflow:auto; margin:0; box-sizing:border-box; }\n.gfx-game-utils { flex-direction:column; }\n.gfx-game-content { flex:1; min-width:0; max-height:100%; overflow:auto; box-sizing:border-box; }\n.gfx-game-board[data-kind=\"memory\"] > button > .face img { filter:drop-shadow(0 0 1.5px #fff) drop-shadow(0 0 1px #fff); }\n@media (max-width:600px) { :host { inset:8px 8px 8px auto; } .gfx-load-games { gap:5px; } .gfx-game-nav { flex-basis:78px; padding:5px; } .gfx-game-tab i { font-size:1.3em !important; } }\n/* Theme games */\n/* 딸기 우유 레시피: one rounded pad per ingredient; it lights up in the order to repeat. */\n.gfx-game-board[data-kind=\"recipe\"] { gap:10px; padding:10px; }\n.gfx-game-board[data-kind=\"recipe\"] > button { aspect-ratio:1; border-radius:26px !important; border:3px solid var(--gfx-line, #6B4528); box-shadow:0 5px 0 var(--gfx-line, #6B4528);\n  font-size:calc(100cqw / var(--cols) * .17); color:#6A2E45; transition:scale .12s ease, filter .12s ease, box-shadow .12s ease; }\n.gfx-game-board[data-kind=\"recipe\"] > button:disabled { opacity:1; }\n.gfx-game-board[data-kind=\"recipe\"] > button[data-pad=\"0\"] { background:#F2557F; color:#fff; } .gfx-game-board[data-kind=\"recipe\"] > button[data-pad=\"1\"] { background:#FFFFFF; }\n.gfx-game-board[data-kind=\"recipe\"] > button[data-pad=\"2\"] { background:#FFE7A3; } .gfx-game-board[data-kind=\"recipe\"] > button[data-pad=\"3\"] { background:#BFE6FF; }\n.gfx-game-board[data-kind=\"recipe\"] > button[data-pad=\"4\"] { background:#FFF3D6; } .gfx-game-board[data-kind=\"recipe\"] > button[data-pad=\"5\"] { background:#FFD3E0; }\n.gfx-game-board[data-kind=\"recipe\"] > button[data-lit] { scale:1.08; filter:brightness(1.12); box-shadow:0 0 0 6px #fff, 0 0 0 9px #F2557F, 0 5px 0 var(--gfx-line, #6B4528); }\n/* 초코칩 터뜨리기: mint, chocolate and friends; the group under the pointer lifts. */\n.gfx-game-board[data-kind=\"pop\"] { gap:3px; }\n.gfx-game-board[data-kind=\"pop\"] > button { border:2px solid #0003; box-shadow:none; border-radius:30% !important; transition:scale .12s ease; }\n.gfx-game-board[data-kind=\"pop\"] > button[data-v=\"0\"] { visibility:hidden; }\n.gfx-game-board[data-kind=\"pop\"] > button[data-v=\"1\"] { background:#8FDDBA; } .gfx-game-board[data-kind=\"pop\"] > button[data-v=\"2\"] { background:#6B4528; }\n.gfx-game-board[data-kind=\"pop\"] > button[data-v=\"3\"] { background:#FFF3D6; } .gfx-game-board[data-kind=\"pop\"] > button[data-v=\"4\"] { background:#F7A8C4; }\n.gfx-game-board[data-kind=\"pop\"] > button[data-v=\"5\"] { background:#9CC9F5; }\n.gfx-game-board[data-kind=\"pop\"] > button[data-v=\"1\"]::after { content:\"\"; width:18%; aspect-ratio:1; border-radius:50%; background:#3E2616; box-shadow:.5em .35em 0 -.05em #3E2616; translate:-.2em -.15em; }\n.gfx-game-board[data-kind=\"pop\"] > button[data-group=\"true\"] { scale:1.1; z-index:1; outline:3px solid #fff; outline-offset:-1px; }\n/* 꽃밭 퍼즐: lavender tiles; a tile in its place turns deeper. */\n.gfx-game-board[data-kind=\"slide\"] { gap:6px; padding:8px; }\n.gfx-game-board[data-kind=\"slide\"] > button { background:#C9B6FF; color:#fff; border:2.5px solid #4F3F85; box-shadow:0 3px 0 #4F3F85; border-radius:16px !important;\n  font-size:calc(100cqw / var(--cols) * .36); -webkit-text-stroke:.12em #4F3F85; paint-order:stroke fill; }\n.gfx-game-board[data-kind=\"slide\"] > button::after { content:\"\"; position:absolute; right:12%; top:12%; width:14%; aspect-ratio:1; border-radius:50%; background:#fff; opacity:.7;\n  box-shadow:-.32em 0 0 -.02em #FFE7A3, 0 .32em 0 -.02em #fff; }\n.gfx-game-board[data-kind=\"slide\"] > button[data-home=\"true\"] { background:#9A7BEA; }\n.gfx-game-board[data-kind=\"slide\"] > button[data-blank=\"true\"] { visibility:hidden; }\n/* 별 밝히기: dim stars that light up gold. */\n.gfx-game-board[data-kind=\"lights\"] { background:#171A2E; gap:6px; padding:8px; }\n.gfx-game-board[data-kind=\"lights\"] > button { background:#262A45; border:2px solid #3B4068; box-shadow:none; border-radius:14px !important; }\n.gfx-game-board[data-kind=\"lights\"] > button::before { content:\"\"; width:72%; aspect-ratio:1; background:#4A4F80; -webkit-mask:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Cpath d='M45.6 12.3Q50 4 54.4 12.3L62 26.8Q64.7 31.8 70.3 32.7L86.4 35.5Q95.7 37.2 89.1 43.9L77.7 55.7Q73.8 59.7 74.6 65.3L76.9 81.5Q78.2 90.8 69.7 86.7L55.1 79.5Q50 77 44.9 79.5L30.3 86.7Q21.8 90.8 23.1 81.5L25.4 65.3Q26.2 59.7 22.3 55.7L10.9 43.9Q4.3 37.2 13.6 35.5L29.7 32.7Q35.3 31.8 38 26.8Z'/%3E%3C/svg%3E\") center / contain no-repeat; mask:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Cpath d='M45.6 12.3Q50 4 54.4 12.3L62 26.8Q64.7 31.8 70.3 32.7L86.4 35.5Q95.7 37.2 89.1 43.9L77.7 55.7Q73.8 59.7 74.6 65.3L76.9 81.5Q78.2 90.8 69.7 86.7L55.1 79.5Q50 77 44.9 79.5L30.3 86.7Q21.8 90.8 23.1 81.5L25.4 65.3Q26.2 59.7 22.3 55.7L10.9 43.9Q4.3 37.2 13.6 35.5L29.7 32.7Q35.3 31.8 38 26.8Z'/%3E%3C/svg%3E\") center / contain no-repeat;\n  transition:background .2s ease, scale .2s cubic-bezier(.3,1.6,.5,1), filter .2s ease; scale:.85; }\n.gfx-game-board[data-kind=\"lights\"] > button[data-on=\"true\"]::before { background:#FFD166; scale:1; filter:drop-shadow(0 0 4px #FFD166); }\n.gfx-game-board > button:hover:not(:disabled) { filter:brightness(1.05); }\n/* Nine games: a two-column shelf of compact cards. */\n.gfx-game-nav { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); align-content:start; flex:0 0 164px; gap:6px; padding:7px; }\n.gfx-game-tab { min-width:0 !important; padding:.3em .2em !important; gap:0; border-radius:14px !important; }\n.gfx-game-tab i { font-size:1.35em; }\n.gfx-game-tab span { font-size:.76em; white-space:normal; line-height:1.15; text-align:center; word-break:keep-all; }\n.gfx-game-utils { grid-column:1 / -1; flex-direction:row; flex-wrap:wrap; }\n.gfx-game-utils > button { flex:1; }\n@media (max-width:600px) { .gfx-game-nav { flex-basis:120px; padding:4px; gap:4px; } .gfx-game-tab span { font-size:.68em; } .gfx-game-tab i { font-size:1.1em !important; } }\n.gfx-game-utils > .gfx-game-util { white-space:nowrap; font-size:.74em !important; padding:.3em .4em !important; }\n/* 스네이크's food: the theme's piece. */\n.gfx-load-games { --gfx-piece:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Cellipse cx='50' cy='93' rx='26' ry='4' fill='%236B4528' opacity='.18'/%3E%3Cpath d='M50 31C40 22 16 22 13 47 10 72 29 92 42 91c3-.3 5-1.4 8-1.4s5 1.1 8 1.4c13 1 32-19 29-44C84 22 60 22 50 31Z' fill='%23EF4B3F' stroke='%236B2318' stroke-width='3.5' stroke-linejoin='round'/%3E%3Cpath d='M27 40c-4 6-5 13-3 19' fill='none' stroke='%23fff' stroke-width='5' stroke-linecap='round' opacity='.55'/%3E%3Ccircle cx='31' cy='34' r='3' fill='%23fff' opacity='.6'/%3E%3Cpath d='M50 31c0-7 1-13 4-18' fill='none' stroke='%236B4528' stroke-width='4.5' stroke-linecap='round'/%3E%3Cpath d='M54 18c6-9 19-10 26-5-5 9-17 11-26 5Z' fill='%237ED36A' stroke='%233E7A33' stroke-width='3' stroke-linejoin='round'/%3E%3Cpath d='M57 17c6-2 12-3 18-3' fill='none' stroke='%233E7A33' stroke-width='1.8' stroke-linecap='round' opacity='.7'/%3E%3C/svg%3E\"); }\n.gfx-load-games[data-theme=\"berry\"] { --gfx-piece:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Cellipse cx='50' cy='93' rx='26' ry='4' fill='%233A2A20' opacity='.18'/%3E%3Cpath d='M50 93C31 86 12 64 14 43 16 28 31 25 50 30 69 25 84 28 86 43 88 64 69 86 50 93Z' fill='%23F0456A' stroke='%237A1E33' stroke-width='3.5' stroke-linejoin='round'/%3E%3Cellipse cx='28' cy='48' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='42' cy='44' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='58' cy='44' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='72' cy='48' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='24' cy='62' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='38' cy='60' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='52' cy='62' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='66' cy='60' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='78' cy='62' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='34' cy='74' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='48' cy='76' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='62' cy='74' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='44' cy='86' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='56' cy='86' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cpath d='M27 46c-3 5-3 11-1 16' fill='none' stroke='%23fff' stroke-width='4.5' stroke-linecap='round' opacity='.55'/%3E%3Cpath d='M50 34 40 38 30 33 38 27 32 19 44 22 50 13 56 22 68 19 62 27 70 33 60 38Z' fill='%236CC25E' stroke='%232F6E2A' stroke-width='3' stroke-linejoin='round'/%3E%3Cpath d='M50 22c0-5 1-9 3-12' fill='none' stroke='%232F6E2A' stroke-width='4' stroke-linecap='round'/%3E%3C/svg%3E\"); }\n.gfx-load-games[data-theme=\"mint\"] { --gfx-piece:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Cellipse cx='50' cy='93' rx='26' ry='4' fill='%233A2A20' opacity='.18'/%3E%3Cpath d='M50 31C40 22 16 22 13 47 10 72 29 92 42 91c3-.3 5-1.4 8-1.4s5 1.1 8 1.4c13 1 32-19 29-44C84 22 60 22 50 31Z' fill='%238ACF4E' stroke='%232F5E1C' stroke-width='3.5' stroke-linejoin='round'/%3E%3Cpath d='M27 40c-4 6-5 13-3 19' fill='none' stroke='%23fff' stroke-width='5' stroke-linecap='round' opacity='.6'/%3E%3Ccircle cx='31' cy='34' r='3' fill='%23fff' opacity='.65'/%3E%3Cpath d='M50 31c0-7 1-13 4-18' fill='none' stroke='%236B4528' stroke-width='4.5' stroke-linecap='round'/%3E%3Cpath d='M54 18c6-9 19-10 26-5-5 9-17 11-26 5Z' fill='%233FA56B' stroke='%231F5E3A' stroke-width='3' stroke-linejoin='round'/%3E%3Ccircle cx='70' cy='70' r='3.2' fill='%235A3A24' opacity='.85'/%3E%3Ccircle cx='30' cy='72' r='2.6' fill='%235A3A24' opacity='.85'/%3E%3Ccircle cx='62' cy='50' r='2.4' fill='%235A3A24' opacity='.85'/%3E%3C/svg%3E\"); }\n.gfx-load-games[data-theme=\"lavender\"] { --gfx-piece:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Cellipse cx='50' cy='93' rx='26' ry='4' fill='%233A2A20' opacity='.18'/%3E%3Cpath d='M52 24c0-6 2-11 6-15' fill='none' stroke='%236B4528' stroke-width='4.5' stroke-linecap='round'/%3E%3Cpath d='M56 16c8-8 20-6 25 0-7 8-18 8-25 0Z' fill='%237ED36A' stroke='%233E7A33' stroke-width='3' stroke-linejoin='round'/%3E%3Ccircle cx='30' cy='34' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='26' cy='30' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='50' cy='32' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='46' cy='28' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='70' cy='34' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='66' cy='30' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='22' cy='52' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='18' cy='48' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='40' cy='50' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='36' cy='46' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='60' cy='50' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='56' cy='46' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='78' cy='52' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='74' cy='48' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='31' cy='68' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='27' cy='64' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='50' cy='67' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='46' cy='63' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='69' cy='68' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='65' cy='64' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='40' cy='84' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='36' cy='80' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='60' cy='84' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='56' cy='80' r='2.6' fill='%23fff' opacity='.7'/%3E%3C/svg%3E\"); }\n.gfx-load-games[data-theme=\"night\"] { --gfx-piece:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Cellipse cx='50' cy='93' rx='24' ry='4' fill='%23000' opacity='.25'/%3E%3Cpath d='M45.8 17.4Q50 10 54.2 17.4L61.6 30.2Q64.1 34.6 69.1 35.6L83.5 38.7Q91.8 40.4 86.1 46.7L76.2 57.6Q72.8 61.4 73.4 66.5L75 81.1Q75.9 89.6 68.1 86.1L54.7 80.1Q50 78 45.3 80.1L31.9 86.1Q24.1 89.6 25 81.1L26.6 66.5Q27.2 61.4 23.8 57.6L13.9 46.7Q8.2 40.4 16.5 38.7L30.9 35.6Q35.9 34.6 38.4 30.2Z' fill='%23FFCF3D' stroke='%238A5A00' stroke-width='3.5' stroke-linejoin='round'/%3E%3Cpath d='M38 40c-3 3-4 7-4 11' fill='none' stroke='%23fff' stroke-width='4' stroke-linecap='round' opacity='.75'/%3E%3Ccircle cx='85' cy='15' r='4' fill='%23FFF6C2'/%3E%3Ccircle cx='13' cy='76' r='3' fill='%23FFF6C2'/%3E%3C/svg%3E\"); }\n/* 스네이크: the theme's piece is the food. */\n.gfx-game-board[data-kind=\"snake\"] { gap:1px; padding:6px; background:var(--mb, #E8D9BE); }\n.gfx-game-board[data-kind=\"snake\"] > div { border-radius:30% !important; background:color-mix(in srgb,var(--gfx-card, #FFFDF5) 45%,transparent); }\n.gfx-game-board[data-kind=\"snake\"] > div[data-s=\"body\"] { background:var(--gfx-accent, #F0763A); border-radius:34% !important; }\n.gfx-game-board[data-kind=\"snake\"] > div[data-s=\"head\"] { background:color-mix(in srgb,var(--gfx-accent, #F0763A) 70%,var(--gfx-line, #6B4528)); border-radius:40% !important; }\n.gfx-game-board[data-kind=\"snake\"] > div[data-s=\"head\"]::after { content:\"\"; width:18%; aspect-ratio:1; border-radius:50%; background:#fff; box-shadow:.45em 0 0 #fff; translate:-.22em 0; font-size:inherit; }\n.gfx-game-board[data-kind=\"snake\"] > div[data-s=\"food\"]::before { content:\"\"; position:absolute; inset:-8%; background:var(--gfx-piece) center / contain no-repeat; }\n/* 쿠키 가게: the shop front (awning, sign, window, menu board, guests, counter), the tool shelf, the ovens. */\n.gfx-game-board[data-kind=\"shop\"] { position:relative; display:flex; flex-direction:column; gap:0; padding:0; overflow:hidden; background:#F3E3C8; border:3px solid var(--gfx-line, #6B4528); container-type:inline-size; }\n.gfx-game-board[data-kind=\"shop\"] > * { aspect-ratio:auto; place-items:normal; font-size:inherit; line-height:1.3; border-radius:0 !important; }\n.gfx-shop-front { position:relative; display:block !important; height:clamp(150px,50cqw,250px); overflow:hidden; background:repeating-linear-gradient(90deg,#FCE6CF 0 14px,#F8DDC2 14px 28px); }\n.gfx-load-games[data-theme=\"night\"] .gfx-shop-front { background:repeating-linear-gradient(90deg,#3B3F66 0 14px,#363A5E 14px 28px); }\n.gfx-shop-awning { position:absolute; inset:0 0 auto; height:24px; filter:drop-shadow(0 2.5px 0 var(--gfx-line, #6B4528)); z-index:1; }\n.gfx-shop-awning::before { content:\"\"; position:absolute; inset:0; background:repeating-linear-gradient(90deg,var(--gfx-accent, #F0763A) 0 24px,#fff 24px 48px);\n  -webkit-mask:radial-gradient(12px at 12px 12px,#000 98%,#0000) 0 100% / 24px 100% repeat-x, linear-gradient(#000 0 0) top / 100% 12px no-repeat;\n  mask:radial-gradient(12px at 12px 12px,#000 98%,#0000) 0 100% / 24px 100% repeat-x, linear-gradient(#000 0 0) top / 100% 12px no-repeat; }\n.gfx-shop-sign { position:absolute; left:50%; top:3px; translate:-50% 0; z-index:2; padding:.12em .9em; border-radius:10px; font-weight:normal; white-space:nowrap; font-size:max(11px,3.4cqw);\n  background:#8A5A33; color:#FFF4D9; border:3px solid var(--gfx-line, #6B4528); box-shadow:0 3px 0 var(--gfx-line, #6B4528), inset 0 -4px 0 #74482A; letter-spacing:.05em; }\n.gfx-shop-sign::before { content:\"🍪\"; margin-right:.25em; }\n.gfx-shop-window { position:absolute; left:3%; top:36px; width:22%; height:44%; box-sizing:border-box; border:4px solid #fff; outline:2.5px solid var(--gfx-line, #6B4528); border-radius:10px 10px 4px 4px; overflow:hidden;\n  background:linear-gradient(90deg,transparent calc(50% - 2px),#fff calc(50% - 2px) calc(50% + 2px),transparent 0), linear-gradient(transparent calc(50% - 2px),#fff calc(50% - 2px) calc(50% + 2px),transparent 0), #BFE6FF; }\n.gfx-shop-window::before { content:\"\"; position:absolute; left:14%; top:22%; width:16%; aspect-ratio:1; border-radius:50%; background:#fff; box-shadow:.7em .15em 0 .1em #fff, 1.3em .2em 0 -.05em #fff; }\n.gfx-shop-window::after { content:\"\"; position:absolute; inset:0 auto auto 0; width:100%; height:22%; background:repeating-linear-gradient(90deg,var(--gfx-accent, #F0763A) 0 8px,#FFD3C0 8px 16px); border-bottom:2px solid var(--gfx-line, #6B4528); border-radius:0 0 40% 40% / 0 0 100% 100%; }\n.gfx-load-games[data-theme=\"night\"] .gfx-shop-window { background-color:#171A2E; }\n.gfx-load-games[data-theme=\"night\"] .gfx-shop-window::before { background:#FFD166; box-shadow:0 0 6px #FFD166, 1.4em 1.2em 0 -.25em #FFF6C2; }\n.gfx-shop-menu { position:absolute; right:3%; top:36px; width:24%; box-sizing:border-box; display:grid !important; gap:1px; padding:4px 6px; font-size:max(8px,2.3cqw); color:#F5F1E6;\n  background:#3E4A3D; border:4px solid #A8743F; outline:2.5px solid var(--gfx-line, #6B4528); border-radius:8px; }\n.gfx-shop-menu b { font-weight:normal; text-align:center; color:#FFD84D; letter-spacing:.15em; }\n.gfx-shop-menu span { display:flex; align-items:center; gap:.3em; white-space:nowrap; }\n.gfx-shop-menu svg { width:1.7em; flex:none; }\n.gfx-shop-menu i { font-style:normal; }\n/* Guests: up to three behind the counter, an order bubble with a patience bar above each; the bubbles sit over the sign. */\n.gfx-shop-guests { position:absolute; z-index:3; left:26%; right:28%; top:40px; bottom:19%; display:flex !important; justify-content:center; align-items:flex-end; gap:2%; }\n.gfx-shop-guest { position:relative; width:32%; display:flex; flex-direction:column; align-items:center; gap:3px; animation:gfx-guest-in .45s cubic-bezier(.3,1.5,.5,1) both; }\n@keyframes gfx-guest-in { from { translate:0 40%; opacity:0; } }\n.gfx-shop-guest .order { position:relative; display:flex; align-items:center; gap:.2em; padding:.15em .4em .35em; border-radius:10px; background:#fff; border:2px solid var(--gfx-line, #6B4528);\n  font-size:max(8px,2.1cqw); white-space:nowrap; box-shadow:0 2px 0 var(--gfx-line, #6B4528); }\n.gfx-shop-guest .order::after { content:\"\"; position:absolute; left:50%; bottom:-6px; width:8px; height:8px; background:#fff; border-right:2px solid var(--gfx-line, #6B4528); border-bottom:2px solid var(--gfx-line, #6B4528); translate:-50% 0; rotate:45deg; }\n.gfx-shop-guest .order svg { width:2em; }\n.gfx-shop-guest .order i { font-style:normal; }\n.gfx-shop-guest .wait { position:absolute; left:6px; right:6px; bottom:2px; height:3px; border-radius:999px; background:#0001; overflow:hidden; }\n.gfx-shop-guest .wait::after { content:\"\"; position:absolute; inset:0 auto 0 0; width:calc(var(--w, 1) * 100%); background:#4CC27A; border-radius:999px; }\n.gfx-shop-guest[data-mood=\"ok\"] .wait::after { background:#FFC933; }\n.gfx-shop-guest[data-mood=\"angry\"] .wait::after { background:#E0483C; }\n.gfx-shop-guest .fig { position:relative; width:100%; aspect-ratio:60 / 72; display:block; }\n.gfx-shop-guest .fig > * { position:absolute; inset:0; width:100%; height:100%; }\n.gfx-shop-guest .fig img { object-fit:contain; object-position:50% 0; filter:drop-shadow(0 0 1.5px #fff) drop-shadow(0 0 1px #fff); }\n/* An SD sprite is a whole figure: show its upper body, as large as the drawn guests; the counter hides the cut. */\n.gfx-shop-guest .fig[data-sd] { overflow:hidden; }\n.gfx-shop-guest .fig[data-sd] > img { inset:4% auto auto 50%; width:auto; height:165%; max-width:none; translate:-50% 0; object-fit:fill; }\n.gfx-shop-guest .fig[data-sd]::after { z-index:1; }\n.gfx-shop-guest[data-mood=\"happy\"] .fig { animation:gfx-guest-bob 1.6s ease-in-out infinite; }\n@keyframes gfx-guest-bob { 50% { translate:0 -3%; } }\n.gfx-shop-guest[data-mood=\"angry\"] .fig { animation:gfx-guest-fume .5s ease-in-out infinite; }\n@keyframes gfx-guest-fume { 25% { translate:-2% 0; } 75% { translate:2% 0; } }\n.gfx-shop-guest[data-mood=\"angry\"] .fig::after { content:\"💢\"; position:absolute; right:-4%; top:2%; font-size:max(10px,3cqw); }\n.gfx-shop-guest[data-leave] { animation:gfx-guest-out .7s ease-in both; }\n.gfx-shop-guest[data-leave=\"happy\"] { animation-name:gfx-guest-yay; }\n@keyframes gfx-guest-out { 30% { translate:0 -6%; } to { translate:0 60%; opacity:0; } }\n@keyframes gfx-guest-yay { 25% { translate:0 -14%; } 50% { translate:0 0; } to { translate:0 -10%; opacity:0; } }\n.gfx-shop-guest[data-leave=\"happy\"] .fig::after { content:\"♥\"; position:absolute; right:0; top:0; color:#F2557F; font-size:max(12px,3.4cqw); }\n.gfx-shop-fig-svg, .gfx-shop-guest .fig svg { overflow:visible; }\n.gfx-shop-guest .g-body { fill:var(--shirt, #F7A8C4); stroke:var(--gfx-line, #6B4528); stroke-width:2.5; }\n.gfx-shop-guest .g-collar { fill:none; stroke:var(--gfx-line, #6B4528); stroke-width:2.2; }\n.gfx-shop-guest .g-back, .gfx-shop-guest .g-hair { fill:var(--hair, #6B4528); stroke:var(--gfx-line, #6B4528); stroke-width:2.5; stroke-linejoin:round; }\n.gfx-shop-guest .g-head { fill:#FFE3C8; stroke:var(--gfx-line, #6B4528); stroke-width:2.5; }\n.gfx-shop-guest .g-eyes { fill:#3A2618; }\n.gfx-shop-guest .g-cheek { fill:#FF9FA8; opacity:.65; }\n.gfx-shop-guest .g-mouth { fill:none; stroke:#3A2618; stroke-width:2; stroke-linecap:round; display:none; }\n.gfx-shop-guest .g-brow { fill:none; stroke:#3A2618; stroke-width:2; stroke-linecap:round; display:none; }\n.gfx-shop-guest:not([data-mood]) .m-happy, .gfx-shop-guest[data-mood=\"happy\"] .m-happy, .gfx-shop-guest[data-mood=\"ok\"] .m-flat, .gfx-shop-guest[data-mood=\"angry\"] .m-angry, .gfx-shop-guest[data-mood=\"angry\"] .g-brow { display:inline; }\n/* The counter: wood planks, the guest's word and the till. */\n.gfx-shop-counter { position:absolute; inset:auto 0 0; height:24%; display:flex !important; align-items:center; gap:8px; padding:0 3%; box-sizing:border-box; z-index:4;\n  background:repeating-linear-gradient(90deg,#B07A47 0 46px,#9E6C3D 46px 48px); border-top:3px solid var(--gfx-line, #6B4528); box-shadow:inset 0 6px 0 #C99260; }\n.gfx-shop-say { position:relative; flex:1; min-width:0; padding:.25em .8em; border-radius:12px; background:#fff; border:2.5px solid var(--gfx-line, #6B4528); box-shadow:0 2px 0 var(--gfx-line, #6B4528);\n  font-size:max(10px,2.7cqw); white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }\n.gfx-shop-say[data-mood=\"good\"] { background:#DDF6E6; } .gfx-shop-say[data-mood=\"bad\"] { background:#FFE1DC; }\n.gfx-shop-say[data-pop] { animation:gfx-game-pop .3s cubic-bezier(.3,1.6,.5,1); }\n.gfx-shop-till { flex:none; padding:.2em .6em; border-radius:8px; background:#3E2616; color:#9CF5B8; border:2.5px solid var(--gfx-line, #6B4528); box-shadow:inset 0 0 0 2px #5A3A24, 0 2px 0 var(--gfx-line, #6B4528);\n  font-size:max(10px,2.6cqw); font-variant-numeric:tabular-nums; letter-spacing:.04em; }\n.gfx-shop-till::before { content:\"🪙 \"; }\n/* The shelf: a wooden plank with the seven tools. */\n.gfx-shop-shelf { display:grid !important; grid-template-columns:repeat(7,minmax(0,1fr)); gap:4px; padding:6px 6px 9px; background:#8A5A33; border-top:3px solid var(--gfx-line, #6B4528); border-bottom:3px solid var(--gfx-line, #6B4528);\n  box-shadow:inset 0 -5px 0 #74482A; }\n.gfx-game-board[data-kind=\"shop\"] .gfx-shop-tool { position:relative; display:flex; flex-direction:column; align-items:center; gap:0; padding:3px 0 2px !important; border-radius:12px !important; border-width:2px;\n  background:#FFF7E8; box-shadow:0 3px 0 var(--gfx-line, #6B4528); font-size:max(9px,2.3cqw); min-width:0; transition:translate .1s ease, background .15s ease; }\n.gfx-shop-tool .icon { display:block; width:min(2.6em,80%); }\n.gfx-shop-tool .icon svg { display:block; width:100%; }\n.gfx-shop-tool .label { white-space:nowrap; }\n.gfx-shop-tool kbd { position:absolute; left:2px; top:1px; font:inherit; font-size:.75em; line-height:1; color:#B59C80; }\n.gfx-game-board[data-kind=\"shop\"] .gfx-shop-tool[aria-pressed=\"true\"] { background:var(--gfx-pick, #FFE17A); translate:0 -3px; box-shadow:0 5px 0 var(--gfx-line, #6B4528), 0 0 0 2px #fff inset; }\n.gfx-game-board[data-kind=\"shop\"] .gfx-shop-tool[aria-pressed=\"true\"] .label { color:var(--gfx-accent, #F0763A); }\n/* The kitchen: a tiled wall and four ovens. */\n.gfx-game-board[data-kind=\"shop\"] > .gfx-shop-ovens { display:grid; grid-template-columns:repeat(4,minmax(0,1fr)); gap:3%; padding:10px 3% 10px;\n  background:conic-gradient(#FFFDF8 25%,#EFE3D2 0 50%,#FFFDF8 0 75%,#EFE3D2 0) 0 0 / 22px 22px; }\n.gfx-load-games[data-theme=\"night\"] .gfx-game-board[data-kind=\"shop\"] > .gfx-shop-ovens { background:conic-gradient(#2A2E4D 25%,#232742 0 50%,#2A2E4D 0 75%,#232742 0) 0 0 / 22px 22px; }\n.gfx-game-board[data-kind=\"shop\"] .gfx-shop-oven { position:relative; display:block; padding:0 !important; background:none; border:0; box-shadow:none; border-radius:0 !important; color:inherit; min-width:0; }\n.gfx-game-board[data-kind=\"shop\"] .gfx-shop-oven:active:not(:disabled) { translate:0 2px; box-shadow:none; }\n.gfx-game-board[data-kind=\"shop\"] .gfx-shop-oven:hover:not(:disabled) svg { filter:brightness(1.06); }\n.gfx-shop-oven svg { display:block; width:100%; overflow:visible; }\n.gfx-shop-oven .tag { display:block; margin:3px auto 0; width:fit-content; max-width:100%; box-sizing:border-box; padding:.05em .55em; border-radius:999px; background:#fff; border:2px solid var(--gfx-line, #6B4528);\n  font-size:max(9px,2.2cqw); white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }\n.gfx-shop-oven[data-stage=\"hot\"] .tag { background:#C9F0D6; color:#1C7A43; }\n.gfx-shop-oven[data-stage=\"ready\"] .tag { background:#FFD84D; animation:gfx-game-blink .6s ease-in-out infinite; }\n.gfx-shop-oven[data-stage=\"over\"] .tag { background:#FFB38A; color:#7A2A0C; }\n.gfx-shop-oven[data-stage=\"burnt\"] .tag { background:#E0483C; color:#fff; }\n.gfx-shop-oven[data-stage=\"ready\"] svg { filter:drop-shadow(0 0 5px #FFD84D) drop-shadow(0 0 2px #FFD84D); }\n.gfx-shop-oven[data-stage=\"burnt\"] svg { animation:gfx-game-shake .5s ease infinite; }\n.gfx-shop-oven[data-stage=\"gone\"] { opacity:.3; filter:grayscale(1); }\n.gfx-shop-oven[data-nope] svg { animation:gfx-game-shake .25s ease; }\n/* Oven parts. */\n.gfx-shop-oven svg * { stroke-linecap:round; stroke-linejoin:round; }\n.gfx-shop-oven .ov-foot { fill:var(--gfx-line, #6B4528); }\n.gfx-shop-oven .ov-body { fill:#FBEBD3; stroke:var(--gfx-line, #6B4528); stroke-width:3; }\n.gfx-shop-oven .ov-top { fill:var(--gfx-accent, #F0763A); stroke:var(--gfx-line, #6B4528); stroke-width:3; }\n.gfx-shop-oven .ov-knob circle { fill:#fff; stroke:var(--gfx-line, #6B4528); stroke-width:2.5; }\n.gfx-shop-oven .ov-knob path { stroke:var(--gfx-line, #6B4528); stroke-width:2.5; }\n.gfx-shop-oven .ov-knob { transform-origin:18px 20px; transition:rotate .3s ease; }\n.gfx-shop-oven[data-lit=\"true\"]:not([data-stage=\"cold\"]) .ov-knob { rotate:135deg; }\n.gfx-shop-oven .dial-face { fill:#fff; stroke:var(--gfx-line, #6B4528); stroke-width:2.5; }\n.gfx-shop-oven .ov-dial path[class^=\"z-\"] { fill:none; stroke-width:3.2; stroke-linecap:butt; }\n.gfx-shop-oven .z-raw { stroke:#E5D6BF; } .gfx-shop-oven .z-ready { stroke:#FFC933; } .gfx-shop-oven .z-over { stroke:#F0763A; }\n.gfx-shop-oven .needle { stroke:#E0483C; stroke-width:2; transform-origin:50px 22px; rotate:calc(-90deg + var(--p, 0) * 180deg); transition:rotate .1s linear; }\n.gfx-shop-oven .hub { fill:var(--gfx-line, #6B4528); }\n.gfx-shop-oven .ov-lamp { fill:#D7CBBB; stroke:var(--gfx-line, #6B4528); stroke-width:2.2; }\n.gfx-shop-oven[data-stage=\"heat\"] .ov-lamp { fill:#FF8A3D; animation:gfx-game-blink .5s ease-in-out infinite; }\n.gfx-shop-oven:is([data-stage=\"hot\"],[data-stage=\"raw\"],[data-stage=\"ready\"]) .ov-lamp { fill:#4CD07D; }\n.gfx-shop-oven:is([data-stage=\"over\"],[data-stage=\"burnt\"]) .ov-lamp { fill:#E0483C; animation:gfx-game-blink .3s ease-in-out infinite; }\n.gfx-shop-oven .ov-door { fill:#6B4528; stroke:#3E2616; stroke-width:3; }\n.gfx-shop-oven .ov-glass { fill:#2B1D14; stroke:#3E2616; stroke-width:2; transition:fill .4s ease; }\n.gfx-shop-oven:not([data-stage=\"cold\"]) .ov-glass { fill:#6A2E14; animation:gfx-oven-warm 1.2s ease-in-out infinite alternate; }\n.gfx-shop-oven[data-stage=\"ready\"] .ov-glass { fill:#9A4A1C; }\n.gfx-shop-oven[data-stage=\"burnt\"] .ov-glass { fill:#1A1210; animation:none; }\n@keyframes gfx-oven-warm { to { fill:#7E3818; } }\n.gfx-shop-oven .ov-coil { fill:none; stroke:#7A6A5E; stroke-width:2; }\n.gfx-shop-oven:not([data-stage=\"cold\"]):not([data-stage=\"burnt\"]) .ov-coil { stroke:#FF7A2E; }\n.gfx-shop-oven .ov-fire { display:none; fill:#FFB347; }\n.gfx-shop-oven:not([data-stage=\"cold\"]):not([data-stage=\"burnt\"]) .ov-fire { display:inline; }\n.gfx-shop-oven .ov-fire path { transform-box:fill-box; transform-origin:50% 100%; animation:gfx-oven-flame .35s ease-in-out infinite alternate; }\n.gfx-shop-oven .ov-fire path:nth-child(2n) { animation-delay:-.17s; fill:#FFD84D; }\n@keyframes gfx-oven-flame { to { scale:1 .7; } }\n.gfx-shop-oven .ov-tray { fill:#C9D0D8; stroke:#5C646E; stroke-width:1.6; }\n.gfx-shop-oven .ov-butter rect { fill:#FFE07A; stroke:#7A5A10; stroke-width:1.6; }\n.gfx-shop-oven .ov-butter path { stroke:#fff; stroke-width:1.6; opacity:.7; }\n.gfx-shop-oven .ov-butter, .gfx-shop-oven .ov-melt, .gfx-shop-oven .ov-cookie { display:none; }\n.gfx-shop-oven[data-butter=\"true\"][data-dough=\"false\"][data-stage=\"cold\"] .ov-butter { display:inline; }\n.gfx-shop-oven[data-butter=\"true\"]:not([data-stage=\"cold\"]) .ov-melt { display:inline; fill:#FFD84D; opacity:.9; }\n.gfx-shop-oven[data-dough=\"true\"] .ov-cookie { display:inline; }\n.gfx-shop-oven .ck-ball { fill:#F6DFAE; stroke:#C9A26A; stroke-width:2; transform-box:fill-box; transform-origin:50% 100%; scale:calc(1 + var(--p, 0) * .6) calc(1 - var(--p, 0) * .5); }\n.gfx-shop-oven .ck-disc, .gfx-shop-oven .ck-crack { display:none; }\n.gfx-shop-oven:is([data-stage=\"ready\"],[data-stage=\"over\"],[data-stage=\"burnt\"]) .ck-ball { display:none; }\n.gfx-shop-oven:is([data-stage=\"ready\"],[data-stage=\"over\"],[data-stage=\"burnt\"]) :is(.ck-disc,.ck-crack) { display:inline; }\n.gfx-shop-oven .ck-disc { fill:#E2A04F; stroke:#8A4F1C; stroke-width:2; transform-box:fill-box; transform-origin:50% 100%; }\n.gfx-shop-oven .ck-crack { fill:none; stroke:#B5722F; stroke-width:1.4; }\n.gfx-shop-oven[data-stage=\"over\"] .ck-disc { fill:#A8682E; stroke:#5A3010; }\n.gfx-shop-oven[data-stage=\"burnt\"] .ck-disc { fill:#2E1C12; stroke:#140A06; } .gfx-shop-oven[data-stage=\"burnt\"] .ck-crack { stroke:#4A2E1C; }\n.gfx-shop-oven[data-flat=\"true\"] :is(.ck-disc,.ck-ball) { scale:1.08 .55; }\n.gfx-shop-oven .ck-sugar, .gfx-shop-oven .ck-chip, .gfx-shop-oven .ck-cream { display:none; }\n.gfx-shop-oven[data-sugar=\"true\"]:not([data-stage=\"burnt\"]) .ck-sugar { display:inline; fill:#fff; }\n.gfx-shop-oven[data-chip=\"true\"] .ck-chip { display:inline; fill:#3E2616; }\n.gfx-shop-oven[data-cream=\"true\"] .ck-cream { display:inline; }\n.gfx-shop-oven .ck-cream path:first-child { fill:#fff; stroke:#C99F7E; stroke-width:1.6; }\n.gfx-shop-oven .ck-cream path + path { fill:none; stroke:#E8D3BE; stroke-width:1.2; }\n.gfx-shop-oven .ov-steam { display:none; fill:none; stroke:#fff; stroke-width:2.2; opacity:.85; }\n.gfx-shop-oven[data-stage=\"ready\"] .ov-steam { display:inline; }\n.gfx-shop-oven .ov-steam path { animation:gfx-oven-steam 1s ease-in-out infinite; }\n.gfx-shop-oven .ov-steam path:nth-child(2) { animation-delay:-.33s; } .gfx-shop-oven .ov-steam path:nth-child(3) { animation-delay:-.66s; }\n@keyframes gfx-oven-steam { from { translate:0 4px; opacity:0; } 40% { opacity:1; } to { translate:0 -5px; opacity:0; } }\n.gfx-shop-oven .ov-smoke { display:none; fill:#9A938C; opacity:.8; }\n.gfx-shop-oven[data-warn=\"true\"] .ov-smoke, .gfx-shop-oven[data-stage=\"burnt\"] .ov-smoke { display:inline; }\n.gfx-shop-oven[data-stage=\"burnt\"] .ov-smoke { fill:#3A3330; }\n.gfx-shop-oven .ov-smoke circle { animation:gfx-oven-smoke 1.4s ease-in-out infinite; transform-box:fill-box; transform-origin:50% 50%; }\n.gfx-shop-oven .ov-smoke circle:nth-child(2) { animation-delay:-.5s; } .gfx-shop-oven .ov-smoke circle:nth-child(3) { animation-delay:-1s; }\n@keyframes gfx-oven-smoke { from { translate:0 6px; scale:.6; opacity:0; } 50% { opacity:1; } to { translate:0 -6px; scale:1.2; opacity:0; } }\n.gfx-shop-oven .ov-shine { fill:none; stroke:#fff; stroke-width:2.5; opacity:.25; }\n.gfx-shop-oven .ov-handle { fill:#C9D0D8; stroke:var(--gfx-line, #6B4528); stroke-width:2; }\n/* +price over the oven, a burst of stars for a perfect cookie. */\n.gfx-game-board[data-kind=\"shop\"] > .gfx-shop-coin { position:absolute; bottom:22%; translate:-50% 0; z-index:3; padding:.1em .6em; border-radius:999px !important; background:#FFD84D; color:#5A3A10; border:2.5px solid var(--gfx-line, #6B4528);\n  white-space:nowrap; font-size:max(11px,2.8cqw); pointer-events:none; animation:gfx-shop-coin 1.1s ease-out both; }\n.gfx-game-board[data-kind=\"shop\"] > .gfx-shop-coin[data-zero] { background:#FFE1DC; color:#A1281C; }\n@keyframes gfx-shop-coin { from { translate:-50% 20px; opacity:0; } 20% { translate:-50% 0; opacity:1; } 75% { opacity:1; } to { translate:-50% -40px; opacity:0; } }\n.gfx-game-board[data-kind=\"shop\"] > .gfx-shop-sparkle { position:absolute; bottom:30%; width:10%; aspect-ratio:1; translate:-50% 0; z-index:3; pointer-events:none; animation:gfx-shop-burst .9s ease-out both; }\n.gfx-game-board[data-kind=\"shop\"] > .gfx-shop-sparkle::before, .gfx-game-board[data-kind=\"shop\"] > .gfx-shop-sparkle::after { content:\"✦\"; position:absolute; inset:0; display:grid; place-items:center; color:#FFD84D; font-size:max(14px,4cqw);\n  text-shadow:-1.4em -.6em 0 #FFD84D, 1.3em -.8em 0 #fff, -1em .9em 0 #fff, 1.2em .7em 0 #FFD84D, 0 -1.5em 0 #F7A8C4; -webkit-text-stroke:1px var(--gfx-line, #6B4528); }\n@keyframes gfx-shop-burst { from { scale:.3; opacity:0; } 30% { opacity:1; } to { scale:1.4; opacity:0; } }\n/* 디저트 핀볼 and 비스킷 벽돌깨기: the table on a canvas, the flipper and launch buttons under it. */\n.gfx-game-board:is([data-kind=\"pinball\"],[data-kind=\"bricks\"]) { display:flex; flex-direction:column; gap:8px; padding:8px; background:var(--gfx-line, #6B4528); }\n.gfx-game-board:is([data-kind=\"pinball\"],[data-kind=\"bricks\"]) > * { aspect-ratio:auto; place-items:normal; font-size:inherit; line-height:1.3; }\n.gfx-game-board:is([data-kind=\"pinball\"],[data-kind=\"bricks\"]) > .gfx-pin-table { display:block; width:100%; aspect-ratio:320 / 520; border-radius:12px !important; touch-action:none; cursor:pointer; }\n.gfx-game-board:is([data-kind=\"pinball\"],[data-kind=\"bricks\"]) > .gfx-pin-pad { display:flex; gap:6px; border-radius:0 !important; }\n.gfx-pin-pad button { flex:1; padding:.45em 0 !important; border-radius:14px !important; font-size:.88em; white-space:nowrap; touch-action:none; }\n.gfx-pin-pad .gfx-pin-launch { background:var(--gfx-pick, #FFE17A); }\n.gfx-pin-pad button[data-held] { translate:0 2px; box-shadow:0 1px 0 var(--gfx-line, #6B4528); background:var(--gfx-accent, #F0763A); color:#fff; }\n/* The shop's paper, wood and tiles stay light in every theme, so its writing stays dark. */\n.gfx-game-board[data-kind=\"shop\"], .gfx-game-board[data-kind=\"shop\"] .gfx-shop-tool { color:#5A3A24; }\n.gfx-load-games[data-theme=\"night\"] .gfx-game-board[data-kind=\"shop\"] .gfx-shop-tool[aria-pressed=\"true\"] { background:#FFE17A; }\n.gfx-load-games[data-theme=\"night\"] .gfx-game-board[data-kind=\"shop\"] .gfx-shop-tool[aria-pressed=\"true\"] .label { color:#B5521C; }\n/* 젤리 블록: jelly cubes on a dark tray; a piece being placed shows where it lands and which lines would melt. */\n.gfx-load-games { --j1:#F7A8C4; --j2:#FFB070; --j3:#FFD84D; --j4:#7FD8B0; --j5:#8CC8F5; --j6:#B9A3F5; --j7:#F2727F; }\n.gfx-game-board[data-kind=\"block\"] { gap:3px; padding:7px; background:var(--gfx-line, #6B4528); }\n.gfx-game-board[data-kind=\"block\"] > div { border-radius:22% !important; background:rgba(255,255,255,.09); box-shadow:inset 0 2px 0 rgba(0,0,0,.18); cursor:pointer; }\n.gfx-game-board[data-kind=\"block\"] > div[data-c], .gfx-game-board[data-kind=\"block\"] > div[data-prev], .gfx-block-piece > i[data-c] {\n  background:var(--c); box-shadow:inset 0 -.22em 0 rgba(0,0,0,.2), inset 0 .2em 0 rgba(255,255,255,.5), 0 0 0 1.5px rgba(0,0,0,.25); }\n.gfx-game-board[data-kind=\"block\"] > div[data-c]::before, .gfx-game-board[data-kind=\"block\"] > div[data-prev]::before, .gfx-block-piece > i[data-c]::before {\n  content:\"\"; position:absolute; left:18%; top:16%; width:26%; height:18%; border-radius:999px; background:#fff; opacity:.75; }\n.gfx-game-board[data-kind=\"block\"] > div[data-prev]:not([data-c]) { opacity:.55; }\n:is(.gfx-game-board[data-kind=\"block\"] > div, .gfx-block-piece > i)[data-c=\"1\"], .gfx-game-board[data-kind=\"block\"] > div[data-prev=\"1\"] { --c:var(--j1); }\n:is(.gfx-game-board[data-kind=\"block\"] > div, .gfx-block-piece > i)[data-c=\"2\"], .gfx-game-board[data-kind=\"block\"] > div[data-prev=\"2\"] { --c:var(--j2); }\n:is(.gfx-game-board[data-kind=\"block\"] > div, .gfx-block-piece > i)[data-c=\"3\"], .gfx-game-board[data-kind=\"block\"] > div[data-prev=\"3\"] { --c:var(--j3); }\n:is(.gfx-game-board[data-kind=\"block\"] > div, .gfx-block-piece > i)[data-c=\"4\"], .gfx-game-board[data-kind=\"block\"] > div[data-prev=\"4\"] { --c:var(--j4); }\n:is(.gfx-game-board[data-kind=\"block\"] > div, .gfx-block-piece > i)[data-c=\"5\"], .gfx-game-board[data-kind=\"block\"] > div[data-prev=\"5\"] { --c:var(--j5); }\n:is(.gfx-game-board[data-kind=\"block\"] > div, .gfx-block-piece > i)[data-c=\"6\"], .gfx-game-board[data-kind=\"block\"] > div[data-prev=\"6\"] { --c:var(--j6); }\n:is(.gfx-game-board[data-kind=\"block\"] > div, .gfx-block-piece > i)[data-c=\"7\"], .gfx-game-board[data-kind=\"block\"] > div[data-prev=\"7\"] { --c:var(--j7); }\n/* Lines that the piece would fill glow; cells just placed squash in; melted cells burst. */\n.gfx-game-board[data-kind=\"block\"] > div[data-line] { outline:2.5px solid #fff; outline-offset:-1px; filter:brightness(1.15); z-index:1; animation:gfx-game-blink .5s ease-in-out infinite; }\n.gfx-game-board[data-kind=\"block\"] > div[data-drop] { animation:gfx-block-drop .26s cubic-bezier(.3,1.6,.5,1); }\n@keyframes gfx-block-drop { from { scale:1.25; } 40% { scale:.88; } }\n.gfx-game-board[data-kind=\"block\"] > div[data-pop]::after { content:\"\"; position:absolute; inset:0; border-radius:22%; background:var(--p); animation:gfx-block-melt .5s ease-out forwards; z-index:2; }\n.gfx-game-board[data-kind=\"block\"] > div[data-pop=\"1\"] { --p:var(--j1); } .gfx-game-board[data-kind=\"block\"] > div[data-pop=\"2\"] { --p:var(--j2); } .gfx-game-board[data-kind=\"block\"] > div[data-pop=\"3\"] { --p:var(--j3); }\n.gfx-game-board[data-kind=\"block\"] > div[data-pop=\"4\"] { --p:var(--j4); } .gfx-game-board[data-kind=\"block\"] > div[data-pop=\"5\"] { --p:var(--j5); } .gfx-game-board[data-kind=\"block\"] > div[data-pop=\"6\"] { --p:var(--j6); }\n.gfx-game-board[data-kind=\"block\"] > div[data-pop=\"7\"] { --p:var(--j7); }\n@keyframes gfx-block-melt { 30% { scale:1.2; filter:brightness(1.4); } to { scale:.2; opacity:0; rotate:20deg; } }\n.gfx-game-board[data-kind=\"block\"] > div[data-nope] { animation:gfx-game-shake .3s ease; }\n/* The tray and its three pieces. */\n.gfx-block-tray { display:grid; grid-template-columns:repeat(3,minmax(0,1fr)); gap:8px; width:min(100%, max(170px, var(--room) * var(--fit, 1))); margin:10px auto 0; touch-action:none; user-select:none; -webkit-user-select:none; }\n.gfx-load-games .gfx-block-slot { aspect-ratio:1.15; display:grid; place-items:center; padding:6px !important; border-radius:16px !important; background:color-mix(in srgb,var(--gfx-line, #6B4528) 12%,var(--gfx-ink, #FFF4D9)); touch-action:none; container-type:inline-size; cursor:grab; }\n.gfx-load-games .gfx-block-slot:disabled { cursor:default; }\n.gfx-load-games .gfx-block-slot[aria-pressed=\"true\"] { background:var(--gfx-pick, #FFE17A); outline:3px solid var(--gfx-accent, #F0763A); }\n.gfx-block-slot[data-dragging] > .gfx-block-piece { opacity:.25; }\n.gfx-block-slot[data-dead=\"true\"] > .gfx-block-piece { filter:grayscale(.85); opacity:.5; }\n.gfx-block-piece { --m:min(17cqw, 24px); --gap:2px; display:grid; grid-template-columns:repeat(var(--w), var(--m)); grid-auto-rows:var(--m); gap:var(--gap); pointer-events:none; font-size:var(--m); }\n.gfx-block-piece > i { position:relative; border-radius:22%; }\n.gfx-block-ghost { position:fixed; left:0; top:0; z-index:3; pointer-events:none; filter:drop-shadow(0 6px 4px rgba(0,0,0,.25)); }\n.gfx-block-ghost[hidden] { display:none; }\n.gfx-block-ghost[data-bad=\"true\"] { opacity:.55; filter:grayscale(.6) drop-shadow(0 6px 4px rgba(0,0,0,.25)); }\n.gfx-block-pop { position:absolute; z-index:3; translate:-50% -50%; padding:.1em .7em; border-radius:999px; background:#FFD84D; color:#5A3A10; border:2.5px solid var(--gfx-line, #6B4528); white-space:nowrap; pointer-events:none; animation:gfx-shop-coin 1.1s ease-out both; }\n.gfx-block-pop[data-big] { font-size:1.25em; background:var(--gfx-accent, #F0763A); color:#fff; }\n";
  const CSS_MORE = `
/* Extra games: a wide runner, two portrait arcades and numbered liquid layers. */
.gfx-game-board:is([data-kind="dino"], [data-kind="water"], [data-kind="candy"], [data-kind="knife"], [data-kind="count"]) {
  display:flex; flex-direction:column; gap:8px; padding:8px; background:var(--gfx-line, #6B4528);
}
.gfx-game-board:is([data-kind="dino"], [data-kind="water"], [data-kind="candy"], [data-kind="knife"], [data-kind="count"]) > * {
  aspect-ratio:auto; place-items:normal; font-size:inherit; line-height:1.3;
}
.gfx-game-board .gfx-arcade-canvas { display:block; width:100%; height:auto; border-radius:12px; touch-action:none; cursor:pointer; }
.gfx-game-board .gfx-arcade-pad { display:flex; gap:6px; border-radius:0; }
.gfx-arcade-pad button { flex:1; min-height:40px; padding:.4em .6em !important; touch-action:none; font-size:.85em; }
.gfx-arcade-pad button[data-held] { background:var(--gfx-pick, #FFE17A); translate:0 2px; }
.gfx-game-board:is([data-kind="dino"], [data-kind="water"], [data-kind="candy"], [data-kind="knife"], [data-kind="count"]):focus-visible { outline:3px solid var(--gfx-accent, #F0763A); outline-offset:3px; }
/* 크게 보기: the column over the whole window (top layer), the page dimmed behind it. */
:host([data-game-large]) { position:fixed; inset:12px; width:auto; height:auto; max-width:none; max-height:none; margin:0; padding:0; border:0; background:transparent;
  overflow:visible; color:inherit; z-index:2147483000; box-shadow:0 0 0 100vmax rgba(12,10,24,.55); border-radius:24px; }
:host([data-game-large]) .gfx-load-games { --room:calc(100cqh - 170px); align-items:stretch; }
:host([data-game-large]) .gfx-game-content { display:flex; flex-direction:column; }
:host([data-game-large]) .gfx-game-stage { flex:1; display:flex; flex-direction:column; justify-content:center; }
@media (max-width:600px) { :host([data-game-large]) { inset:6px; } }
/* The game's own UI style (data-skin): its corners and thinner outlines instead of 말랑's capsules. */
.gfx-load-games[data-skin] :is(.gfx-game-nav, .gfx-game-content) { border-radius:var(--gfx-r, 22px); border-width:2px; box-shadow:0 3px 0 var(--gfx-line, #6B4528); }
.gfx-load-games[data-skin] :is(.gfx-game-tools, .gfx-game-levels, .gfx-game-utils, .gfx-drop-pad) button, .gfx-load-games[data-skin] .gfx-game-result button { border-radius:var(--gfx-pill, 999px); border-width:2px; }
.gfx-load-games[data-skin] .gfx-game-tab { border-radius:min(16px, var(--gfx-r, 22px)) !important; border-width:2px; }
.gfx-load-games[data-skin] .gfx-game-board { border-radius:min(16px, var(--gfx-r, 22px)); }
.gfx-load-games[data-skin] .gfx-game-tab[aria-pressed="true"], .gfx-load-games[data-skin] .gfx-drop-pad [data-main] { color:var(--gfx-card, #fff) !important; }
/* 마카롱 낙하: macarons fall into a dark well; the ghost shows where the piece lands, melted rows flash. */
.gfx-drop-row { display:flex; justify-content:center; align-items:flex-start; gap:10px; }
.gfx-drop-row > .gfx-game-board { margin:0; flex:0 1 auto; min-width:0; }
.gfx-game-board[data-kind="drop"] { position:relative; gap:2px; padding:6px; background:var(--gfx-line, #6B4528); overflow:hidden; }
.gfx-game-board[data-kind="drop"]:focus-visible { outline:3px solid var(--gfx-accent, #F0763A); outline-offset:2px; }
.gfx-game-board[data-kind="drop"] > div { border-radius:30% !important; background:rgba(255,255,255,.07); }
:is(.gfx-game-board[data-kind="drop"] > div, .gfx-drop-minigrid > i)[data-c] { background:var(--c);
  box-shadow:inset 0 -.18em 0 rgba(0,0,0,.22), inset 0 .14em 0 rgba(255,255,255,.45), 0 0 0 1px rgba(0,0,0,.25); }
.gfx-game-board[data-kind="drop"] > div[data-c]::before { content:""; position:absolute; left:16%; top:14%; width:30%; height:20%; border-radius:999px; background:#fff; opacity:.6; }
.gfx-game-board[data-kind="drop"] > div[data-live] { filter:brightness(1.08); }
.gfx-game-board[data-kind="drop"] > div[data-ghost] { background:color-mix(in srgb,var(--c) 22%,transparent); box-shadow:inset 0 0 0 2px color-mix(in srgb,var(--c) 75%,transparent); }
:is(.gfx-game-board[data-kind="drop"] > div, .gfx-drop-minigrid > i):is([data-c="1"], [data-ghost="1"]) { --c:var(--j1); }
:is(.gfx-game-board[data-kind="drop"] > div, .gfx-drop-minigrid > i):is([data-c="2"], [data-ghost="2"]) { --c:var(--j2); }
:is(.gfx-game-board[data-kind="drop"] > div, .gfx-drop-minigrid > i):is([data-c="3"], [data-ghost="3"]) { --c:var(--j3); }
:is(.gfx-game-board[data-kind="drop"] > div, .gfx-drop-minigrid > i):is([data-c="4"], [data-ghost="4"]) { --c:var(--j4); }
:is(.gfx-game-board[data-kind="drop"] > div, .gfx-drop-minigrid > i):is([data-c="5"], [data-ghost="5"]) { --c:var(--j5); }
:is(.gfx-game-board[data-kind="drop"] > div, .gfx-drop-minigrid > i):is([data-c="6"], [data-ghost="6"]) { --c:var(--j6); }
:is(.gfx-game-board[data-kind="drop"] > div, .gfx-drop-minigrid > i):is([data-c="7"], [data-ghost="7"]) { --c:var(--j7); }
.gfx-game-board[data-kind="drop"] > .gfx-drop-fx { position:absolute; inset:6px; aspect-ratio:auto; display:block; border-radius:0 !important; background:none; pointer-events:none; z-index:2; }
.gfx-drop-fx > i { position:absolute; left:-2px; right:-2px; top:calc(var(--y) * 5%); height:5%; border-radius:6px; background:#fff; animation:gfx-drop-melt .4s ease-out forwards; }
@keyframes gfx-drop-melt { 0% { opacity:.95; scale:1 1; } 40% { opacity:.9; scale:1.04 1.5; } 100% { opacity:0; scale:1.1 .2; } }
.gfx-drop-side { flex:0 0 4.8em; display:flex; flex-direction:column; gap:6px; }
.gfx-drop-mini { padding:4px 6px 6px; text-align:center; font-size:.78em; border:2px solid var(--gfx-line, #6B4528); border-radius:min(12px, var(--gfx-r, 22px));
  background:color-mix(in srgb,var(--gfx-line, #6B4528) 14%,var(--gfx-ink, #FFF4D9)); }
.gfx-drop-mini > b { display:block; min-height:1.1em; font-weight:normal; }
.gfx-drop-mini > b:empty { display:none; }
.gfx-drop-mini[data-dim] { opacity:.45; }
.gfx-drop-minigrid { display:grid; grid-template-columns:repeat(4,1fr); gap:2px; margin-top:3px; }
.gfx-drop-minigrid[data-w="3"] { translate:12.5% 0; }
.gfx-drop-minigrid > i { aspect-ratio:1; border-radius:30%; }
.gfx-drop-pad { display:flex; justify-content:center; flex-wrap:wrap; gap:6px; margin-top:10px; touch-action:none; user-select:none; -webkit-user-select:none; }
.gfx-drop-pad button { min-width:2.7em; padding:.3em .6em !important; touch-action:none; }
.gfx-drop-pad [data-main] { background:var(--gfx-accent, #F0763A) !important; color:#fff !important; }
.gfx-drop-toast { position:absolute; left:50%; top:34%; translate:-50% 0; z-index:3; pointer-events:none; white-space:nowrap; opacity:0; font-size:1.45em; color:#fff;
  -webkit-text-stroke:1px var(--gfx-line, #6B4528); paint-order:stroke fill; text-shadow:0 3px 0 var(--gfx-line, #6B4528); }
.gfx-drop-toast[data-go] { animation:gfx-drop-toast 1s ease-out forwards; }
@keyframes gfx-drop-toast { 0% { opacity:0; scale:.6; } 15% { opacity:1; scale:1.18; } 30% { scale:1; } 75% { opacity:1; } 100% { opacity:0; translate:-50% -36px; } }
@media (max-width:600px) { .gfx-drop-side { flex-basis:3.6em; } .gfx-drop-row { gap:6px; } .gfx-game-board[data-kind="drop"] { --fit:.36 !important; } .gfx-drop-pad { gap:4px; } .gfx-drop-pad button { min-width:2.3em; } }
`;
  let sheet = null;
  const styleSheet = () => { if (!sheet) { sheet = new CSSStyleSheet(); sheet.replaceSync(CSS + CSS_MORE); } return sheet; };

  /* Mounting: the games sit inside the game's generation panel (.forge-center) only while it says it is
   * generating. The game redraws that panel; the same games (and their state) move to the new one. */
  let mounted = null; // { center, wrap, position }
  function release() {
    if (!mounted) return;
    mounted.center.style.position = mounted.position;
    mounted = null;
  }
  /* The game shows this same screen, saying "Generating story…", while it merely fetches a scene that is already
   * written: on opening the game, on switching worlds, on entering a chapter. It cannot tell beforehand; a saved
   * scene just comes back within a second or so. So: never while the game boots or opens a chapter it has already
   * written, and otherwise only once the screen has been generating for GENERATING_AFTER without a break. */
  const GENERATING_AFTER = 2500;
  let generatingSince = 0;
  function generating(h) {
    if (!writingLoad(h)) return false;
    if (h._boot === "idle" || h._boot === "loading") return false;
    try { if (h._hudView === "forge" && typeof h._chapterWritten === "function" && h._chapterWritten()) return false; } catch {}
    return true;
  }
  function sync() {
    if (disposed) return;
    const h = document.querySelector(HOST_TAG), now = performance.now();
    if (generating(h)) generatingSince ||= now; else generatingSince = 0;
    const settled = generatingSince && (mounted || now - generatingSince >= GENERATING_AFTER);
    const center = settled ? h.shadowRoot.querySelector(".forge-center") : null;
    if (!center) { if (mounted) { mounted.wrap.shadowRoot?.querySelector('.gfx-load-games')?.dispose?.(); mounted.wrap.remove(); release(); } return; }
    if (mounted && mounted.center !== center) { const wrap = mounted.wrap; release(); mounted = { center, wrap, position: center.style.position }; }
    if (!mounted) {
      const wrap = el("div");
      wrap.setAttribute("data-gfx-minigames", "");
      const shadow = wrap.attachShadow({ mode: "open" });
      shadow.adoptedStyleSheets = [styleSheet()];
      shadow.append(makeLoadingGames(wrap));
      mounted = { center, wrap, position: center.style.position };
      center.append(wrap);
      // The preset is read from the game element, so once the column is inside it.
      shadow.querySelector(".gfx-load-games")?.retheme?.();
    }
    if (getComputedStyle(center).position === "static") center.style.position = "relative";
    if (mounted.wrap.parentNode !== center) center.append(mounted.wrap);
  }
  const tick = setInterval(sync, 200);
  sync();

  const dispose = () => {
    if (disposed) return;
    disposed = true;
    clearInterval(tick);
    life.abort();
    if (mounted) { mounted.wrap.shadowRoot?.querySelector('.gfx-load-games')?.dispose?.(); mounted.wrap.remove(); release(); }
    if (window[KEY] === dispose) delete window[KEY];
  };
  window[KEY] = dispose;
  MARINARA?.onCleanup?.(dispose);
})();
